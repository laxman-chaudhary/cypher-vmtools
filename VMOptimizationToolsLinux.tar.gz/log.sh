#!/bin/bash

# Log interface

# Log file
declare g_log_file__="/var/log/sangfor_vm_proxyd.log"
# The log file size limit(1M)
declare -r g_log_size__="$((1024*1024))"
# The log file count limit
declare -r g_log_cnt__=3

# Log interface
# Log file .Support file size limit 
_logfile()
{
    echo "${@}" >> "${g_log_file__}"

    # Gets the log file size
    local filesize=""
    filesize="`stat -c "%s" "${g_log_file__}"`" &&
        [[ "${filesize}" =~ ^.[0-9]+$ ]] ||
        return 0

    # File does not exceed the size. return
    test "${filesize}" -lt "${g_log_size__}" && return 0

    local i=0
    for((i=${g_log_cnt__};i>1;i--))
    do
        local prev="${g_log_file__}_$((i-1))"
        #if [ -e "${prev}" ]
        #then
            #mv -f "${prev}" "${g_log_file__}_${i}"
            #echo "move '${prev}' to '${g_log_file__}_${i}'"
        #fi

        test -e "${prev}" &&
            mv -f "${prev}" "${g_log_file__}_${i}"
    done
    #echo "move '${g_log_file__}' to '${g_log_file__}_1'"
    mv -f "${g_log_file__}" "${g_log_file__}_1"
    return 0
}

# set log file path
# param $1: file path(The absolute path)
set_log_filepath()
{
	g_log_file__=$1
	return 0
}

# The log file interface
# param $1: The contents of the log(Support variable input)
log()
{
    _logfile "I|`date "+%Y/%m/%d %H:%M:%S"`|$$|${0##*/}|${FUNCNAME[1]}|${BASH_LINENO[0]}|" "${*}"
    return 0
}
