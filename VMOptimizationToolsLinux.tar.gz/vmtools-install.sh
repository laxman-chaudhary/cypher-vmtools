#!/bin/bash
# shellcheck disable=SC2086,SC2254,SC2068,SC2129,SC2157,SC2116,SC2166,SC2001,SC2162,SC2010,SC2206,SC2012,SC2155

#检查系统是否支持virtio
#运行程序通知后台修改配置
#修改配置程序

shell_dir=`dirname "${BASH_SOURCE[0]}"`
. "${shell_dir}/net_common.sh"
. "${shell_dir}/action_common.sh"

declare -r g_change_conf_file_name="vtp-sangfor-vmstools-install"
#virtio
declare -r g_virtio="virtio"
#virtio_blk
declare -r g_virtio_blk="${g_virtio}_blk"
#virtio_net
declare -r g_virtio_net="${g_virtio}_net"
#virtio_pci
declare -r g_virtio_pci="${g_virtio}_pci"
#当前目录
declare g_current_dir=""
#修改配置文件的绝对路径
declare g_change_conf_file_path=""

#备份的网络配置路径，此配置路径在virtio_nic_compat.sh同样有定义使用
declare g_sangfor_cfg_dir="/etc/sangfor"
declare g_backup_network_info="${g_sangfor_cfg_dir}/sangfor_network_info.bak"

#以virtio启动可以成功要求的最低发行版redhat（不包含）
declare -i g_redhat_least_support_version_main=5
declare -i g_redhat_least_support_version_sub=4

#以virtio启动可以成功要求的最低发行版suse（包含）
declare -i g_suse_least_support_version_main=12

#要求linux内核版本号不低于2.6.18
#redhat/centos5.x 的内核版本为 2.6.18, 但其不包含 virtio_console 驱动, 不能透传数据
#Virtio要求的最低linux内核版本号是2.6.25, 这里直接使用2.6.25做判断
#防止出现客户升级到 2.6.18, 仍然出现安装 vmtools 失败的问题, by lwf
declare -i g_kernel_least_version=2
declare -i g_kernel_least_major_version=6
declare -i g_kernel_least_minor_version=25

#TD25596 快速拉起的虚拟机，import virtio驱动报错
#TD26215 安装vmtool，回迁到VMware不能正常启动
declare -r TRUE=0
declare -r FALSE=1
#操作系统类型，目前只处理rhel和debian两大类
declare -r UNKNOW_TYPE=0
declare -r RHEL_TYPE=1
declare -r DEBIAN_TYPE=2
declare -r SUSE_TYPE=3
#麒麟v10系统
declare -r KYLIN_V10_TYPE=4

declare -r RD_UPD_TOOL=10
declare -r RD_LIST_TOOL=20

declare g_target_kernel=""
declare g_system_type=${UNKNOW_TYPE}
#需要更新到rd文件的列表
declare mod_list_need_upd=""
#临时保存系统rd内容的文件
declare g_rd_list_file=""

# 从环境变量BACKEND中获取运行环境标识，目前有值可能是 libguestfs
declare g_backend_type=${BACKEND}

#检查系统类型
#retval： 1 ref Rhel 2 ref Debian 3 suse 4 kylin
check_system_type(){
    local lsb_ver="/etc/os-release"
    local rhel_ver="/etc/redhat-release"
    local issue_ver="/etc/issue"
    local sys_id=""
    local sys_major_ver=""
    local tmp=""
    local tmp_ver=""

    if [ -e $lsb_ver ]; then
        sys_id=$( grep '^ID=' $lsb_ver )
        sys_ver=$( grep '^VERSION_ID=' $lsb_ver )
        sys_ver=${sys_ver#*=}
        sys_ver=${sys_ver//\"/}
        tmp=$( echo $sys_id | grep -Ei "ubuntu|debian" 2>/dev/null )
        if [ -n "$tmp" ]; then
            echo $DEBIAN_TYPE
            return
        fi
        tmp=$( echo $sys_id | grep -Ei "redhat|centos|fedora" 2>/dev/null )
        if [ -n "$tmp" ]; then
            echo $RHEL_TYPE
            return
        fi
        # SUSE Linux Enterprise Server, sles
        tmp=$( echo $sys_id | grep -Ei "sles|suse" 2>/dev/null )
        if [ -n "$tmp" ]; then
            echo $SUSE_TYPE
            return
        fi

        #麒麟v10
        tmp=$( echo $sys_id | grep -Ei "kylin" 2>/dev/null )
        tmp_ver=$( echo $sys_ver | grep -i "v10" 2>/dev/null )
        if [ -n "$tmp" -a -n "$tmp_ver" ]; then
            echo $KYLIN_V10_TYPE
            return
        fi
    fi
    #redhat
    if [ -e  $rhel_ver ]; then
        echo $RHEL_TYPE
        return
    fi

    if [ -e $issue_ver ]; then
        tmp=$( grep -Ei "ubuntu|debian" $issue_ver 2>/dev/null )
        if [ -n "$tmp" ]; then
            echo $DEBIAN_TYPE
            return
        fi
        tmp=$( grep -Ei "redhat|centos|fedora" $issue_ver 2>/dev/null )
        if [ -n "$tmp" ]; then
            echo $RHEL_TYPE
            return
        fi
        tmp=$( grep -Ei "suse" $issue_ver 2>/dev/null )
        if [ -n "$tmp" ]; then
            echo $SUSE_TYPE
            return
        fi

        #麒麟v10
        tmp=$( grep -i "kylin" $issue_ver 2>/dev/null )
        tmp_ver=$( grep -i "v10" $issue_ver 2>/dev/null )
        if [ -n "$tmp" -a -n "$tmp_ver" ]; then
            echo $KYLIN_V10_TYPE
            return
        fi
    fi

    echo $UNKNOW_TYPE
    return
}

#检测目标模块是否已经builtin
if_builtin_mod() {
    local target_mod=$1
    local builtin_file="/lib/modules/${g_target_kernel}/modules.builtin"
    local tmp=""

    if [ -z "$target_mod" ]; then
        echo $FALSE
        return
    fi

    if [ ! -e $builtin_file ]; then
       echo $FALSE
       return
    fi

    tmp=$(grep -w $target_mod $builtin_file 2>/dev/null)
    if [ -n "$tmp" ]; then
       echo $TRUE
       return
    fi

    echo $FALSE
    return
}

#获取操作rd文件的工具路径
#redhat : lsinitrd、mkinitramfs
#ubuntu need update-initramfs lsinitramfs
get_rd_tool_path() {
    tmp=""
    case $g_system_type in
    $RHEL_TYPE|$KYLIN_V10_TYPE )
        if [ "$1" -eq $RD_UPD_TOOL ]; then
            tmp=$(which mkinitrd 2>/dev/null)
            echo $tmp
            return
        elif [ "$1" -eq $RD_LIST_TOOL ]; then
            tmp=$(which lsinitrd 2>/dev/null)
            echo $tmp
            return
        else
           echo ""
           return
        fi
    ;;
    $DEBIAN_TYPE )
        if [ "$1" -eq $RD_UPD_TOOL ]; then
            tmp=$(which update-initramfs 2>/dev/null)
            echo $tmp
            return
        elif [ "$1" -eq $RD_LIST_TOOL ]; then
            tmp=$(which lsinitramfs 2>/dev/null)
            echo $tmp
            return
        else
           echo ""
           return
        fi
    ;;
    $SUSE_TYPE )
        if [ "$1" -eq $RD_UPD_TOOL ]; then
            tmp=$(which dracut 2>/dev/null)
            if [ "$?" -ne 0 ]; then
                # for suse 11
                tmp=$(which mkinitrd 2>/dev/null)
            fi
            echo $tmp
            return
        elif [ "$1" -eq $RD_LIST_TOOL ]; then
            tmp=$(which lsinitrd 2>/dev/null)
            echo $tmp
            return
        else
           echo ""
           return
        fi
    ;;
    * )
        echo ""
        return
    ;;
    esac
}

#获取目标rd文件的路径
get_target_img() {
    local img=""
    case $g_system_type in
    $RHEL_TYPE|$KYLIN_V10_TYPE )
        img="/boot/initramfs-${g_target_kernel}.img"
        if [ -e $img ]; then
            echo $img
        else
            echo ""
        fi
        return
    ;;
    $DEBIAN_TYPE )
        img="/boot/initrd.img-${g_target_kernel}"
        if [ -e $img ]; then
            echo $img
        else
            echo ""
        fi
        return
    ;;
    $SUSE_TYPE )
        img="/boot/initrd-${g_target_kernel}"
        if [ -e $img ]; then
            echo $img
        else
            echo ""
        fi
        return
    ;;
    * )
        echo ""
        return
    ;;
    esac
}

#更新rhel类型系统的initrd
update_rhel_initrd() {
    local update_tool=""
    local update_cmd=""
    local rd_img=""

    rd_img=$(get_target_img)
    if [ -z "$rd_img" ]; then
        echo "initrd file not find!"
        return $FALSE
    fi

    update_tool=$(get_rd_tool_path $RD_UPD_TOOL)
    if [ -z "$update_tool" ]; then
        echo "mkinitrd cmd not find!"
        return $FALSE
    fi

    cp -f "$rd_img" "$rd_img.sfbak" 2>/dev/null
    if [ "$?" -ne 0 ]; then
        echo "backup initrd file fail!"
        return $FALSE
    fi

    update_cmd="$update_tool"
    for upd_mod in ${mod_list_need_upd[@]}
    do
        update_cmd="$update_cmd --with $upd_mod"
    done

    update_cmd="$update_cmd -f $rd_img  $g_target_kernel"
    $update_cmd >/dev/null 2>&1
    if [ "$?" -ne 0 ]; then
        echo "update $rd_img fail!"
        cp -f "$rd_img.sfbak" "$rd_img" 2>/dev/null
        if [ "$?" -eq 0 ]; then
            rm -f $rd_img.sfbak 2>/dev/null
            return $FALSE
        fi
        echo "restore backup file fail!"
        return $FALSE
    fi

    return $TRUE
}

#更新debian类型系统的initrd文件
update_debian_initrd() {
    local -r mod_conf_file="/etc/initramfs-tools/modules"
    local update_tool=""
    local rd_img=""

    rd_img=$(get_target_img)
    if [ -z "$rd_img" ]; then
        echo "initrd file not find!"
        return $FALSE
    fi

    update_tool=$(get_rd_tool_path $RD_UPD_TOOL)
    if [ -z "$update_tool" ]; then
        echo "update-initramfs cmd not find!"
        return $FALSE
    fi

    cp -f "$rd_img" "$rd_img.sfbak" 2>/dev/null
    if [ "$?" -ne 0 ]; then
        echo "backup initrd file fail!"
        return $FALSE
    fi

    if [ ! -e $mod_conf_file ]; then
        echo "can't not find mod update file: $mod_conf_file"
        return $FALSE
    fi

    echo "" >> $mod_conf_file
    echo "" >> $mod_conf_file
    echo "#These modules were added by Sangfor VMTools for virtualize system." >> $mod_conf_file
    echo "#Do not edit it." >> $mod_conf_file
    for upd_mod in ${mod_list_need_upd[@]}
    do
        echo $upd_mod >> $mod_conf_file
    done
    echo "#Sangfor VMTools add end." >> $mod_conf_file

    $update_tool -u >/dev/null 2>&1
    if [ "$?" -ne 0 ]; then
        echo "update $rd_img fail!"
        cp -f "$rd_img.sfbak" "$rd_img" 2>/dev/null
        if [ "$?" -eq 0 ]; then
            rm -f $rd_img.sfbak 2>/dev/null
            return $FALSE
        fi
        echo "restore backup file fail!"
        return $FALSE
    fi

    return $TRUE
}

get_suse_vml_images(){
    img="/boot/vmlinuz-${g_target_kernel}"
    if [ -e $img ]; then
        echo $img
    else
        echo ""
    fi
    return
}

update_suse_initrd() {
    local update_tool=""
    local update_cmd=""
    local rd_img=""
    local mods=""

    rd_img=$(get_target_img)
    if [ -z "$rd_img" ]; then
        echo "initrd file not find!"
        return $FALSE
    fi

    vml_img=$(get_suse_vml_images)
    if [ -z "vml_img" ]; then
        echo "vmlinuz file not find!"
        return $FALSE
    fi

    update_tool=$(get_rd_tool_path $RD_UPD_TOOL)
    if [ -z "$update_tool" ]; then
        echo "dracut or mkinitrd cmd not find!"
        return $FALSE
    fi

    cp -f "$rd_img" "$rd_img.sfbak" 2>/dev/null
    if [ "$?" -ne 0 ]; then
        echo "backup initrd file fail!"
        return $FALSE
    fi

    # add modules
    mods=$(echo ${mod_list_need_upd[@]})
    dracut_tool=$( echo $update_tool | grep "dracut" 2>/dev/null )
    if [ -n "$dracut_tool" ]; then
        update_cmd="$update_tool --add-drivers \"$mods\" -f $rd_img --kver $g_target_kernel"
    else
        update_cmd="$update_tool -m \"$mods\" -i $rd_img -k $vml_img"
    fi

    eval "$update_cmd" >/dev/null 2>&1
    if [ "$?" -ne 0 ]; then
        echo "update $rd_img fail!"
        cp -f "$rd_img.sfbak" "$rd_img" 2>/dev/null
        if [ "$?" -eq 0 ]; then
            rm -f $rd_img.sfbak 2>/dev/null
            return $FALSE
        fi
        echo "restore backup file fail!"
        return $FALSE
    fi

    return $TRUE
}

upd_rd_file() {
    case $g_system_type in
    $RHEL_TYPE|$KYLIN_V10_TYPE )
        update_rhel_initrd
    ;;
    $DEBIAN_TYPE )
        update_debian_initrd
    ;;
    $SUSE_TYPE )
        update_suse_initrd
    ;;
    * )
        return $FALSE
    ;;
    esac
    return $?
}

#检查系统是否存在更新rd所需要的工具
check_initrd_tool() {
    local lsrd_tool=""
    local mkrd_tool=""

    if [ "$g_system_type" -eq $RHEL_TYPE -o "$g_system_type" -eq $DEBIAN_TYPE -o "$g_system_type" -eq $SUSE_TYPE -o "$g_system_type" -eq $KYLIN_V10_TYPE ]
    then
        lsrd_tool=$(get_rd_tool_path $RD_LIST_TOOL)
        mkrd_tool=$(get_rd_tool_path $RD_UPD_TOOL)
        if [ -n "$lsrd_tool" -a -n "$mkrd_tool" ]; then
            if [ "$g_system_type" -eq $DEBIAN_TYPE ]; then
                #先更新一次initrd，确保/etc/initramfs-tools/modules内的模块配置已经存在rd文件内
                $mkrd_tool -u >/dev/null 2>&1
            fi
            echo $TRUE
            return
        fi
    fi
    echo $FALSE
    return
}

#获取一遍系统rd文件的列表存入缓存文件中
gen_rd_list_file()
{
    local mod_ls_tool=""
    local target_img=""
    g_rd_list_file=`mktemp`
    mod_ls_tool=$(get_rd_tool_path $RD_LIST_TOOL)
    if [ -z "$mod_ls_tool" ]; then
        # echo "can't find rd tools"   调试信息
        return 1
    fi
    target_img=$(get_target_img)
    if [ -z "$target_img" ]; then
        # echo "can't find rd"   调试信息
        return 1
    fi

    # echo "get rd list in $g_rd_list_file"   调试信息
    $mod_ls_tool $target_img >$g_rd_list_file
    return 0
}

#检查目标模块是否已经编译进了rd文件内
if_mod_in_rd() {
    local tmp=""

    if [ -z "$1" ]; then
     echo $FALSE
     return
    fi

    #使用缓存文件，避免每次判断都解压rd，花费时间
    if [ -f "$g_rd_list_file" ];then
        tmp=$(cat $g_rd_list_file |grep -w $1.ko)
        if [ -z "$tmp" ]; then
            echo $FALSE
            return
        fi
        echo $TRUE
        return
    fi

    echo $FALSE
    return
}

#检查模块驱动在当前的内核是否存在
if_mod_exist() {
    local tmp=""
    local module_path="/lib/modules/${g_target_kernel}/kernel/"

    if [ -z "$1" ]; then
        echo $FALSE
        return
    fi

    tmp=$(find $module_path -name $1.ko -o -name $1.ko.xz 2>/dev/null)
    if [ -n "$tmp" ]; then
        echo $TRUE
        return
    fi
    echo $FALSE
    return
}

check_not_support_system(){

    if [ "$g_system_type" -eq $SUSE_TYPE ]; then
        if [ -e "/etc/SuSE-release" ]; then
            suse_release="/etc/SuSE-release"
            # 获取版本号
            sys_ver=$(grep '^VERSION =' $suse_release)
            sys_ver=${sys_ver##*=}
            
            # 获取补丁版本包
            sys_patchlevel=$(grep '^PATCHLEVEL =' $suse_release)
            sys_patchlevel=${sys_patchlevel##*=}
        elif [ -e "/etc/products.d/baseproduct" ]; then
            suse_release="/etc/products.d/baseproduct"
            # 获取版本号,原本格式为<baseversion>xx</baseversion>
            sys_ver=`grep '<baseversion>' $suse_release | cut -d'>' -f2 | cut -d'<' -f1`
            
            # 获取补丁版本包,原本格式为<patchlevel>xx</patchlevel>
            sys_patchlevel=`grep '<patchlevel>' $suse_release | cut -d'>' -f2 | cut -d'<' -f1`
        else
            echo "vmtools not support for this operating system"
            return
        fi

        sys_ver=$(echo $sys_ver | awk '{print int($0)}')
        if [ "$sys_ver" -ne 11 ]; then
            return
        fi
        
        sys_patchlevel=$(echo $sys_patchlevel | awk '{print int($0)}')
        if [ "$sys_patchlevel" -le 1 ]; then
            echo "vmtools not support for suse 11 or suse 11 sp1, please update the operating system"
            return
        fi
    fi
    return
}

#更新系统rd文件的入口
update_system_rd_file() {
    local -r module_check_list=( mptbase mptsas virtio_pci virtio_blk )
    local tool_chk=$FALSE
    local mod_builtin=$FALSE
    local mod_exist=$FALSE
    local mod_in_rd=$FALSE

    if [ "$g_system_type" -eq $UNKNOW_TYPE ]; then
        return $FALSE
    fi

    tool_chk=$(check_initrd_tool)
    if [ "$tool_chk" -ne $TRUE ]; then
        echo "Error: can not find rd file tools"
        return $FALSE
    fi

    #获取rd文件列表
    gen_rd_list_file

    for mod in ${module_check_list[*]}
    do
        mod_builtin=$FALSE
        mod_exist=$FALSE
        mod_in_rd=$FALSE

        mod_builtin=$(if_builtin_mod $mod)
        if [ "$mod_builtin" -eq $TRUE ]; then
            continue
        fi

        mod_in_rd=$(if_mod_in_rd $mod)
        if [ "$mod_in_rd" -eq $TRUE ]; then
           continue
        fi

        mod_exist=$(if_mod_exist $mod)
        if [ "$mod_exist" -eq $TRUE ]; then
           mod_list_need_upd="$mod_list_need_upd $mod"
        else
           echo "Warnning: Can not find kernel module $mod.ko"
        fi
    done

    if [ -n "$mod_list_need_upd" ]; then
        upd_rd_file
        return $?
    fi
    return $TRUE
}

#检查操作系统发行版本(cat /etc/issue)是否符合要求
#不支持RedHat5.4以下版本的操作系统以virtio设备启动(不修改引导文件)
check_boot_support() {
    local distribution_version=""
    local version_number=""
    local main_version=0
    local sub_version=0

    distribution_version="`cat /etc/issue | grep -i \"Red Hat\"`"
    if [ x"${distribution_version}" = x"" ]; then
        return 0;
    fi
    echo ${distribution_version}
    version_number=`echo ${distribution_version} | sed s/[^0-9.]//g`
    main_version=`echo ${version_number} | tr "." " " | awk '{print $1}'`
    sub_version=`echo ${version_number} | tr "." " " | awk '{print $2}'`

    if [ ${main_version} -gt ${g_redhat_least_support_version_main} ]; then
        return 0;
    fi
    if [ ${main_version} -eq ${g_redhat_least_support_version_main} ]; then
        if [ ${sub_version} -ge ${g_redhat_least_support_version_sub} ]; then
            return 0;
        fi
    fi
    return 1;
}

#检查操作系统发行版本(cat /etc/issue)是否需要关闭高性能模式
#RedHat5.x版本需要关闭高性能模式,suse12之前的版本也需要关闭
check_close_high_performance() {
    local distribution_version=""
    local version_number=""
    local main_version=0
    local is_redhat=""
    local is_suse=""

    is_redhat="`cat /etc/issue | grep -i \"Red Hat\"`"
    is_suse="`cat /etc/issue | grep -i \"SUSE\"`"

    if [ x"${is_redhat}" != x"" ]; then
        distribution_version=$is_redhat

        version_number=`echo ${distribution_version} | sed s/[^0-9.]//g`
        main_version=`echo ${version_number} | tr "." " " | awk '{print $1}'`

        if [ ${main_version} -eq ${g_redhat_least_support_version_main} ]; then
            return 0;
        fi
    elif [ x"${is_suse}" != x"" ]; then
        distribution_version=$is_suse

        version_number=`echo ${distribution_version} | awk '{print $7}'`

        if [[ ${version_number} != *[!0-9]* && ${version_number} -lt ${g_suse_least_support_version_main} ]]; then
            return 0;
        fi
    fi
    return 1;
}

#判断系统内核是否支持，要求内核版本不能低于2.6.18
is_support_kernel(){
    KERNEL_VERSION=`echo ${g_target_kernel} | awk -F'.' '{ print $1}'`;
    if [ ! "${KERNEL_VERSION}" ]; then
        return 1;
    fi
    MAJOR_VERSION=`echo ${g_target_kernel} | awk -F'.' '{ print $2}'`;
    if [ ! "${MAJOR_VERSION}" ]; then
        return 1;
    fi
    MINOR_VERSION=`echo ${g_target_kernel} | awk -F'-' '{ print $1}' | awk -F'.' '{ print $3}'`;
    if [ ! "${MINOR_VERSION}" ]; then
        return 1;
    fi
    if [ ${KERNEL_VERSION} -gt ${g_kernel_least_version} ]; then
        return 0;
    fi
    if [ ${KERNEL_VERSION} -eq ${g_kernel_least_version} ]; then
        if [ ${MAJOR_VERSION} -gt ${g_kernel_least_major_version} ]; then
            return 0;
        fi
        if [ ${MAJOR_VERSION} -eq ${g_kernel_least_major_version} ]; then
            if [ ${MINOR_VERSION} -ge ${g_kernel_least_minor_version} ]; then
                return 0;
            fi
        fi
    fi
    return 1;
}
#判断能不能通过virtio_blk启动，防止重启后不能进入系统
#可以返回0
is_virtio_blk_boot_filter(){
    local initramfs_img=""
    local temp_str=""
    initramfs_img="/boot/initramfs-${g_target_kernel}.img"
    local linux=""
    # redhat6.0-7.0都可通过/etc/system-release文件来判断是不是redhat
    # /etc/issue是普遍的方式，但是redhat7不行
    linux=`cat /etc/system-release 2>/dev/null | grep -iE "CentOS|Red Hat" 2>/dev/null`
    # redhat6.0-7.0 img文件都是/boot/initramfs-${g_target_kernel}.img
    # 但是处理img的方式有点不一样
    if [ "${linux}" != "" ];then
        #是redhat
        if [ -e "${initramfs_img}" ];then
            # 存在就判断
            type lsinitrd > /dev/null 2>&1
            if [ $? -eq 0 ]; then
                #存在命令，直接通过命令查看
                temp_str=`lsinitrd "${initramfs_img}" | grep -i ${g_virtio_blk} 2>/dev/null`
            else
                # 不存在命令，使用更通用的工具
                # redhat7.0不能使用zcat查看，只能通过lsinitrd查看
                temp_str=`zcat "${initramfs_img}" |cpio -it|grep -i ${g_virtio_blk} 2>/dev/null`
            fi
            test -z "${temp_str}" && return 1 #为空说明不支持
            return 0
        fi
        #是redhat 但是img文件不存在，出现未知的情况
        return 1
    fi
    # 再做其他的过滤

    #没有其他的过滤了
    # 这个函数主要是做一个限制，一个过滤，过滤后的环境都认为可以安装
    return 0
}
#判断是否支持virtio
is_support_virtio(){
    local modules=""
    local virtio=""
    local virtio_module=""
    local code=0
    local vblk=0
    local vnet=0
    local vpci=0

    check_boot_support
    code=$?
    if [ ${code} -ne 0 ]; then
        return 1;
    fi
    # 判断能不能从virtio_blk启动
    is_virtio_blk_boot_filter
    code=$?
    if [ ${code} -ne 0 ];then
        return 1
    fi
    modules="/lib/modules/${g_target_kernel}/modules.builtin"

    # 判断文件是否存在
    if [ -e "${modules}" ];then
        #存在
        virtio=`cat ${modules} |grep ${g_virtio} 2>/dev/null`
        if [ x"${virtio}" != x"" ];then
            virtio_module=`echo ${virtio} |grep ${g_virtio_blk} 2>/dev/null`
            if [ x"${virtio_module}" != x"" ];then
                vblk=1
            fi
            virtio_module=`echo ${virtio} |grep ${g_virtio_net} 2>/dev/null`
            if [ x"${virtio_module}" != x"" ];then
                vnet=1
            fi
            virtio_module=`echo ${virtio} |grep ${g_virtio_pci} 2>/dev/null`
            if [ x"${virtio_module}" != x"" ];then
                vpci=1
            fi
            if [ ${vblk} -eq 1 ] && [ ${vnet} -eq 1 ] && [ ${vpci} -eq 1 ];then
                return 0
            fi
        fi
    fi
    #不存在或者没有包含virtio
    modules="/lib/modules/${g_target_kernel}/modules.alias"
    # 判断文件是否存在
    if [ ! -e "${modules}" ];then
        #不存在
        return 1
    fi
    #存在
    virtio=`cat ${modules} |grep ${g_virtio} 2>/dev/null`
    if [ x"${virtio}" != x"" ];then
        virtio_module=`echo ${virtio} |grep ${g_virtio_blk} 2>/dev/null`
        if [ x"${virtio_module}" != x"" ];then
            vblk=1
        fi
        virtio_module=`echo ${virtio} |grep ${g_virtio_net} 2>/dev/null`
        if [ x"${virtio_module}" != x"" ];then
            vnet=1
        fi
        virtio_module=`echo ${virtio} |grep ${g_virtio_pci} 2>/dev/null`
        if [ x"${virtio_module}" != x"" ];then
            vpci=1
        fi
        if [ ${vblk} -eq 1 ] && [ ${vnet} -eq 1 ] && [ ${vpci} -eq 1 ];then
            return 0
        else
            return 1
        fi
    else
        return 1
    fi
}

is_virtio_blk_boot(){
    local virtio=""
    local initrd_img=""
    local initramfs_img=""
    initrd_img="/boot/initrd-${g_target_kernel}.img"
    initramfs_img="/boot/initramfs-${g_target_kernel}.img"

    if [ ! -e "${initrd_img}" ];then
        #不存在
        #下面的操作要么是退出(exit)，要么是支持(return 0)
        echo "${initrd_img} is not exist!"          #提示信息，不删掉
        if [ ! -e "${initramfs_img}" ];then
            #不存在
            echo "${initramfs_img} is not exist!"          #提示信息，不删掉
            #两个都不存在
            echo "can not boot from ${g_virtio_blk}!"
            exit 1           #肯定有一个存在的
        fi
        #存在
        virtio=`zcat ${initramfs_img} |cpio -it|grep -i ${g_virtio_blk} 2>/dev/null`
        echo "virtio = ${virtio}"        #调试，去掉
        if [ x"${virtio}" != x"" ];then
            echo "${initramfs_img} contine ${g_virtio_blk}"         #调试，去掉
            return 0
        else
            echo "can not boot from ${g_virtio_blk}!"     #提示信息，不删掉
            exit 1      #initramfs这个也没有，这种情况还没遇到，如果出现这种情况直接退出
        fi
    fi
    #存在
    virtio=`zcat ${initrd_img} |cpio -it|grep -i ${g_virtio_blk} 2>/dev/null`
    echo "virtio = ${virtio}"        #调试，去掉
    if [ x"${virtio}" != x"" ];then
        return 0
    else
        return 1
    fi
}
set_virtio_blk_boot(){
    local code=0
    local initrd_img=""
    initrd_img="/boot/initrd-${g_target_kernel}.img"
    cp -f "${initrd_img}" "${initrd_img}.sfbak"   #备份
    mkinitrd --with ${g_virtio_pci} --with ${g_virtio_blk} -f ${initrd_img} ${g_target_kernel}
    code=$?
    if [ ${code} -ne 0 ];then
        echo "mkinitrd failed!"                  #提示信息，不删掉
        cp -f "${initrd_img}.sfbak" "${initrd_img}"
        return 1
    else
        echo "mkinitrd success!"              #调试，去掉
        return 0
    fi
}
#判断系统是32位还是64位
#x86 return 32
#x64 return 64
x86_or_x64(){
    local x64="x86_64"
    local info=""
    info="`uname -a 2>/dev/null`"
    if [ x"${info/${x64}/}" = x"${info}" ];then
        #x86
        return 32
    else
        return 64
    fi
}
# TODO暂时先依靠config文件获取uname-r，如果用户升级过内核则会获取到错误的版本。 后续可以解析grub文件获取
get_uname-r(){
    local config_list=()
    local config_names=`ls /boot/config-* |grep -v -i -E "rescue|kdump"`

    for config in $config_names
    do
        local uname_r="${config#*-}"
        config_list=(${config_list[*]} "$uname_r")
    done

    if [ 0 -eq ${#config_list[@]} ];then
        return 1
    elif [ 1 -eq ${#config_list[@]} ];then
        if [ -n "${config_list[0]}" ];then
            echo "${config_list[0]}"
            return 0
        fi
    fi
    #比较选取最高版本号，初始化为数组第一个
    local latest_version="${config_list[0]}"
    for config in ${config_list[@]}
    do
        local version="${config%%-*}"
        compare_version "$version" "${latest_version%%-*}"
        if [ $? -eq 1 ];then
            latest_version=$config
        fi
    done

    echo "$latest_version"
    return 0
}
#初始化环境
init(){
    local code=0
    g_current_dir=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

    if [ x"${g_backend_type}" = x"libguestfs" ];then
        g_target_kernel="`get_uname-r`"
    else
        g_target_kernel=`uname -r`
    fi

    #判断系统是32还是64
    x86_or_x64
    code=$?
    if [ ${code} -eq 32 ];then
        g_change_conf_file_path="${g_current_dir}/x86/${g_change_conf_file_name}"
    else
        g_change_conf_file_path="${g_current_dir}/x64/${g_change_conf_file_name}"
    fi
}

notify_to_host(){
    local op_notify=$1
    if [ x"${g_backend_type}" = x"libguestfs" ];then
        # 在libguestfs环境中无法通知关闭高性能，所以直接处理为失败
        if [ x"$op_notify" = x"CloseHighPerformance" ];then
            return 1
        fi
        return 0
    fi

    #调用程序修改后台配置
    if [ ! -e "${g_change_conf_file_path}" ];then
        #不存在
        echo "${g_change_conf_file_path} is not exist!"          #提示信息，不删掉
        return 1
    fi
    #存在
    chmod +x "${g_change_conf_file_path}" >/dev/null 2>&1
    #运行程序，修改配置
    "${g_change_conf_file_path}" ${op_notify}
    exit_code=$?
    if [ ${exit_code} -ne 0 ];then
        echo "Modify Virtual machine profile failed!"          #提示信息，不删掉
        return 1
    fi
    return 0
}

#修改/etc/fstab,暂不处理grub
change_fstabcfg(){
    local new_fstab="/etc/fstab.sf_new"
    local is_change=0
    #不存在e2label，就返回
    type e2label 2>/dev/null 1>&2 || return 0

    while read line
    do
        #空行，已经使用lable的行不处理
        if [[ $line =~ ^\# ]] || [[ $line =~ ^LABEL ]] || [[ $line =~ ^label ]] || [[ x"$line" == x"" ]]; then
            echo "$line" >> "$new_fstab"
            continue
        fi
        fs_spec=`echo $line | awk '{print $1}'`
        fs_type=`echo $line | awk '{print $3}'`
        if [ ! -e $fs_spec ];then
            echo "$line" >> "$new_fstab"
            continue
        fi
        #暂时只处理ext文件系统的分区
        if [[ ! $fs_type =~ ^ext ]];then
            echo "$line" >> "$new_fstab"
            continue
        fi
        e2label "$fs_spec" 2>/dev/null 1>&2
        if [ $? -ne 0 ];then
            echo "$line" >> "$new_fstab"
            continue
        fi
        label=`e2label $fs_spec 2>/dev/null`
        if [[ x"$label" == x"" ]];then
            if [ -L "$fs_spec" ];then
                label1=`echo $fs_spec 2>/dev/null | awk -F"/" '{print $NF}'`
                label2=`ls -l $fs_spec | awk -F"/" '{print $NF}'`
                label1_length=`echo ${#label1}`
                label2_length=`echo ${#label2}`
                [[ $label1_length -le $label2_length ]] && label=$label1 || label=$label2
            else
                label=`echo $fs_spec | awk -F"/" '{print $NF}'`
            fi
            e2label "$fs_spec" "$label" 2>/dev/null
            if [ $? -ne 0 ];then
                echo "$line" >> "$new_fstab"
                continue
            fi
        fi
        echo "$line" | sed "s#${fs_spec}#LABEL=${label}#" >> "$new_fstab"
        is_change=1
    done < "/etc/fstab"
    #没有修改fstab，直接返回
    if [ $is_change -eq 0 ];then
        rm -f "$new_fstab"
        return 0
    fi
    #备份原fstab
    cp -f "/etc/fstab" "/etc/fstab.sfback"
    mv -f "$new_fstab" "/etc/fstab"
    return 0
}

#出错退出之前清理环境
exit_clean_env(){
    "${g_current_dir}/update_install" uninstall >/dev/null 2>&1
    exit 1
}

# 仅在安装的时候备份一次，升级的时候会检查有没有生成备份配置，有则不重复备份。
# 不过即使重复备份也没有关系，依靠此配置修正网络配置的脚本只会运行一次
backup_network_cfg()
{
    if [ -e "${g_backup_network_info}" ]; then
        return
    fi
    mkdir -p "${g_sangfor_cfg_dir}"
    local net_dev_list=$(get_net_name)
    for net_dev in $net_dev_list; do
        macaddr=`cat "/sys/class/net/${net_dev}/address"`
        echo "${macaddr} ${net_dev}" >> "${g_backup_network_info}"
    done
}

# 检查fstab文件，如果存在写/dev/sd[x]或者/dev/hd[x]的设备挂载，则会导致使用virtio后
# 设备变成/dev/vd[x]无法自动挂载的问题，这里检查出来就不安装vmtools了
check_fstab() {
    test -e "/etc/fstab" || return 0;

    if [ x"${g_backend_type}" != x"libguestfs" ];then
        # 目前非正常安装流程不检查该项
        return 0
    fi

    cat /etc/fstab | sed 's/^\s*//' | sed '/^#/d' | sed '/^[[:space:]]*$/d' |
    while read LINE
    do
        cur_line=`echo $LINE`
        cur_line=${cur_line:0:7}

        if [ x"/dev/sd" == x"${cur_line}" -o x"/dev/hd" == x"${cur_line}" ];then
           return 1
        fi
    done || return 1
    return 0
}

main(){
    local exit_code=0
    local user_input="no"
    #判断是否是root用户
    if [ $UID -ne 0 ]; then
        echo "Please re-run this program as the super user."            #提示信息，不删掉
        exit 1
    fi

    #初始化
    init

    # 判断是否会因为fstab导致安装vmtools后分区无法自动挂载
    check_fstab
    exit_code=$?
    if [ ${exit_code} -ne 0 ]; then
        echo "Error: The /etc/fstab file is not standard and does not support installation."
        # 只在libguestfish安装vmtools时检查此项
        exit_clean_env
    fi

    #判断内核版本是否支持
    is_support_kernel
    exit_code=$?
    if [ ${exit_code} -ne 0 ]; then
        echo "Error: It's not support the current kernel! The version of the at least >=${g_kernel_least_version}.${g_kernel_least_major_version}.${g_kernel_least_minor_version}"
        #内核版本不支持时，向HOST发送内核版本不支持的通知
        notify_to_host "KernelNotSuport"
        exit_clean_env
    fi

    #判断当前宿主机的操作系统大类rhel或者debian
    g_system_type=$(check_system_type)
    #添加对指定系统的补丁版本的检测
    support_msg=$(check_not_support_system)
    if [  -n "$support_msg"  ]; then
        echo $support_msg
        exit_clean_env
    fi
    update_system_rd_file
    exit_code=$?
    if [ ${exit_code} -ne 0 ];then
        echo "Update rd file failed!"          #提示信息，不删掉
        #安装失败时，向Host发送安装失败的通知
        #notify_to_host "InstallFail"
        #exit_clean_env
    fi

    #判断是否支持virtio
    is_support_virtio
    exit_code=$?
    if [ ${exit_code} -ne 0 ];then
        echo "Error: Current system is not support virtio!"                #提示信息，不删掉
        #内核不支持virtio时，向HOST发送内核不支持virito的通知
        notify_to_host "VirtioNotSuport"
        exit_clean_env
    fi

    #安装升级，报表和vm_proxyd
    chmod +x "${g_current_dir}/update_install" >/dev/null 2>&1
    "${g_current_dir}/update_install" 2>/dev/null
    exit_code=$?
    if [ ${exit_code} -ne 0 ];then
        echo "Install Update module failed!"          #提示信息，不删掉
        #安装失败时，向Host发送安装失败的通知
        notify_to_host "InstallFail"
        exit_clean_env
    fi

    #安装完成通知Host修改配置文件
    notify_to_host "InstallSuccess"
    if [ $? -ne 0 ]; then
        #这个通知host失败了也需要清理环境
        exit_clean_env
    fi

    # 若是rhel 5.x版本，通知关闭高性能模式
    check_close_high_performance
    exit_code=$?
    if [ ${exit_code} -eq 0 ]; then
        notify_to_host "CloseHighPerformance"
        if [ $? -ne 0 ]; then
            #这个通知host失败了也需要清理环境
            exit_clean_env
        fi
    fi

    # 备份当前网络设备名与mac地址的对应关系，便于安装virtio后修正网络配置中的网络
    # 设备名，详见virtio_nic_compat.sh
    backup_network_cfg

    #修改fstab
    change_fstabcfg

    #处理完成之后，使用sync强制写入磁盘
    sync >/dev/null 2>&1

    #完成
    echo "Everything is OK. Need to reboot!"       #调试，去掉
    #是否立即重启
    read -p "reboot now(yes/no)?" user_input
    case ${user_input} in
        "Y"|"y"|"yes"|"Yes"|"yEs"|"yeS"|"YEs"|"YeS"|"yES"|"YES")
        reboot;;
        *)
        echo "Please reboot later!";;
    esac
    exit 0
}

main