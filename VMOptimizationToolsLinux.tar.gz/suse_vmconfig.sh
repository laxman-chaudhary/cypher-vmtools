#!/bin/bash
# shellcheck disable=SC2154,SC2129
# 该文件使用了其他文件中的全局变量导致shellcheck检查不过， 屏蔽2154类型
# 重定向shellcheck建议的方式在多个管道连接的语句中不好改，重定向代码较多，屏蔽2129类型
shell_dir=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
. "${shell_dir}/vmconfig_common_func"

# set default route config
# param $1: ip_type
# param $2: gateway
# return 0(success),1(fail)
suse_set_default_route()
{
    local ip_type=$1
    local gateway=$2

    test -z "$gateway" && return
    check_iptype_is_ipv4_or_ipv6 "$ip_type"
    if [ $? -eq 1 ]; then
        log_error "ip_type $ip_type is not ipv4 or ipv6"
        return 1
    fi

    ipv6_gateway=`grep ":" "$g_suse_routes_config_file" |awk  -F" " '{if (NR==1) print $2}' | head -n 1`
    if [  x"$ipv6_gateway" == x"" ];then
        if [ x"$ip_type" == x"ipv4" ];then
            echo "default $gateway - -" > $g_suse_routes_config_file
        elif [ x"$ip_type" == x"ipv6" ];then
            echo "default $gateway - -" >> $g_suse_routes_config_file
        fi
    else
        if [ x"$ip_type" == x"ipv4" ];then
            echo "default $gateway - -" > $g_suse_routes_config_file
            echo "default $ipv6_gateway - -" >> $g_suse_routes_config_file
        elif [ x"$ip_type" == x"ipv6" ];then
            sed -i "s/$ipv6_gateway/$gateway/g" $g_suse_routes_config_file
        fi
    fi
    return 0
}

#更新suse的dns
update_suse_dns()
{
    local dns_list=$1
    local new_dns_list=""

    test -z "$dns_list" && return 1

    check_resolv_cfg_dns "$dns_list"
    if [ $? -eq 0 ];then
        log_info "config and resolv dns is same,dns:$dns_list"
        return 1
    fi

    for dns in $dns_list; do
        if [ x"$dns" == x"" ];then
            continue
        fi
        is_valid_ip_address "$dns"
        if [ $? -eq 0 ];then
            new_dns_list="$new_dns_list $dns"
        fi
    done
    #更换dns
    suse_change_dns_config "$new_dns_list"
    netconfig update -f >/dev/null 2>&1
}

#更改suse的dns配置文件
# param $1:new_dns_list
suse_change_dns_config()
{
    local new_dns_list=$1
    test -z "$new_dns_list" && return 1
    local new_config="NETCONFIG_DNS_STATIC_SERVERS=\"$new_dns_list\""

    log_info "change suse dns $new_config"
    sed -i "s/^\s*NETCONFIG_DNS_STATIC_SERVERS.*/$new_config/" $g_suse_netconfig_file
}

# 判断ip配置文件里面有无配置，有则进行拷贝
# param $1: ifname,eg. eth0
# param $2: ip_type
# param $3: 系统ip配置文件文件
# param $4：临时ip配置文件
backup_suse_cfg_ip_to_tmp()
{
    local ifname=$1
    local ip_type=$2
    local cfg_file=$3
    local ip_tmp_cfg_file=$4
    local ipv4_massage=""
    local ipv6_massage=""

    if [ x"$ip_type" == x"ipv4" ];then
        #判断如果有ipv6的信息
        ipv6_massage=`get_value_from_config "$cfg_file" "IPV6INIT"`
        if [ x"$ipv6_massage" != x"" ];then
            #将含有ipv6信息的内容拷贝到文件中
            log_info "ipv6  ${cfg_file}  ${ip_tmp_cfg_file}"
            # 创建网络配置临时文件时为了保证和原来配置属性一致采用复制方式创建
            cp -af $cfg_file $ip_tmp_cfg_file 2>/dev/null
            echo "" > ${ip_tmp_cfg_file}
            cat ${cfg_file} |awk  'BEGIN{RS="\n\n"}NR==1{print}' |grep -w IPV6INIT >> ${ip_tmp_cfg_file}
            cat ${cfg_file} |awk  'BEGIN{RS="\n\n"}NR==1{print}' |grep -w IPADDR_0 >> ${ip_tmp_cfg_file}
            cat ${cfg_file} |awk  'BEGIN{RS="\n\n"}NR==1{print}' |grep -w PREFIXLEN_0 >> ${ip_tmp_cfg_file}
        fi
    elif [ x"$ip_type" == x"ipv6" ];then
        #判断含有ipv4信息
        ipv4_massage=`get_value_from_config "$cfg_file" "IPADDR"`
        if [ x"$ipv4_massage" != x"" ];then
            #将含有ipv4信息的内容拷贝到文件中
            log_info "ipv4  ${cfg_file}  ${ip_tmp_cfg_file}"
            # 创建网络配置临时文件时为了保证和原来配置属性一致采用复制方式创建
            cp -af $cfg_file $ip_tmp_cfg_file 2>/dev/null
            echo "" > ${ip_tmp_cfg_file}
            cat ${cfg_file} |awk  'BEGIN{RS="\n\n"}NR==1{print}' |grep -w IPADDR >> ${ip_tmp_cfg_file}
            cat ${cfg_file} |awk  'BEGIN{RS="\n\n"}NR==1{print}' |grep -w NETMASK >> ${ip_tmp_cfg_file}
        fi
    else
        log_error "ip_type $ip_type is not ipv4 or ipv6"
        return 1
    fi
    return 0
}

# suse series system generate network config
# param $1: ifname,eg:eth0
# param $2: protocol,eg:dhcp|static
# param $3: ip,eg:192.168.100.100
# param $4: net mask,eg:255.255.255.0
# param $5: gateway,eg:192.168.100.1
# param $6: ip_type
# return 0(success),1(fail)
suse_gen_network_cfg_file()
{
    local ifname=$1
    local protocol=$2
    local ipaddr=$3
    local netmask=$4
    local gateway=$5
    local ip_type=$6
    local cfg_file="$g_suse_network_cfg_dir/ifcfg-$ifname"
    local ip_tmp_cfg_file="/tmp/suse-ip-ifcfg-$ifname"
    local ipv6_massage=""

    test -z "$ifname" && return 1
    if [ x"$protocol" != x"$PROTO_STATIC" ] && [ x"$protocol" != x"$PROTO_DHCP" ];then
        log_error "error,invalid proto $protocol"
        return 1
    fi
    log_info "config:{$ifname,$protocol,$ipaddr,$netmask,$gateway,$ip_type}"
    backup_suse_cfg_ip_to_tmp $ifname "$ip_type" "$cfg_file" "$ip_tmp_cfg_file"

    #判断是否存在ipv6的信息
    ipv6_massage=`get_value_from_config "$ip_tmp_cfg_file" "IPV6INIT"`
    if [ x"$ipv6_massage" != x"" ];then
        mv -f $ip_tmp_cfg_file $cfg_file
        echo "BOOTPROTO=$protocol" >> $cfg_file
    else 
        echo "BOOTPROTO=$protocol" > $cfg_file
    fi
    is_valid_inet_address $ipaddr
    if [ $? -eq 0 ];then
        echo "IPADDR=$ipaddr" >> $cfg_file
    fi

    is_valid_inet_address $netmask
    if [ $? -eq 0 ];then
        echo "NETMASK=$netmask" >> $cfg_file
    fi

    is_valid_inet_address $gateway
    if [ $? -eq 0 ];then
        suse_set_default_route "$ip_type" "$gateway"
    fi

    echo "STARTMODE='auto'" >> $cfg_file
    #关闭物理链路检测，网卡断开情况下保证设置ip成功
    echo "LINK_REQUIRED='no'" >> $cfg_file
    return 0
}

# suse series system generate network config
# param $1: ifname,eg:eth0
# param $2: protocol,eg:dhcp|static
# param $3: ipv6,eg:2001:d02::14:0:0:9
# param $4: ipv6_prefix,eg:64
# param $5: ipv6_gateway,eg:2001:d02::14:0:0:9
# param $6: ip类型 ipv4 or ipv6
# return 0(success),1(fail)
suse_gen_ipv6_network_cfg_file()
{
    local ifname=$1
    local protocol=$2
    local ipv6=$3
    local ipv6_prefix=$4
    local ipv6_gateway=$5
    local ip_type=$6
    local cfg_file="$g_suse_network_cfg_dir/ifcfg-$ifname"
    local ip_tmp_cfg_file="/tmp/suse-ip-ifcfg-$ifname"
    local ipv4_massage=""

    test -z "$ifname" && return 1
    if [ x"$protocol" != x"$PROTO_STATIC" ] && [ x"$protocol" != x"$PROTO_DHCP" ];then
        log_error "error,invalid proto $protocol"
        return 1
    fi
    backup_suse_cfg_ip_to_tmp $ifname "$ip_type" "$cfg_file" "$ip_tmp_cfg_file"
    #判断是否存在ipv4的信息
    ipv4_massage=`get_value_from_config "$ip_tmp_cfg_file" "IPADDR"`
    if [ x"$ipv4_massage" != x"" ];then
        mv -f $ip_tmp_cfg_file $cfg_file
        echo "IPV6INIT=yes" >> $cfg_file
    else
        echo "IPV6INIT=yes" > $cfg_file
    fi
    echo "BOOTPROTO=$protocol" >> $cfg_file

    is_valid_inet6_address $ipv6
    if [ $? -eq 0 ];then
        echo "IPADDR_0=$ipv6" >> $cfg_file
    fi
    is_valid_inet6_prefixlen $ipv6_prefix
    if [ $? -eq 0 ];then
        echo "PREFIXLEN_0=$ipv6_prefix" >> $cfg_file
    fi
    is_valid_inet6_address $ipv6_gateway
    if [ $? -eq 0 ];then
        suse_set_default_route "$ip_type" "$ipv6_gateway"
    fi
    echo "STARTMODE='auto'" >> $cfg_file
    #关闭物理链路检测，网卡断开情况下保证设置ip成功
    echo "LINK_REQUIRED='no'" >> $cfg_file
    return 0
}

# suse series system generate network config
# param $1: ifname,eg:eth0
# param $2: ipaddr,eg:2001:d02::14:0:0:9
# param $3: netmask,eg:64
# param $4: gateway,eg:2001:d02::14:0:0:9
# param $5: ip类型 ipv4 or ipv6
# return 0(success),1(fail)
suse_network_cfg_handle()
{
    local ifname=$1
    local ipaddr=$2
    local netmask=$3
    local gateway=$4
    local ip_type=$5
    local protocol=$PROTO_STATIC
    local config_file=""

    if test -z "$ifname";then
        log_error "ifname is needed"
        return 1
    fi

    check_iptype_is_ipv4_or_ipv6 "$ip_type"
    if [ $? -eq 1 ]; then
        log_error "ip_type $ip_type is not ipv4 or ipv6"
        return 1
    fi

    # 如果没有配置ip，获取接口当前的配置
    if test -z "$ipaddr";then
        config_file=${g_suse_network_cfg_dir}/ifcfg-$ifname
        if test -z "$config_file";then
            log_warn "ifname:$ifname config file is not exist"
            protocol=$PROTO_DHCP
        else
            protocol=`get_value_from_config "$config_file" "BOOTPROTO"`
            if test -z "$protocol";then
                protocol=$PROTO_STATIC
            fi
            if [ x"$ip_type" == x"ipv4" ];then
                ipaddr=`get_value_from_config "$config_file" "IPADDR"`
                netmask=`get_value_from_config "$config_file" "NETMASK"`
            elif [ x"$ip_type" == x"ipv6" ];then
                ipaddr=`get_value_from_config "$config_file" "IPADDR_0"`
                netmask=`get_value_from_config "$config_file" "PREFIXLEN_0"`
            fi
        fi
        log_info "[config]origin proto:$protocol,ip_type:$ip_type,ip:$ipaddr,netmask:$netmask,gateway:$gateway"
    fi

    # 配置中可能获取不到ip，通过命令获取
    if [ x"$PROTO_STATIC" == x"$protocol" ];then
        if test -z "$ipaddr" || test -z "$netmask";then
            log_warn "$ifname get config from cmd"
            if [ x"$ip_type" == x"ipv4" ];then
                ipaddr=`get_if_ip $ifname`
                netmask=`get_if_mask $ifname`
                gateway=`get_if_gateway $ifname`
            elif [ x"$ip_type" == x"ipv6" ];then
                ipaddr=`get_if_ipv6 $ifname`
                netmask=`get_if_ipv6_prefix_len $ifname`
                gateway=`get_if_ipv6_gateway $ifname`
            fi
            if test -z "$ipaddr" || test -z "$netmask";then
                log_warn "$ifname get ip info failed,use default proto (dhcp)"
                protocol=$PROTO_DHCP
            else
                protocol=$PROTO_STATIC
            fi
            
            log_info "[cmd]origin proto:$protocol,ip_type:$ip_type,ip:$ipaddr,netmask:$netmask,gateway:$gateway"
        fi
    fi

    if [ x"$ip_type" == x"ipv4" ];then
        suse_gen_network_cfg_file "$ifname" "$protocol" "$ipaddr" "$netmask" "$gateway" "$ip_type"
    elif [ x"$ip_type" == x"ipv6" ];then
        suse_gen_ipv6_network_cfg_file "$ifname" "$protocol" "$ipaddr" "$netmask" "$gateway" "$ip_type"
    fi

    # 若网卡未启用，则启用网卡
    ifconfig "$ifname" | grep "UP" -q
    if [ $? -ne 0 ]; then
        ifconfig "$ifname" up
    fi

    return 0
}
