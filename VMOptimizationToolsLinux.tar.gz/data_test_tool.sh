#!/bin/bash
shell_dir=`dirname "${BASH_SOURCE[0]}"`
proc_name=`basename "${BASH_SOURCE[0]}"`

declare SEND_INTERVAL=5						#the interval of send packet
declare GET_INFO_INTERVAL=5					#the frequency of get CPU,IO andm emory,get once five seconds
declare GET_DISK_INFO_INTERVAL=60			#the frequency of get disk information,get once every minute
declare GET_NETWORK_INFO_INTERVAL=600		#the frequency of get net card, get once ten minute
declare CPU_IO_MEM_COUNT_TIME=0				#the first time need to get CPU,IO,MEM
declare DISK_COUNT_TIME=60					#the first time need to get disk information
declare NETWORK_COUNT_TIME=600				#the first time need to get netcard information
declare CPU_INFO_FIRST=""					#save the old information of CPU
declare CPU_INFO_SECOND=""					#save the new information of CPU
declare IO_INFO_FIRST=""					#save the old information of IO
declare IO_INFO_SECOND=""					#save the new information of IO

declare FIRST_TIME=1
declare TITLE_PRINT=1
declare REAL=0
declare MSG_INFO_DATA=""
declare CPU_USAGE=0
declare RD_IOPS=0
declare RD_BYTEPS=0
declare WR_IOPS=0
declare WR_BYTEPS=0
declare MEMTOTAL=""
declare MEMUSED=""
declare DISK_TOTAL=""
declare DISK_USED=""
declare VNETDEVS=[]
declare MEM_USAGE=0
declare DISK_USAGE=0
declare TMP_DATE=""
declare DUID_IAID=""

#Get the os information of virtual machine
get_cpu_info()
{
	local array=`cat /proc/stat | head -n 1 | awk '{print $2" "$3" "$4" "$5" "$6" "$7" "$8}'`
	echo "$array";
}

#Get the information of CPU
get_diskio_info()
{
	local array=`cat /proc/diskstats | grep '[vsh]d[a-z][^1-9]' \
					| awk 'BEGIN{a=0;b=0;c=0;d=0}{a=(a"+"$4);b=(b"+"$6);c=(c"+"$8);d=(d"+"$10)}END{print a" "b" "c" "d}'`
	echo "$array";
}

#Get the information of disk IO
get_mem_usage()
{
	MEMTOTAL=`cat /proc/meminfo | grep MemTotal | awk -F" " '{print $2}'`
	MEMFREE=`cat /proc/meminfo | grep MemFree | awk -F" " '{print $2}'`
	local MEMBUFFERS=`cat /proc/meminfo | grep ^Buffers | awk -F" " '{print $2}'`
	local CACHED=`cat /proc/meminfo | grep ^Cached | awk -F" " '{print $2}'`
	MEMUSED=`expr ${MEMTOTAL} - ${MEMFREE} - ${MEMBUFFERS} - ${CACHED}`
	MEMTOTAL=`expr ${MEMTOTAL} \* 1024`
	MEMUSED=`expr ${MEMUSED} \* 1024`
	if [ ${MEMTOTAL} -lt ${MEMUSED} ]; then
		log "get_mem_usage wrong!"
		return 1;
	fi
	MEM_USAGE=`expr 100 \* ${MEMUSED} \/ ${MEMTOTAL}`;
	return 0;
}

#Get the usage of memory
get_disk_total()
{
	DISK_TOTAL=`cat /proc/partitions | grep [vsh]d[a-z]$ | awk 'BEGIN{a=0}{a=(a"+"$3)}END{print a}'`
	if [ ! "${DISK_TOTAL}" ]; then
		return 1;
	fi
	DISK_TOTAL=$((${DISK_TOTAL}))
	DISK_TOTAL=`expr ${DISK_TOTAL} \* 1024`
	return 0;
}

#Get the total size of disk
get_disk_used()
{
	#check whether the df command is exist
	type df >/dev/null 2>&1
	if [ $? -ne 0 ]; then
		log "check df failed!"
		return 1
	fi
	DISK_USED=`df -P | grep ^/dev | grep -E -v '^/dev/(fuse|loop|fstab|sr)' |awk '{print $1 " " $3}' |sort |uniq \
			|awk 'BEGIN{a=0}{a=(a"+"$2)}END{print a}'`
	if [ ! "${DISK_USED}" ]; then
		return 1;
	fi
	DISK_USED=$((${DISK_USED}))
	DISK_USED=`expr ${DISK_USED} \* 1024`
	return 0;
}

#Get the count of netcard
get_net_count()
{
	local net_count=`ls /sys/class/net/ -n | grep pci | wc -l`
	echo ${net_count}
}

#Get the name of netcard
get_net_name()
{
	local net_name=`ls /sys/class/net -n | grep pci |tr "/" " "| awk '{print $NF}'`
	if [ ! "${net_name}" ]; then
		return 1;
	fi
	echo "${net_name}"
	return 0;
}

get_net_pci_by_sys()
{
	local net_pci=`ls /sys/class/net/$1 -n |egrep -o \:[a-z0-9]{2}\:[a-z0-9]{2}\.[0-7] |tail -n 1 \
			|cut -d ":" -f 2-3 | tr [:.] " "`
	if [ ! "${net_pci}" ]; then 
		return 1;
	fi
	echo "${net_pci}"
	return 0;
}

get_net_pci_by_lspci()
{
	#check whether the lspci command is exist
	type lspci >/dev/null 2>&1
	if [ $? -ne 0 ]; then
		log "check lspci failed!"
		return 1
	fi
	local net_pci=`lspci | grep Eth | awk '{print $1}'|sed -n "${2}p" | tr [:.] " "`
	if [ ! "${net_pci}" ]; then
		return 1;
	fi
	echo "${net_pci}"
	return 0;
}

#Get the ipaddress of netcard
get_net_ip()
{
	local tmp_name=$1
	#check whether the ip command is exist
	type ip >/dev/null 2>&1
	if [ $? -ne 0 ]; then
		log "check ip failed!"
		return 1
	fi
	local ipaddrs=` ip addr ls ${tmp_name} |grep -o -E "([0-9]{1,3}\.){1,3}[0-9]{1,3}/[0-9]{1,2}" | cut -d '/' -f1 | xargs echo -n | tr ' ' ':'`
	echo "${ipaddrs}"
}

get_net_ipv6()
{
	local tmp_name=$1
	type ip >/dev/null 2>&1
	if [ $? -ne 0 ]; then
		log "check ip failed!"
		return 1
	fi
	#fe80::fcfc:feff:fede:f93e 或者 2001:db8:0:f101::1|fe80::fcfc:feff:fede:f93e
	local get_ipv6=` ip addr ls ${tmp_name} |awk '{if($1~/^inet6$/)print $2}'|awk -F/ '{print $1}' | sed '/^fe80/d'| xargs echo -n | tr ' ' '|'`   
	local ipv6=${get_ipv6//:/-}
	echo "$ipv6"
	return 0
}

#Get the information of netcard
get_net_info()
{
		local net_count=0
	net_count=`get_net_count`;
	#if the count of netcard is zero ,then return directly,the netcard field is set null
	if [ ${net_count} -eq 0 ]; then
		VNETDEVS=[]
		return 0;
	fi
	local net_name=""
	net_name=`get_net_name`
	if [ $? -eq 1 ]; then
		log "get_net_name failed" 
		return 1;
	fi
	local net_num=0;
	local tmp_name=""
	local tmpstr=""
	#get the PCI and ipaddress of every netcard
	for tmp_name in ${net_name}
	do
		net_num=$(($net_num + 1));
		#get pci of netcard
		tmpstr=`get_net_pci_by_sys ${tmp_name}`
		if [ $? -eq 1 ]; then
			tmpstr=`get_net_pci_by_lspci ${net_num}`
			if [ $? -eq 1 ]; then
				log "get_net_pci failed"
				return 1;
			fi
		fi
		#save the pci information
		local busNumber=""
		local devNumber=""
		local funcNumber=""
		local net_pci_bus=`echo "${tmpstr}" | cut -d " " -f 1`
		local net_pci_dev=`echo "${tmpstr}" | cut -d " " -f 2`
		local net_pci_func=`echo "${tmpstr}" | cut -d " " -f 3`
		((busNumber=16#${net_pci_bus}))
		((devNumber=16#${net_pci_dev}))
		((funcNumber=16#${net_pci_func}))
		#get the ipaddress of netcard
		local ipv4=""
		ipv4=`get_net_ip ${tmp_name}`
		if [ $? -ne 0 ]; then
			log "get_net_ip failed!"
			return 1
		fi
		local ipv6=""
		ipv6=`get_net_ipv6 ${tmp_name}`
		if [ -z "$ipv6" ]; then
			local ipaddrs="$ipv4"
		elif [ -z "$ipv4" ]; then
			local ipaddrs="$ipv6"
		else
			local ipaddrs="$ipv4|$ipv6"
		fi
		
		if [ ${net_num} -eq 1 ]; then
			VNETDEVS={\"busNumber\":${busNumber},\"devNumber\":${devNumber},\"funcNumber\":${funcNumber},\"ipaddrs\":\"${ipaddrs}\"}
			continue;
		fi
		VNETDEVS=${VNETDEVS}",{\"busNumber\":${busNumber},\"devNumber\":${devNumber},\"funcNumber\":${funcNumber},\"ipaddrs\":\"${ipaddrs}\"}"
	done
	#finaly ,add "[]" outside the VNETDEVS
	VNETDEVS="["${VNETDEVS}"]"
	return 0;
}

#get the information of disk
get_disk_info()
{
	#get the information of the total size of disk
	get_disk_total
	if [ $? -eq 1 ]; then
		log "get_disk_total failed"
		return 1;
	fi
	#get the usage of disk
	get_disk_used
	if [ $? -eq 1 ]; then
		log "get_disk_used failed"
		return 1;
	fi
	if [ ${DISK_TOTAL} -lt ${DISK_USED} ]; then
			log "get_disk wrong!"
			return 1;
	fi
	DISK_USAGE=`expr 100 \* ${DISK_USED} \/ ${DISK_TOTAL}`;
	return 0
}

#caculate the cpu usage and io
caculate_cpu_io()
{
	#caculate the usage of CPU
	local old_cpu_time=0
	local index=1
	local tmp_cpu=0
	for((index=1;index<8;index++))
	do
		tmp_cpu=`echo "${CPU_INFO_FIRST}" | cut -d " " -f $index`
		let " old_cpu_time = $tmp_cpu + $old_cpu_time "
	done
	local new_cpu_time=0
	tmp_cpu=0
	for((index=1;index<8;index++))
	do
		tmp_cpu=`echo "${CPU_INFO_SECOND}" | cut -d " " -f $index`
		let " new_cpu_time = $tmp_cpu + $new_cpu_time "
	done
	local cpu_total_diff=`expr $new_cpu_time - $old_cpu_time`
	local cpu_arr1=`echo "${CPU_INFO_FIRST}" | awk -F' ' '{print $4}'`
	local cpu_arr2=`echo "${CPU_INFO_SECOND}" | awk -F' ' '{print $4}'`
	local idle_time_diff=`expr $cpu_arr2 - $cpu_arr1`
	if [ $cpu_total_diff -eq 0 ]; then
		CPU_USAGE=0;
	else  
		CPU_USAGE=`expr 100 \* \( $cpu_total_diff - $idle_time_diff \) \/ \( $new_cpu_time - $old_cpu_time \)`;
	fi
	#caculate the Disk io
	local diskio1=`echo "${IO_INFO_FIRST}" | awk -F' ' '{print $1}'`
	diskio1=$((${diskio1}))
	local diskio2=`echo "${IO_INFO_SECOND}" | awk -F' ' '{print $1}'`
	diskio2=$((${diskio2}))
	RD_IOPS=`expr \( ${diskio2} - ${diskio1} \) \/ ${GET_INFO_INTERVAL}`;
	diskio1=`echo "${IO_INFO_FIRST}" | awk -F' ' '{print $2}'`
	diskio1=$((${diskio1}))
	diskio2=`echo "${IO_INFO_SECOND}" | awk -F' ' '{print $2}'`
	diskio2=$((${diskio2}))
	RD_BYTEPS=`expr \( ${diskio2} - ${diskio1} \) \/ ${GET_INFO_INTERVAL}`;
	RD_BYTEPS=$((${RD_BYTEPS}*512))
	diskio1=`echo "${IO_INFO_FIRST}" | awk -F' ' '{print $3}'`
	diskio1=$((${diskio1}))
	diskio2=`echo "${IO_INFO_SECOND}" | awk -F' ' '{print $3}'`
	diskio2=$((${diskio2}))
	WR_IOPS=`expr \( ${diskio2} - ${diskio1} \) \/ ${GET_INFO_INTERVAL}`;
	diskio1=`echo "${IO_INFO_FIRST}" | awk -F' ' '{print $4}'`
	diskio1=$((${diskio1}))
	diskio2=`echo "${IO_INFO_SECOND}" | awk -F' ' '{print $4}'`
	diskio2=$((${diskio2}))
	WR_BYTEPS=`expr \( ${diskio2} - ${diskio1} \) \/ ${GET_INFO_INTERVAL}`;
	WR_BYTEPS=$((${WR_BYTEPS}*512))
	return 0;
}

#Get the information of CPU USAGE,IO,MEMORY
get_cpu_io_mem_info()
{
	if [ ${CPU_IO_MEM_COUNT_TIME} -eq 0 ]; then
		CPU_INFO_FIRST=`get_cpu_info`
		IO_INFO_FIRST=`get_diskio_info`
		get_mem_usage
		if [ $? -ne 0 ]; then
			log "get_mem_usage failed"
			return 1
		fi
	fi
	if [ ${CPU_IO_MEM_COUNT_TIME} -ge ${GET_INFO_INTERVAL} ]; then
		CPU_INFO_SECOND=`get_cpu_info`
		IO_INFO_SECOND=`get_diskio_info`
		get_mem_usage
		if [ $? -ne 0 ]; then
			log "get_mem_usage failed"
			return 1
		fi
		caculate_cpu_io
		if [ $? -ne 0 ]; then
			log "caculate cpu io failed"
			return 1
		fi
		CPU_INFO_FIRST=${CPU_INFO_SECOND}
		IO_INFO_FIRST=${IO_INFO_SECOND}
		CPU_IO_MEM_COUNT_TIME=0
	fi
	let " CPU_IO_MEM_COUNT_TIME = ${SEND_INTERVAL} + CPU_IO_MEM_COUNT_TIME "
	return 0
}

#Get the report data of virtual machine
get_os_info()
{
	#Get the information of CPU USAGE,IO,MEMORY
	get_cpu_io_mem_info
	if [ $? -eq 1 ]; then
		log "get_cpu_diskio_usage failed"
		return 1;
	fi
	if [ ${DISK_COUNT_TIME} -ge ${GET_DISK_INFO_INTERVAL} ]; then
		#get the information of the usage  of disk
		get_disk_info
		if [ $? -eq 1 ]; then
			log "get_disk_info failed"
			return 1;
		fi
		DISK_COUNT_TIME=0
	fi
	let " DISK_COUNT_TIME = ${SEND_INTERVAL} + DISK_COUNT_TIME "
	if [ ${NETWORK_COUNT_TIME} -ge ${GET_NETWORK_INFO_INTERVAL} ]; then
		#get the information of netcard
		get_net_info
		if [ $? -eq 1 ]; then
			log "get_net_info failed"
			return 1;
		fi
		NETWORK_COUNT_TIME=0
	fi
	let " NETWORK_COUNT_TIME = ${SEND_INTERVAL} + NETWORK_COUNT_TIME "
	#获取guest端的duid
	get_duid_iaid_info
	if [ $? -eq 1 ]; then
		log "get_duid_iaid_info failed"
		return 1;
	fi
	return 0;
}

# 获取guest机的duid和iaid
# return 0(success),1(fail)
get_duid_iaid_info()
{
	local dhclient6_file_list=""
	local dhclient_file_list=""
	local all_dhclient_file_list=""
	local get_duid_iaid=""
	local dhclient_dir="/var/lib"

	dhclient6_file_list=`find $dhclient_dir -name dhclient6.leases 2>/dev/null`
	dhclient_file_list=`find $dhclient_dir -name dhclient.leases 2>/dev/null`
	if [ x"$dhclient6_file_list" == x"" ] && [ x"$dhclient_file_list" == x"" ]; then
		return 1
	fi

	all_dhclient_file_list="${dhclient6_file_list} ${dhclient_file_list}"

	for dhclient_file in $all_dhclient_file_list;do
		get_duid_iaid=`from_file_get_duid_iaid ${dhclient_file}`
		if [ x"$get_duid_iaid" != x"" ]; then
			break
		fi
	done
	DUID_IAID=$get_duid_iaid
	return 0
}

# 从文件中获取duid字段和每个网卡的iaid
# param $1: dhclient_file
# return 0(success),1(fail)
from_file_get_duid_iaid()
{
	local dhclient_file=$1
	local dhcp6_client_id=""
	local default_duid=""
	local duid=""
	local iaid=""

	if [ x"$dhclient_file" == x"" ];then
		log " no duid_dhclient6_file $dhclient_file"
		return 1
	fi

	dhcp6_client_id=`cat $dhclient_file | grep -a "dhcp6.client-id" | head -n 1 |awk -F" " '{print $3}' | sed "s/;//g"`
	if [ x"$dhcp6_client_id" == x"" ]; then
		return 1
	fi
	iaid=`from_file_get_iaid "$dhclient_file"`
	duid=`check_duid "$dhcp6_client_id"`

	echo "$duid$iaid"
	return 0
}

#从文件中获取iaid
# param $1: dhclient_file
# return 0(success),1(fail)
from_file_get_iaid()
{
	local dhclient_file=$1
	local tmp_name=""
	local tmpstr=""
	local new_iaid_list=""
	local net_name=""
	local net_num=0

	if [ x"$dhclient_file" == x"" ];then
		log " no dhclient_file $dhclient_file"
		return 1
	fi

	net_name=`get_net_name`
	if [ -z "$net_name" ]; then
		return 1
	fi

	for tmp_name in ${net_name}
	do
		if [ x"$tmp_name" == x"" ];then
			break
		fi
		net_num=$(($net_num + 1));
		#get pci of netcard
		tmpstr=`get_net_pci_by_sys ${tmp_name}`
		if [ $? -eq 1 ]; then
			tmpstr=`get_net_pci_by_lspci ${net_num}`
			if [ $? -eq 1 ]; then
				log "get_net_pci failed"
				return 1;
			fi
		fi
		#save the pci information
		local busNumber=""
		local devNumber=""
		local funcNumber=""
		local net_pci_bus=`echo "${tmpstr}" | cut -d " " -f 1`
		local net_pci_dev=`echo "${tmpstr}" | cut -d " " -f 2`
		local net_pci_func=`echo "${tmpstr}" | cut -d " " -f 3`
		((busNumber=16#${net_pci_bus}))
		((devNumber=16#${net_pci_dev}))
		((funcNumber=16#${net_pci_func}))
		local iaid=""
		iaid=`cat $dhclient_file | grep -i $tmp_name -A 1 | awk '{if (NR==2)print $2}' | sed "s/://g"`
		if [ x"$iaid" == x"" ]; then
			iaid=`ip addr show dev $tmp_name 2>/dev/null | awk '{if (NR==2)print $2}' | cut -d \: -f 3-6 | sed "s/://g"`
		fi
		new_iaid_list="${new_iaid_list}|$busNumber-$devNumber-$funcNumber|$iaid"
	done

	echo "$new_iaid_list"
	return 0
}
#修改duid补0
# param $1: duid
# return 0(success),1(fail)
check_duid()
{
	local duid=$1
	local new_duid_list=""
	local old_duid_list=""
	local new_duid=""

	if [ x"$duid" == x"" ];then
		log "duid none"
		return 1
	fi
	old_duid_list=`echo $duid | sed "s/:/ /g"`
	for get_duid in $old_duid_list;do
		if [[ $get_duid  =~ ^[0-9a-fA-F]{1}$ ]];then
			new_duid="0$get_duid"
		elif [[ $get_duid  =~ ^[0-9a-fA-F]{2}$ ]];then
			new_duid="$get_duid"
		else
			log "duid is invaild"
			return 1
		fi
		new_duid_list="$new_duid_list$new_duid"
	done
	echo $new_duid_list
	return 0
}


print_to_screen()
{
	TMP_DATE=`date +%m/%d-%H:%M:%S`
	# MSG_INFO_DATA="${TMP_DATE}		  ${CPU_USAGE}	${MEM_USAGE}  ${DISK_USAGE}	 ${RD_BYTEPS}  ${WR_BYTEPS}	 ${RD_IOPS}	 ${WR_IOPS}	 ${VNETDEVS}"
	if [ ${TITLE_PRINT} -eq 1 ]; then
		echo "	 time		   cpu	mem	 disk  rd_bytes	 wr_bytes  rd_iops	wr_iops	 duid_iaid  ip"
		TITLE_PRINT=0
	fi
	#echo ${MSG_INFO_DATA}
	echo "${TMP_DATE}	 ${CPU_USAGE}	${MEM_USAGE}	${DISK_USAGE}	   ${RD_BYTEPS}		   ${WR_BYTEPS}		  ${RD_IOPS}		${WR_IOPS}		  ${DUID_IAID}		 ${VNETDEVS}"
	return 0
}

save_to_file()
{
	TMP_DATE=`date +%m/%d-%H:%M:%S`
	# MSG_INFO_DATA="${TMP_DATE}	 ${CPU_USAGE}	 ${MEM_USAGE}	 ${DISK_USAGE}	  ${RD_BYTEPS}	  ${WR_BYTEPS}	   ${RD_IOPS}	 ${WR_IOPS}		 ${VNETDEVS}"
	if [ ${TITLE_PRINT} -eq 1 ]; then
		echo "	 time		   cpu	mem	 disk  rd_bytes	 wr_bytes  rd_iops	wr_iops	 duid_iaid  ip" >> "${shell_dir}/tmp_data.txt"
		TITLE_PRINT=0
	fi
	echo "${TMP_DATE}	 ${CPU_USAGE}	${MEM_USAGE}	${DISK_USAGE}	   ${RD_BYTEPS}		   ${WR_BYTEPS}		  ${RD_IOPS}		${WR_IOPS}		  ${DUID_IAID}		 ${VNETDEVS}" >> "${shell_dir}/tmp_data.txt"
	return 0
}

#Get data once
get_os_info_twice()
{
	get_os_info
	if [ $? -eq 1 ]; then
		log "get_os_info failed"
		return	1
	fi
	sleep ${SEND_INTERVAL}
	get_os_info
	if [ $? -eq 1 ]; then
		log "get_os_info failed"
		return	1
	fi
	print_to_screen || return 1
	return 0
}

#Get data immediately and print to screen
get_os_info_real()
{
	while true
	do
		if [ ${FIRST_TIME} -eq 1 ]; then
			get_os_info || return 1
			FIRST_TIME=0
		else
			get_os_info || return 1
			print_to_screen || return 1
		fi
		sleep ${SEND_INTERVAL}
	done
}

#Save the data into the file,ignore the first data,is default value
save_os_info()
{
	if [ ${FIRST_TIME} -eq 1 ]; then
		get_os_info || return 1
		FIRST_TIME=0
	else
		get_os_info || return 1
		save_to_file || return 1
	fi
	sleep ${SEND_INTERVAL}
	return 0
}

#print data
print_os_info()
{
	if [ $# -eq 1 ]; then
		#Requires two comparative data to calculate correctly
		get_os_info_twice || return 1
	else
		get_os_info_real || return 1
	fi
	return 0
}

#When printing multiple data first need to be ignored, because the first part of the default data 
#there is to do a comparison of the data in order to calculate after
main()
{
	if [ ${REAL} -eq 1 ]; then
		#print immediately
		print_os_info || return 1
	else
		if [ $1 -eq 1 ]; then
			#print once
			print_os_info $1 || return 1
		else
			echo "" > "${shell_dir}/tmp_data.txt"
			for((i=1;i<=$1+1;i++)); do
				#Saved to a file several times, the first time the data is not saved
				save_os_info || return 1
			done
		fi
	fi
	return 0
}

if [ $# -eq 0 ] || [ x"$1" = x'-h' ]; then
	echo "Usage: ./${proc_name} [OPTIONS] OBJECT "
	echo "		 OBJECT	 := n(type the number of times, use with -c option)"
	echo "		 OPTIONS := { -h[Help] | -c[count] | -r[real time]}"
elif [ $# -eq 1 ] && [ x"$1" = x'-r' ]; then
	REAL=1;
	main || echo "main failed!"
elif [ $# -eq 2 ] && [ x"$1" = x'-c' ]; then
	main $2 || echo "main failed!"
else
	echo "wrong parameters!"
fi
