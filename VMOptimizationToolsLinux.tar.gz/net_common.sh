#!/bin/bash

get_net_count()
{
    local net_list=$(ls /sys/class/net)
    local net_count=0

    for net in $net_list;do
        ls /sys/class/net/${net} -n | grep -q "pci" 2>/dev/null
        if [ $? -eq 0 ];then
            net_count=$((net_count + 1))
            continue
        fi

        ls /sys/class/net/${net}/device -n 2>/dev/null | grep -q "virtio"
        [ $? -eq 0 ] && net_count=$((net_count + 1))
    done

    echo ${net_count}
}

#Get the name of netcard
get_net_name()
{
    local net_name=""
    local net_list=$(ls /sys/class/net)

    for net in $net_list;do
        ls /sys/class/net/${net} -n | grep -q "pci" 2>/dev/null
        if [ $? -eq 0 ];then
            net_name="${net_name} ${net}"
            continue
        fi

        ls /sys/class/net/${net}/device -n 2>/dev/null | grep -q "virtio"
        [ $? -eq 0 ] && net_name="${net_name} ${net}"
    done

    echo "${net_name}"
}
