#!/bin/bash
# shellcheck disable=SC2154,SC2129
# 该文件使用了其他文件中的全局变量导致shellcheck检查不过， 屏蔽2154类型
# 重定向shellcheck建议的方式在多个管道连接的语句中不好改，重定向代码较多，屏蔽2129类型
shell_dir=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
. "${shell_dir}/vmconfig_common_func"

#备份的网络配置路径，此配置在安装vmtools时由vmtools-install.sh生成
#格式为：网卡物理地址 网卡设备名
declare g_sangfor_cfg_dir="/etc/sangfor"
declare g_backup_network_info="${g_sangfor_cfg_dir}/sangfor_network_info.bak"

# 判断ip配置文件里面有无配置，有则进行拷贝
# param $1: ifname,eg. eth0
# param $2: ip类型 ipv4 or ipv6
# param $3: 网卡配置文件
# param $4: 网卡配置临时文件
#success 0;fail 1
backup_redhat_cfg_ip_to_tmp()
{
    local ifname=$1 
    local ip_type=$2
    local cfg_file=$3
    local ip_tmp_cfg_file=$4
    local ipv4_massage=""
    local ipv6_massage=""

    if [ x"$ip_type" == x"ipv4" ];then
        #判断如果有ipv6的信息
        ipv6_massage=`get_value_from_config "$cfg_file" "IPV6INIT"`
        if [ x"$ipv6_massage" != x"" ];then
            #将含有ipv6信息的内容拷贝到文件中
            log_info "ipv6  ${cfg_file}  ${ip_tmp_cfg_file}"
            # 创建网络配置临时文件时为了保证和原来配置属性一致采用复制方式创建
            cp -af $cfg_file $ip_tmp_cfg_file 2>/dev/null
            echo "" > ${ip_tmp_cfg_file}
            cat ${cfg_file} |awk  'BEGIN{RS="\n\n"}NR==1{print}' |grep IPV6INIT >> ${ip_tmp_cfg_file}
            cat ${cfg_file} |awk  'BEGIN{RS="\n\n"}NR==1{print}' |grep IPV6ADDR >> ${ip_tmp_cfg_file}
            cat ${cfg_file} |awk  'BEGIN{RS="\n\n"}NR==1{print}' |grep PREFIXLEN >> ${ip_tmp_cfg_file}
            cat ${cfg_file} |awk  'BEGIN{RS="\n\n"}NR==1{print}' |grep IPV6_DEFAULTGW >> ${ip_tmp_cfg_file}   
        fi
    elif [ x"$ip_type" == x"ipv6" ];then
        #判断含有ipv4信息
        ipv4_massage=`get_value_from_config "$cfg_file" "IPADDR"`
        if [ x"$ipv4_massage" != x"" ];then
            #将含有ipv4信息的内容拷贝到文件中
            log_info "ipv4  ${cfg_file}  ${ip_tmp_cfg_file}"
            # 创建网络配置临时文件时为了保证和原来配置属性一致采用复制方式创建
            cp -af $cfg_file $ip_tmp_cfg_file 2>/dev/null
            echo "" > ${ip_tmp_cfg_file}
            cat ${cfg_file} |awk  'BEGIN{RS="\n\n"}NR==1{print}' |grep IPADDR >> ${ip_tmp_cfg_file}
            cat ${cfg_file} |awk  'BEGIN{RS="\n\n"}NR==1{print}' |grep NETMASK >> ${ip_tmp_cfg_file}
            cat ${cfg_file} |awk  'BEGIN{RS="\n\n"}NR==1{print}' |grep GATEWAY >> ${ip_tmp_cfg_file}
        fi
    else
        log_error "ip_type $ip_type is not ipv4 or ipv6"
        return 1
    fi
    return 0
}

#此函数的最终目的是找出对应网卡相对应的ip信息配置文件，传进来的信息只是网卡名，先是根据网卡名找出对应的ip配置文件，然后比较ip配置文件里面ip信息与使用命令获取到的ip
# get the current config file of interface
# param $1: ifname,eg. eth0
# param $2: ip类型 ipv4 or ipv6
# output: config file name
# return 0(success),1(fail)
redhat_get_config_file()
{
    local ifname=$1
    local ip_type=$2
    local ipaddr=""
    local netmask=""
    local prefix=""
    local cfg_ip=""
    local cfg_mask=""
    local cfg_prefix=""
    local first_file=""
    local check_cur_ip_exist=""

    test -z "$ifname" && return 1
    check_iptype_is_ipv4_or_ipv6 "$ip_type"
    if [ $? -eq 1 ]; then
        log_error "ip_type $ip_type is not ipv4 or ipv6"
        return 1
    fi

    # shellcheck disable=SC2231
    for file in  ${g_redhat_network_cfg_dir}/ifcfg-*
    do
        device=`get_value_from_config "$file" "DEVICE"`
        if [ x"$ifname" != x"$device" ];then
            continue
        fi

        if test -z "$first_file";then
            first_file="$file"
        fi
        if [ x"$ip_type" == x"ipv4" ];then
            ipaddr=`get_if_ip "$ifname"`
            netmask=`get_if_mask "$ifname"`
            test -z "$netmask" && break
            test -z "$ipaddr" && break
            prefix=`mask2cdr "${netmask}"`
            cfg_ip=`get_value_from_config "$file" "IPADDR"`
            cfg_mask=`get_value_from_config "$file" "NETMASK"`
            cfg_prefix=`get_value_from_config "$file" "PREFIX"`

            if [ x"${cfg_ip}" != x"${ipaddr}" ];then
                continue
            fi
            if [ x"${cfg_mask}" != x"${netmask}" ] && [ x"${cfg_prefix}" != x"${prefix}" ];then
                continue
            fi
        elif [ x"$ip_type" == x"ipv6" ];then
            cfg_ip=`get_value_from_config "$file" "IPV6ADDR"`
            cfg_prefix=`get_value_from_config "$file" "PREFIXLEN"`
            get_if_ipv6_and_prefixlen "$ifname" "${cfg_ip}/${cfg_prefix}"
            check_cur_ip_exist=$?
            if [ ${check_cur_ip_exist} -eq 1 ];then
                continue
            fi
        fi 
        echo $file
        return 0
    done
    echo "$first_file"
    return 1
}

# 判断系统版本是否大于8
is_after_centos8()
{
    local version=`cat /etc/redhat-release | awk '{print $4}'`
    if [[ x"$version" > x"8" ]]; then
        return 0
    fi
    return 1
}

# redhat series system generate network config
# param $1: ifname,eg:eth0
# param $2: protocol,eg:dhcp|static
# param $3: ip,eg:192.168.100.100
# param $4: net mask,eg:255.255.255.0
# param $5: gateway,eg:192.168.100.1
# param $6: mac address,eg:FE:FC:FE:66:82:32
# param $7: ip类型 ipv4 or ipv6
# return 0(success),1(fail)
redhat_gen_network_cfg_file()
{
    local ifname=$1
    local protocol=$2
    local ipaddr=$3
    local netmask=$4
    local gateway=$5
    local macaddr=$6
    local ip_type=$7
    local cfg_file="$g_redhat_network_cfg_dir/ifcfg-$ifname"
    local ip_tmp_cfg_file="/tmp/redhat-ip-ifcfg-$ifname"
    local ipv6_massage=""

    test -z "$ifname" && return 1
    if [ x"$protocol" != x"$PROTO_STATIC" ] && [ x"$protocol" != x"$PROTO_DHCP" ];then
        log_error "error,invalid proto $protocol"
        return 1
    fi
    #Fix TD 87612, centos6.5设置配置时候需要设置网卡的MAC地址，因为centos6.5的NetworkManager服务是根据MAC地址设置指定网卡。没有设置的话，可能其他网卡也会用。
    is_valid_mac_address "$macaddr"
    if [ $? -ne 0 ];then
        log_error "[redhat_gen_network_cfg_file]error,macaddr is not valid for ${ifname} : ${macaddr}"
        return 1
    fi
    log_info "config:{$ifname,$protocol,$ipaddr,$netmask,$gateway}"
    backup_redhat_cfg_ip_to_tmp "$ifname" "$ip_type" "$cfg_file" "$ip_tmp_cfg_file"

    #判断是否存在ipv6的信息
    ipv6_massage=`get_value_from_config "$ip_tmp_cfg_file" "IPV6INIT"`
    if [ x"$ipv6_massage" != x"" ];then
        mv -f $ip_tmp_cfg_file $cfg_file
        echo "TYPE=Ethernet" >> $cfg_file
    else
        echo "TYPE=Ethernet" > $cfg_file
    fi
    echo "DEVICE=$ifname" >> $cfg_file
    echo "BOOTPROTO=$protocol" >> $cfg_file
    echo "ONBOOT=yes" >> $cfg_file
    echo "NAME=$ifname" >> $cfg_file
    # macaddr 上面校验了有效性，这里不需要检查了
    echo "HWADDR=$macaddr" >> $cfg_file
    # dns不写入网卡中，加此参数是防止重启网络，制空dns文件中的dns
    echo "PEERDNS=no" >> $cfg_file
    if ! is_after_centos8; then
        # 此参数是避免networkmanger的影响，在centos7.0版本，
        #ifdown ifup会因networkmanger出现ip不生效，关闭networkmanger之后，修改ip会生效
        echo "NM_CONTROLLED=no" >> $cfg_file
    fi

    is_valid_inet_address $ipaddr
    if [ $? -eq 0 ];then
        echo "IPADDR=$ipaddr" >> $cfg_file
    fi

    is_valid_inet_address $netmask
    if [ $? -eq 0 ];then
        echo "NETMASK=$netmask" >> $cfg_file
    fi

    is_valid_inet_address $gateway
    if [ $? -eq 0 ];then
        echo "GATEWAY=$gateway" >> $cfg_file
    fi

    metric=`cat /proc/net/dev |sed -n  "/$ifname:/="`
    if ! test -z "$metric";then
        echo "METRIC=10$metric" >> $cfg_file
    fi

    return 0
}

#生成ipv6的配置文件,一种情况是如果同一个网卡，ipv4与ipv6同时设置的话，会先保存ipv4的配置，再添加ipv6的信息
#另一种情况是如果同一个网卡，只设置ipv6的话，会直接覆盖对应网卡的配置
# redhat series system generate network config
# param $1: ifname,eg:eth0
# param $2: protocol,eg:dhcp|static
# param $3: ipv6,eg:2001:d02::14:0:0:9
# param $4: ipv6_prefix,eg:64
# param $5: ipv6_gateway,eg:2001:d02::14:0:0:9
# param $6: mac address,eg:FE:FC:FE:66:82:32
# param $7: ip类型 ipv4 or ipv6
# return 0(success),1(fail)
redhat_gen_ipv6_network_cfg_file(){
    local ifname=$1
    local protocol=$2
    local ipv6=$3
    local ipv6_prefix=$4
    local ipv6_gateway=$5
    local macaddr=$6
    local ip_type=$7
    local cfg_file="$g_redhat_network_cfg_dir/ifcfg-$ifname"
    local ip_tmp_cfg_file="/tmp/redhat-ip-ifcfg-$ifname"
    local ipv4_massage=""

    test -z "$ifname" && return 1
    if [ x"$protocol" != x"$PROTO_STATIC" ] && [ x"$protocol" != x"$PROTO_DHCP" ];then
        log_error "error,invalid proto $protocol"
        return 1
    fi
    is_valid_mac_address "$macaddr"
    if [ $? -ne 0 ];then
        log_error "[redhat_gen_network_cfg_file]error,macaddr is not valid for ${ifname} : ${macaddr}"
        return 1
    fi
    log_info "config:{$ifname,$protocol,$ipv6,$ipv6_prefix,$ipv6_gateway}"
    backup_redhat_cfg_ip_to_tmp "$ifname" "$ip_type" "$cfg_file" "$ip_tmp_cfg_file"

    #判断是否存在ipv4的信息
   ipv4_massage=`get_value_from_config "$ip_tmp_cfg_file" "IPADDR"`
    if [ x"$ipv4_massage" != x"" ];then
        mv -f $ip_tmp_cfg_file $cfg_file
        echo "IPV6INIT=yes" >> $cfg_file
    else 
        echo "IPV6INIT=yes" > $cfg_file
    fi
    metric=`cat /proc/net/dev |sed -n  "/$ifname:/="`
    if ! test -z "$metric";then
        echo "METRIC=10$metric" >> $cfg_file
    fi
    echo "TYPE=Ethernet" >> $cfg_file
    echo "DEVICE=$ifname" >> $cfg_file
    echo "ONBOOT=yes" >> $cfg_file
    echo "NAME=$ifname" >> $cfg_file
    echo "BOOTPROTO=$protocol" >> $cfg_file
    echo "HWADDR=$macaddr" >> $cfg_file
    # dns不写入网卡中，加此参数是防止重启网络，制空dns文件中的dns
    echo "PEERDNS=no" >> $cfg_file

    if ! is_after_centos8; then
        echo "NM_CONTROLLED=no" >> $cfg_file
    fi
    is_valid_inet6_address $ipv6
    if [ $? -eq 0 ];then
        echo "IPV6ADDR=$ipv6" >> $cfg_file
    fi
    is_valid_inet6_prefixlen $ipv6_prefix
    if [ $? -eq 0 ];then
        echo "PREFIXLEN=$ipv6_prefix" >> $cfg_file
    fi
    is_valid_inet6_address $ipv6_gateway
    if [ $? -eq 0 ];then
        echo "IPV6_DEFAULTGW=$ipv6_gateway" >> $cfg_file
    fi

    # 禁用IPv6自动配置
    if [ x"$protocol" == x"$PROTO_STATIC" ];then
        echo "IPV6_AUTOCONF=no" >> $cfg_file
    fi
}

# redhat network cfg handle
# param $1: ifname,eg:eth0
# param $2: ip,eg:192.168.100.100 or 1002:1:
# param $3: net mask,eg:255.255.255.0
# param $4: gateway,eg:192.168.100.1
# param $5: ip类型 ipv6 or ipv4
# param $6: macaddr, eg:FE:FC:FE:66:82:31
# return 0(success),1(fail)
redhat_network_cfg_handle()
{
    local ifname=$1
    local ipaddr=$2
    local netmask=$3
    local gateway=$4
    local ip_type=$5
    local macaddr=$6
    local protocol=$PROTO_STATIC
    local method=""
    local cur_config_file=""
    local prefix=""

    if test -z "$ifname";then
        log_error "ifname is needed"
        return 1
    fi
    check_iptype_is_ipv4_or_ipv6 "$ip_type"
    if [ $? -eq 1 ]; then
        log_error "ip_type $ip_type is not ipv4 or ipv6"
        return 1
    fi
    if test -z "$macaddr";then
        log_error "[redhat_network_cfg_handle]macaddr is needed for ${ifname}"
        return 1
    fi

    # 如果没有配置ip，获取接口当前的配置
    if test -z "$ipaddr";then
        method=`nmcli_get_config_ip_method $ifname "$ip_type"`
        if ! test -z "$method";then
            if [ x"$method" == x"manual" ] || [ x"$method" == x"auto" ];then
                protocol=$PROTO_STATIC
                ipaddr=`nmcli_get_config_ip "$ifname" "$ip_type"`
                netmask=`nmcli_get_config_mask "$ifname" "$ip_type"`
                gateway=`nmcli_get_config_gateway "$ifname" "$ip_type"` 
            else
                protocol=$PROTO_DHCP
            fi
            log_info "[nmcli]origin proto:$protocol,ip_type:$ip_type,ip:$ipaddr,netmask:$netmask,gateway:$gateway"
        else
            cur_config_file=`redhat_get_config_file "$ifname" "$ip_type"`
            if test -z "$cur_config_file";then
                log_warn "ifname:$ifname ip_type:$ip_type config file is not exist"
                protocol=$PROTO_DHCP
            else
                log_debug "ifname:$ifname ip_type:$ip_type config file is $cur_config_file"
                protocol=`get_value_from_config "$cur_config_file" "BOOTPROTO"`
                if test -z "$protocol";then
                    protocol=$PROTO_STATIC
                fi
                if [ x"$ip_type" == x"ipv4" ];then
                    ipaddr=`get_value_from_config "$cur_config_file" "IPADDR"`
                    netmask=`get_value_from_config "$cur_config_file" "NETMASK"`
                    if test -z "$netmask";then
                        prefix=`get_value_from_config "$file" "PREFIX"`
                        if ! test -z "$prefix";then
                            netmask=`cdr2mask ${prefix}`
                        fi
                    fi
                    gateway=`get_value_from_config "$cur_config_file" "GATEWAY"`
                elif [ x"$ip_type" == x"ipv6" ];then
                    ipaddr=`get_value_from_config "$cur_config_file" "IPV6ADDR"`
                    netmask=`get_value_from_config "$cur_config_file" "PREFIXLEN"`
                    gateway=`get_value_from_config "$cur_config_file" "IPV6_DEFAULTGW"`
                fi
                log_info "[config]origin proto:$protocol,ip_type:$ip_type,ip:$ipaddr,netmask:$netmask,gateway:$gateway"
            fi
        fi
    fi

    # 配置中可能获取不到ip，通过命令获取
    if [ x"$PROTO_STATIC" == x"$protocol" ];then
        if test -z "$ipaddr" || test -z "$netmask";then
            log_warn "$ifname ip_type:$ip_type get config from cmd"
            if [ x"$ip_type" == x"ipv4" ];then
                ipaddr=`get_if_ip $ifname`
                netmask=`get_if_mask $ifname`
                gateway=`get_if_gateway $ifname`
            elif [ x"$ip_type" == x"ipv6" ];then
                ipaddr=`get_if_ipv6 $ifname`
                netmask=`get_if_ipv6_prefix_len $ifname`
                gateway=`get_if_ipv6_gateway $ifname`
            fi
            if test -z "$ipaddr" || test -z "$netmask";then
                log_warn "$ifname get ip_type:$ip_type ip info failed,use default proto (dhcp)"
                protocol=$PROTO_DHCP
            else
                protocol=$PROTO_STATIC
            fi

            log_info "[cmd]origin proto:$protocol,ip_type:$ip_type,ip:$ipaddr,netmask:$netmask,gateway:$gateway"
        fi
    fi
    if [ x"$ip_type" == x"ipv4" ];then
        redhat_gen_network_cfg_file "$ifname" "$protocol" "$ipaddr" "$netmask" "$gateway" "${macaddr}" "$ip_type"
    elif [ x"$ip_type" == x"ipv6" ];then
        redhat_gen_ipv6_network_cfg_file "$ifname" "$protocol" "$ipaddr" "$netmask" "$gateway" "${macaddr}" "$ip_type"

        if [ "$protocol" == "$PROTO_STATIC" ];then
            # 禁用自动获取ipv6
            disable_ipv6_autoconf_to_sysctl_conf "$ifname"
        else
            # 清理之前添加的禁用自动获取ipv6的配置
            clean_ipv6_autoconf_from_sysctl_conf "$ifname"
        fi
    fi
    return 0
}

# 问题: 安装virito后，centos7及redhat7等系统的网络设备名会发生变化，比如，由ens18改为eth0
#       如果其网络配置ifcfg-ens18中记录了DEVICE=ens18，则在切换为virtio网卡后会出现找不到
#       设备的问题
# 引发问题：在低版本vmtools对以上问题的处理中，如果用户再编辑下ip，编辑的ip会被写入到ifcfg-eth0
#          文件中，导致ifcfg-ens18与ifcfg-eth0的ip冲突
# 功能：将出现ifcfg-ens18中device=eth0，而且ifcfg-eth0中也存在device=eth0的情况，做删除ens中device操作
deal_interface_cfg_device_conflict()
{
    # 没有找到备份信息时也不做兼容性处理
    if [ ! -e "${g_backup_network_info}" ]; then
        return 1
    fi

    local backup_net_info=""
    local ens_interface=""
    local network_cfg_path="/etc/sysconfig/network-scripts"
    local network_ens_cfg_file=""
    local network_eth_cfg_file=""
    local eth_ifname=""
    local ens_interfaces=""

    ens_interfaces=`cat $g_backup_network_info | awk '{print $2}' | grep ens`
    if [ x"$ens_interfaces" == x"" ];then
        return 1
    fi
    for ens_interface in $ens_interfaces; do
        network_ens_cfg_file="$network_cfg_path/ifcfg-$ens_interface"
        # 获取ens配置中的device eg:eth0
        eth_ifname=`cat $network_ens_cfg_file | grep "DEVICE" | grep "eth" | awk -F= '{print $2}'`
        if [ x"$eth_ifname" == x"" ];then
            continue
        fi
        network_eth_cfg_file="$network_cfg_path/ifcfg-$eth_ifname" 
        # 如果文件存在
        if [ -f "$network_eth_cfg_file" ];then
            log_info "del $eth_ifname device"
            sed -i "/DEVICE/d" $network_ens_cfg_file
        else
            # 将NAME的ens改为eth
            sed -i "s/$ens_interface/$eth_ifname/g" $network_ens_cfg_file
            # 将ens文件名改为eth文件名
            log_info "$eth_ifname mv $network_ens_cfg_file $network_eth_cfg_file"
            mv -f $network_ens_cfg_file $network_eth_cfg_file 2>/dev/null
        fi
    done
    return 0
}

# 处理redhat的网卡参数
redhat_network_cfg_handle_once()
{
    local flag=""

    flag=`cat $shell_dir/network_compat_flag | grep "redhat_handle_once" | awk -F= '{print $2}' 2>/dev/null`
    if [ x"$flag" == x"1" ];then
        return 1
    fi
    #处理ens网卡的问题
    deal_interface_cfg_device_conflict
    echo "redhat_handle_once=1" >> "$shell_dir/network_compat_flag" 2>/dev/null

    return 0
}

# 处理redhat的dns
clear_redhat_net_config_dns()
{
    local net_name=$1
    local network_cfg_path="/etc/sysconfig/network-scripts"
    local dns1=""
    local dns2=""
    local network_ifcfg_file=""
    local dns_list=""
    local all_dns_list=""
    local three_dns=""

    test -z "$net_name" && return 1

    for net in $net_name; do
        network_ifcfg_file="$network_cfg_path/ifcfg-$net"
        if [ ! -e "$network_ifcfg_file" ];then
            continue
        fi
        dns1=`cat $network_ifcfg_file 2>/dev/null | grep "DNS1" | awk -F= '{print $2}'`
        dns2=`cat $network_ifcfg_file 2>/dev/null | grep "DNS2" | awk -F= '{print $2}'`
        if [ x"$dns1" != x"" ];then
            sed -i "/DNS1/d" $network_ifcfg_file
        fi
        if [ x"$dns2" != x"" ];then
            sed -i "/DNS2/d" $network_ifcfg_file
        fi
        dns_list=`joint_dns "$dns1" "$dns2"`
        if [ x"$dns_list" == x"" ];then
            continue
        else
            all_dns_list="$all_dns_list $dns_list"
            #去掉字符串首尾空格(如果不去掉，cut用法不会过滤掉空格，取不到想要取的字符串)
            all_dns_list=`echo "$all_dns_list" | awk '{gsub(/^\s+|\s+$/, "");print}'`
        fi
    done
    #获取前面三个dns
    three_dns=`get_three_dns "$all_dns_list"`
    echo $three_dns
}
