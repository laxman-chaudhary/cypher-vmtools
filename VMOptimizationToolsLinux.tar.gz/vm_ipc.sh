#!/bin/bash

# The file for the virtual machine communication interface

. "`dirname \"$0\"`/log.sh"
. "`dirname \"$0\"`/common_config.sh"

# The structure of the definition of data packet
declare  -r BEGIN_TAG__="#SaNgFoR_BeGiN#"
declare  -r END_TAG__="#sAnGfOr_eNd#"
declare  -r LENGTH_TAG__="LeNgTh:"
declare  -r TUNNELHDR_TAG__="TuNnEl_HdR:"
declare  -r MSGDATA_TAG__="MsGDaTa:"

# Module ID registration
declare g_my_modid__=0
# Register the instance of ID
declare g_my_instid__=0
# The message callback array register
declare -a g_msg_callback_array__

# The XML file name.
declare -r g_update_xml_filename="LinuxUpdate.XML"

# Read field values from the JSON string.
# param $1: json string
get_value_from_json()
{
	if [ $# -ne 2 ]; then
		log "parameter error!"
		return 1
	fi
	
	# FIXME: Need to deal with ,} in json
	local value=`echo "${1}" | awk -F"\"${2}\":" '{print $2}' | awk -F',|}' '{print $1}'`
	echo "${value}"
	return 0
}

# To tunnel head reading from a virtual machine serial news
# param $1: file path
get_tunnel_hdr_from_file()
{
	if [ $# -ne 1 ]; then
		log "parameter error!"
		return 1
	fi
	
	while read line
	do
		echo "${line}"
		return 0
	done < ${1}
	
	return 1
}

# Read field values from the JSON file.
# Don't take too long for a string, such as 20K, pay attention to value cannot with double quotation marks.
# param $1: file path
# param $2: value name
get_value_from_json_file()
{
	if [ $# -ne 2 ]; then
		log "parameter error!"
		return 1
	fi
	
	local value=`awk -F"\"${2}\":" '{print $2}' "${1}" | awk -F',|}' '{print $1}'`
	# FIXME: To delete quotation marks, you can write more rigorous, only to both sides of the.
	test ! -z "${value}" && value=`echo "${value}" | tr -d '"'`
	echo "${value}"
	return 0
}

# Access to the source device ID from the tunnel in the head.
# param $1: the tunnel string
vm_ipc_get_src_devid()
{
	if [ $# -ne 1 ]; then
		log "parameter error!"
		return 1
	fi
	
	get_value_from_json ${1} "src_devid"
	return 0
}

# Access to the source ID module from the tunnel in the head.
# param $1: the tunnel string
vm_ipc_get_src_modid()
{
	if [ $# -ne 1 ]; then
		log "parameter error!"
		return 1
	fi
	
	get_value_from_json ${1} "src_mod"
	return 0
}

# Purpose of obtaining ID module from the tunnel in the head.
# param $1: the tunnel string
vm_ipc_get_dst_modid()
{
	if [ $# -ne 1 ]; then
		log "parameter error!"
		return 1
	fi
	
	get_value_from_json ${1} "dst_mod"
	return 0
}

# To obtain the source instance of ID from the tunnel in the head.
# param $1: the tunnel string
vm_ipc_get_src_instid()
{
	if [ $# -ne 1 ]; then
		log "parameter error!"
		return 1
	fi
	
	get_value_from_json ${1} "src_inst"
	return 0
}

# Purpose of obtaining an instance of ID from the tunnel in the head.
# param $1: the tunnel string
vm_ipc_get_dst_instid()
{
	if [ $# -ne 1 ]; then
		log "parameter error!"
		return 1
	fi
	
	get_value_from_json ${1} "dst_inst"
	return 0
}

# Gets the message type from the tunnel in the head
# param $1: the tunnel string
vm_ipc_get_msg_type()
{
	if [ $# -ne 1 ]; then
		log "parameter error!"
		return 1
	fi
	
	get_value_from_json ${1} "msg_type"
	return 0
}

# Gets the packet ID from the tunnel head
# param $1: the tunnel string
vm_ipc_get_id()
{
	if [ $# -ne 1 ]; then
		log "parameter error!"
		return 1
	fi
	
	get_value_from_json ${1} "id"
	return 0
}

# Gets the slice identification from the tunnel in the head
# param $1: the tunnel string
vm_ipc_get_frag_off()
{
	if [ $# -ne 1 ]; then
		log "parameter error!"
		return 1
	fi
	
	get_value_from_json ${1} "frag_off"
	return 0
}

# vm_ipc Communication interface initialization function
# param $1: The self module id
# param $2: The self instance id，default is 0.
vm_ipc_init()
{
	if [ $# -ne 2 ]; then
		log "parameter error!"
		return 1
	fi
	
	g_my_modid__=${1}
	g_my_instid__=${2}
	
	# Parameters to check the legality
	test -z "${RECV_DIR__}" && return 1
	test ! -n "${g_my_modid__}" && return 1
	test ! -n "${g_my_instid__}" && return 1
	local dirpath="${RECV_DIR__}/${g_my_modid__}/${g_my_instid__}"

	# Remove the last time the confiscation of the end of the data
	rm -rf "${dirpath}"
	mkdir -p "${dirpath}"

	mkdir -p "/var/log/sangfor"
	set_log_filepath "/var/log/sangfor/mod${g_my_modid__}_inst${g_my_instid__}.log"
	# Get version from XML file.
	local version=`grep -oP '(?<=\<Version\>)[^\<]+' "$( dirname "${BASH_SOURCE[0]}" )/${g_update_xml_filename}" 2>/dev/null`
	if [ -z "$version" ];then
		version=$(sed -n 's/.*<Version>\(.*\)<\/Version>/\1/p' "$(dirname "${BASH_SOURCE[0]}")/${g_update_xml_filename}" 2>/dev/null)
	fi
	log "XML version is:${version}"
	return 0
}

# Registration message callback
# param $1: message id
# param $2: message callback function
# The first parameter to the callback function is the module of ID, the second parameter is an instance of ID, the third parameter is the message file path.
vm_ipc_reg_callback()
{
	if [ $# -ne 2 ]; then
		log "parameter error!"
		return 1
	fi
	
	local msgid=${1}
	local funcname=${2}
	
	g_msg_callback_array__[${1}]=${2}
}

# Message and event driven API, in the while call, receive the message will automatically call the callback function.
vm_ipc_event_loop_once()
{
	local msg_dir="${RECV_DIR__}/${g_my_modid__}/${g_my_instid__}"
	# ls order by time
	local filelist=`ls -rt ${msg_dir}/*.msg 2> /dev/null`
	while read file
	do
		# no file
		test -z "${file}" && continue
		local datafile=${file}
		
		# Determine the file exists, prevent to be deleted
		test -f "${datafile}" || continue
		
		local hdrfile=`echo "${datafile}" | sed 's/.msg$/.hdr/'`
		if [ ! -f "${hdrfile}" ]; then
			log "lost hdr file: '${hdrfile}'"
			rm -f "${datafile}"
			continue
		fi
		
		local tunnel_hdr=`get_tunnel_hdr_from_file "${hdrfile}"`
		local msg_type=`vm_ipc_get_msg_type "${tunnel_hdr}"`
		local peer_modid=`vm_ipc_get_src_modid "${tunnel_hdr}"`
		local peer_instid=`vm_ipc_get_src_instid "${tunnel_hdr}"`
		
		local funcname=${g_msg_callback_array__[$msg_type]}
		if [ -z "${funcname}" ]; then
			log "recv unreg msg_type '${msg_type}' from mod '${peer_modid}' inst '${peer_instid}'"
		else
			$funcname ${peer_modid} ${peer_instid} "${datafile}"
		fi
		
		rm -f "${datafile}"
		rm -f "${hdrfile}"
	done <<EOF
${filelist}
EOF
	
	# Clean the residue file(Create 20 minutes ago, group of failure or rename failed file)
	find "${msg_dir}" -type f -mmin +20 -exec rm {} \;
}

# Send message to the inside of the machine
# param $1: Objective to module id
# param $2: Objective to instance id
# param $3: message id
# param $4: message data(file or string)
vm_ipc_to_self()
{
	if [ $# -ne 4 ]; then
		log "parameter error!"
		return 1
	fi
	
	local modid=${1}
	local instid=${2}
	local msgtype=${3}
	local msgdata=${4}
	local id=$(($RANDOM*$RANDOM))
	
	local tunnel_json="{\"version\":0,\
\"src_devid\":\"0\",\"dst_devid\":\"0\",\"direct_devid\":\"0\",\
\"src_dev\":1,\"dst_dev\":2,\
\"src_mod\":${g_my_modid__},\"dst_mod\":${modid},\
\"src_inst\":${g_my_instid__},\"dst_inst\":${instid},\
\"id\":${id},\"frag_off\":0,\
\"msg_type\":${msgtype},\"data\":\"\"}"
	
	local dirpath="${RECV_DIR__}/${modid}/${instid}"
	local tmpfile="${dirpath}/.mod${g_my_modid__}_msg${msgtype}_${id}"
	local filepath="${dirpath}/mod${g_my_modid__}_msg${msgtype}_${id}"
	test ! -d "${dirpath}" && mkdir -p "${dirpath}"
	echo "${tunnel_json}" > "${tmpfile}.hdr"
	
	# copy if it is a file.
	if [ -f "${msgdata}" ]; then
		cp "${msgdata}" "${tmpfile}.msg"
	else
		echo "${msgdata}" > "${tmpfile}.msg"
	fi
	mv "${tmpfile}.hdr" "${filepath}.hdr"
	mv "${tmpfile}.msg" "${filepath}.msg" 
	
	return 0
}

# Send message to the host.
# param $1: module id
# param $2: instance id
# param $3:  message id
# param $4: message data(file or string)
vm_ipc_to_local_host()
{
	if [ $# -ne 4 ]; then
		log "parameter error!"
		return 1
	fi
	
	local modid=${1}
	local instid=${2}
	local msgtype=${3}
	local msgdata=${4}
	local id=$(($RANDOM*$RANDOM))
	# Patch size
	local frag_size=10240
	local total_size=0
	local sended=0
	test -f "${msgdata}" && total_size=`stat -c %s "${msgdata}"` || total_size=${#msgdata}

	test ! -d "${SEND_DIR__}" && mkdir -p "${SEND_DIR__}"
	local tmpfile="${SEND_DIR__}/.mod${g_my_modid__}_inst${g_my_instid__}_msg${msgtype}_${id}"
	local filepath="${SEND_DIR__}/mod${g_my_modid__}_inst${g_my_instid__}_msg${msgtype}_${id}"
	
	while [[ ${sended} -lt ${total_size} ]]
	do
		local frag_off=0
		local send_len=$((${total_size}-${sended}))
		test ${send_len} -gt ${frag_size} && send_len=${frag_size} && frag_off=$((0x20000000|${sended})) || frag_off=${sended}
		
		local tunnel_json="{\"version\":0,\
\"src_devid\":\"0\",\"dst_devid\":\"0\",\"direct_devid\":\"0\",\
\"src_dev\":1,\"dst_dev\":2,\
\"src_mod\":${g_my_modid__},\"dst_mod\":${modid},\
\"src_inst\":${g_my_instid__},\"dst_inst\":${instid},\
\"id\":${id},\"frag_off\":${frag_off},\
\"msg_type\":${msgtype},\"data\":\"\"}"

		echo "${tunnel_json}" > "${tmpfile}"
		if [ -f "${msgdata}" ]; then
			dd if="${msgdata}" of="${tmpfile}" skip=${sended} seek=$((${#tunnel_json}+1)) bs=1 count=${send_len}
			# Appends a newline
			echo "" >> "${tmpfile}"
		else
			echo "${msgdata:${sended}:${send_len}}" >> "${tmpfile}"
		fi

		mv "${tmpfile}" "${filepath}_offset${sended}"

		sended=$((${sended}+${send_len}))
	done

	return 0
}
