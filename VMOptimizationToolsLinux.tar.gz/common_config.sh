#!/bin/bash

# Module forwarding packets received directory.
declare -r RECV_DIR__="/var/sangfor/recv"

# The directory module forwarding.
declare -r SEND_DIR__="/var/sangfor/send"

# time for sangfor_vm_proxyd_w to sleep when no data to devliver
declare -r SEND_SLEEP_TIME__=1
