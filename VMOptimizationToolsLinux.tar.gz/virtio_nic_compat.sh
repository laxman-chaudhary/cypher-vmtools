#!/bin/bash

# 问题：td15331.安装virito后，centos7及redhat7等系统的网络设备名会发生变化，比如，由ens18改为eth0
#       如果其网络配置ifcfg-ens18中记录了DEVICE=ens18，则在切换为virtio网卡后会出现找不到
#       设备的问题
# 功能：此脚本用于查找并修改ifcfg-*中可能存在的DEVICE字段，并将其修正为使用virtio网卡后的
#       网络设备名
# @author fangfei
# @date 20170330
#

shell_dir=`dirname "${BASH_SOURCE[0]}"`
. "${shell_dir}/net_common.sh"

#网络配置目录
declare g_network_cfg_path="/etc/sysconfig/network-scripts/"

#备份的网络配置路径，此配置在安装vmtools时由vmtools-install.sh生成
#格式为：网卡物理地址 网卡设备名
declare g_sangfor_cfg_dir="/etc/sangfor"
declare g_backup_network_info="${g_sangfor_cfg_dir}/sangfor_network_info.bak"

# 实现网络配置修正
# 原理：1、安装vmtools前读取/sys/class/net/ens18/address，获取每个网卡的mac地址，并保存其与网络设备名的对应关系，如：
#          xx:xx:xx:xx:xx:xx ens18
#       2、安装vmtools后，读取ifcfg-ens18中的DEVICE字段，若无则不做处理
#       3、若存在DEVICE，则说明此网络连接之前有与网络设备绑定，从1中保存的对应关系获取其mac地址
#       4、遍历/sys/class/net下的每张网卡，获取其address，和3中得到的mac比较
#       5、若相等则说明找到安装virtio前后的同张网卡，获取其设备名，更新到DEVICE中。
# 注意：本函数在遇到ifcfg-*中存在注释的情况时可能会有问题，比如ifcfg-ens18中存在以下配置项
#       NAME="ens18 10" # 注释部分，网络连接名称，名称中可以包含空格
#       DEVICE=ens18    # 注释部分，网络设备名
virtio_nic_compat()
{
    # 只针对centos/redhat系列操作系统的网卡配置做处理，即存在g_network_cfg_path的系统
    cd "${g_network_cfg_path}" 2>/dev/null || return 1
    
    # 没有找到备份信息时也不做兼容性处理
    if [ ! -e "${g_backup_network_info}" ]; then
        return 1
    fi
    
    local interfaces=""         # 网络配置列表
    local interface=""          # 网络配置
    local old_dev_name=""       # 旧网络设备名，即ifcfg-eth0中DEVICE字段的值，此值可能需要修正
    local old_mac_addr=""       # 旧网络设备名对应的mac地址
    local backup_net_info=""    # 备份文件中网络配置信息
    local backup_mac_addr=""    # 备份文件中记录的网卡mac地址
    local backup_dev_name=""    # 备份文件中记录的网卡名
    local new_net_list=""       # 当前使用的网络设备列表
    local new_dev_name=""       # 当前使用的网络设备名，安装virtio后设备名会发生变化，此变量记录的为真实值
    local new_mac_addr=""       # 当前网络设备的mac地址
    
    new_net_list=$(get_net_name)
    
    interfaces=`find ./ -name "ifcfg-*" -type f`
    for interface in $interfaces; do
        # 不存在DEVICE字段则不用处理
        old_dev_name=`cat "${interface}" | grep "^DEVICE=.*" | sed 's/DEVICE=//g' | sed s/[\"\']//g`
        if test -z "${old_dev_name}"; then
            continue
        fi

        # fix td16252, 由于old_mac_addr在上个循环残留，导致ifcfg-lo配置文件里的DEVICE字段会被篡改成eth0
        old_mac_addr=""
        # 获取旧的网络设备名对应的mac地址，不能直接通过grep old_dev_name的方式来匹配，因为网卡名中可能
        # 存在ens1和ens18这种网卡名前缀相同的情况，grep ens1时同时会获取到ens18的mac地址，导致匹配失败
        while read backup_net_info; do
            backup_mac_addr=`echo "${backup_net_info}" | awk '{print $1}'`
            backup_dev_name=`echo "${backup_net_info}" | awk '{print $2}'`
            if [ "${backup_dev_name}" = "${old_dev_name}" ]; then
                old_mac_addr="${backup_mac_addr}"
                break
            fi
        done < "${g_backup_network_info}"

        if test -z "${old_mac_addr}"; then
            continue
        fi
        
        for new_dev_name in $new_net_list; do
            new_mac_addr=`cat "/sys/class/net/${new_dev_name}/address"`
            if [ "${new_mac_addr}" = "${old_mac_addr}" ]; then
                break
            fi
        done
        
        if [ "${new_mac_addr}" != "${old_mac_addr}" ]; then
            continue
        fi
        
        # 网络设备名本身相同，或者已经修正过，则不重复修改，避免改出其他问题
        if [ "${new_dev_name}" = "${old_dev_name}" ]; then
            continue
        fi

        # 增加v6之后，如果只设置v6的话，安装virtio之后，配置文件名会被修改为eth，导致v4失效，没有保存v4，因此修改网卡配置文件名为ifcfg-eth
        local cfg_file="./ifcfg-${new_dev_name}"
        cp ${interface} $cfg_file
        sed "s/NAME=['\"]\?${old_dev_name}['\"]\?/NAME=${new_dev_name}/g" -i "${cfg_file}"
        # 关键代码，将安装virtio前的网络设备名修改为新的网络设备名
        sed "s/DEVICE=['\"]\?${old_dev_name}['\"]\?/DEVICE=${new_dev_name}/g" -i "${cfg_file}"        
    done
    
    return 0
}

main()
{
    virtio_nic_compat
    if [ $? -ne 0 ]; then
        # 函数返回1表示遇到不需要处理的系统类型，不重启网络服务，直接返回
        return 1
    fi
    
    # 修改网络配置后需重启一次网络服务生效
    service network restart > /dev/null 2>&1
    return $?
}

main
# 脚本无论执行成功还是失败都返回0，如果返回失败，外部将不会重命名此文件，
# 则系统每次启动时都会执行一次，多余
exit 0