#!/usr/bin/perl -w

use strict;
use warnings;
use Socket;
#perl version before 5.14 need import Socket6 module
use if $] < 5.014, "Socket6";
use bignum;

my $ICMP_SEND_SUCCESS = 0;
my $ICMP_SEND_ERROR_OTHER = 255;
my $LOG_PATH = "/var/log/sfping.log";

use constant {
    IPPROTO_ICMP       => 1,
    IPPROTO_ICMPV6     => 58,
    ICMP_ECHO_REQUSET  => 8,
    ICMP_ECHO_REPLY    => 0,
    ICMP6_ECHO_REQUSET => 128,
    ICMP6_ECHO_REPLY   => 129,
    VT_ICMP_DEBUG_PATH_MAGIC => 0x13579BDF,
    VT_ICMP6_DEBUG_PATH_MAGIC => 0x13579BDE,
    IPV4_HAED_LEN => 20,
    VT_DEBUG_VM => 1,
    VT_DEBUG_VR => 0,
    SEQUENCE_NUM => 2,
};

sub sf_debug
{
    my ($log_debug) = @_;

    printf "[D] $log_debug\n";
    
    `echo "[D] $log_debug" >>$LOG_PATH`
}

sub sf_error
{
    my ($log_error) = @_;
    
    printf "[E] $log_error\n";
    
    `echo "[E] $log_error" >>$LOG_PATH`
}

sub sf_constant_bswap64
{
    my ($x) = @_;
    
    return (($x & 0x00000000000000ff) << 56) |
           (($x & 0x000000000000ff00) << 40) |
           (($x & 0x0000000000ff0000) << 24) |
           (($x & 0x00000000ff000000) <<  8) |
           (($x & 0x000000ff00000000) >>  8) |
           (($x & 0x0000ff0000000000) >> 24) |
           (($x & 0x00ff000000000000) >> 40) |
           (($x & 0xff00000000000000) >> 56);
}

sub sf_htons
{
    my ($in) = @_;

    return(unpack('n*', pack('S*', $in)));
}

sub sf_htonl
{
    my ($in) = @_;

    return(unpack('N*', pack('L*', $in)));
}

sub sf_htonll_high
{
    my ($in) = @_;
    my $high = ($in) >> 32;
    return sf_htonl($high);
}
sub sf_htonll_low
{
    my ($in) = @_;
    my $low = ($in & 0xffffffff);
    return sf_htonl($low);
}

sub sf_htonll
{
    my ($in) = @_;
    return sf_constant_bswap64($in);
}

sub sf_ntohl
{
    my ($in) = @_;

    return(unpack('L*', pack('N*', $in)));
}

sub sf_ntohs
{
    my ($in) = @_;

    return(unpack('S*', pack('n*', $in)));
}

sub sf_ntohll
{
    my ($in) = @_;
    return sf_constant_bswap64($in);
}

sub sf_in_cksum {

    my ($packet) = @_;
    my ($plen, $short, $num,  $count, $chk);

    $plen = length($packet);
    $num = int($plen / 2);
    $chk = 0;
    $count = $plen;

    foreach $short (unpack("S$num", $packet)) {
        $chk += $short;
        $count = $count - 2;
    }

    if($count == 1) {
        $chk += unpack("C", substr($packet, $plen -1, 1));
    }

    # add the two halves together (CKSUM_CARRY -> libnet)
    $chk = ($chk >> 16) + ($chk & 0xffff);
    return(~(($chk >> 16) + $chk) & 0xffff);
}

sub sf_sockaddr_in6
{
    my ($dstaddr) = @_;
    my $sock_addr;
    if ($] < 5.014)
    {
        $sock_addr = sockaddr_in6(0, inet_pton(AF_INET6, $dstaddr));
    }
    else
    {
        $sock_addr = sockaddr_in6(0, Socket::inet_pton(AF_INET6, $dstaddr), []);
    }
    return $sock_addr;
}

sub send_recv_buf
{
    my ($sendbuf, $dest) = @_;
    my $ret = 0;
    my $recvbuf = "";
    my $recvbuf_len = 400;

    if(!defined(send(SOCK, $sendbuf, 0, $dest)))
    {
        $ret = 0 + $!;
        sf_error("send data failed! error = $ret");
        return $recvbuf;
    }

    if(!defined(recv(SOCK,$recvbuf, $recvbuf_len, 0)))
    {
        $ret = 0 + $!;
        sf_error("recv failed! error = $ret");
        return $recvbuf;
    }

    return $recvbuf;
}

sub sf_icmp_send_recv
{
    my ($dstaddr, $version, $pkt_id, $hostid, $vmid, $ifid, $is_ipv6) = @_;
    my $pid = $$;
    sf_debug("pid = $pid");
    sf_debug("dstip = $dstaddr");
    sf_debug("version = $version");
    sf_debug("pkt_id = $pkt_id");
    sf_debug("hostid = $hostid");
    sf_debug("vmid = $vmid");
    sf_debug("ifid = $ifid");

    my $ret = 0;
    my $type = VT_DEBUG_VM;
    my $chks = 0;
    my $dest = 0;
    my $icmp_pkt_type = 0;
    my $icmp_pkt_code = 0;
    my $head_len = 0;
    my $template = '';
    my $template1 = '';
    my $debug_path_magic = 0;
    if (!$is_ipv6)
    {
        sf_debug("send ipv4");
        $dest = sockaddr_in(0, inet_aton($dstaddr));
        $ret = socket(SOCK, PF_INET, SOCK_RAW, getprotobyname('icmp'));
        $icmp_pkt_type = ICMP_ECHO_REQUSET;
        $head_len = IPV4_HAED_LEN;
        $debug_path_magic = VT_ICMP_DEBUG_PATH_MAGIC;
        $template = 'CCnnnx[24] Cx[3] L L x[4] L2 L2 L x[4] L x[212]';
        $template1 = 'CCnnnx[24] Cx[3] L L x[4] L2 L2 L x[4] L';
    }
    else
    {
        sf_debug("send ipv6");
        $dest = sf_sockaddr_in6($dstaddr);
        $ret = socket(SOCK, PF_INET6, SOCK_RAW, IPPROTO_ICMPV6);
        $icmp_pkt_type = ICMP6_ECHO_REQUSET;
        $head_len = 0;  # recv ipv6 pkt has no head
        $debug_path_magic = VT_ICMP6_DEBUG_PATH_MAGIC;
        $template = 'CCnnnx[8] Cx[3] L L x[4] L2 L2 L x[4] L x[212]';
        $template1 = 'CCnnnx[8] Cx[3] L L x[4] L2 L2 L x[4] L';
    }

    if(not $ret)
    {
        sf_error("socket failed! error = $!");
        return $ICMP_SEND_ERROR_OTHER;
    }

    sf_debug("ifid = $ifid");
    #��װ��������
    my $sendbuf=pack($template, 
        $icmp_pkt_type, $icmp_pkt_code, $chks, $pid, SEQUENCE_NUM, $type,
        sf_htonl($version), sf_htonl($pkt_id), sf_htonll_high($hostid),
        sf_htonll_low($hostid), sf_htonll_high($vmid), sf_htonll_low($vmid),
        sf_htonl($ifid), sf_htonl($debug_path_magic));

    $chks = sf_htons(sf_in_cksum($sendbuf));

    $sendbuf=pack($template,
        $icmp_pkt_type, $icmp_pkt_code, $chks, $pid, SEQUENCE_NUM, $type,
        sf_htonl($version), sf_htonl($pkt_id), sf_htonll_high($hostid),
        sf_htonll_low($hostid), sf_htonll_high($vmid), sf_htonll_low($vmid),
        sf_htonl($ifid), sf_htonl($debug_path_magic));

    my $send_len = length($sendbuf);
    sf_debug("sendbuf len = $send_len\n");

    my $recvbuf = '';
    # ͨ���������ж��Ƿ��ͳɹ�
    $recvbuf = send_recv_buf($sendbuf, $dest);
    my $recv_len = length($recvbuf);
    sf_debug("recv_len = $recv_len\n");
    if($recv_len != $send_len + $head_len)
    {
        sf_error("send failed, retry!");
        # �յ��ĵ�һ����������na����
        $recvbuf = send_recv_buf($sendbuf, $dest);
        my $recv_len = length($recvbuf);
        sf_debug("recv_len = $recv_len\n");
        if($recv_len != $send_len + $head_len)
        {
            sf_error("send failed, len not equal!");
            return $ICMP_SEND_ERROR_OTHER;
        }
    }
    
    #?a???����?��y?Y
    if ($head_len)
    {
        $recvbuf = substr($recvbuf, $head_len);
    }

    my ($ret_icmp_type, $ret_icmp_code, $ret_cksum, $ret_pid,
        $ret_seq, $src_type, $src_version, $src_pkt_id, $src_hostid_high,
        $src_hostid_low, $src_vmid_high, $src_vmid_low, $src_ifid,
        $src_magic) = unpack($template1, $recvbuf);
    $src_version = sf_ntohl($version);
    $src_pkt_id = sf_ntohl($src_pkt_id);
    $src_hostid_high = sf_ntohl($src_hostid_high);
    $src_hostid_low = sf_ntohl($src_hostid_low);
    $src_vmid_high = sf_ntohl($src_vmid_high);
    $src_vmid_low = sf_ntohl($src_vmid_low);
    $src_ifid = sf_ntohl($src_ifid);

    my $src_hostid = ($src_hostid_high << 32) + $src_hostid_low;
    my $src_vmid = ($src_vmid_high << 32) + $src_vmid_low;

    sf_debug("ret_icmp_type = $ret_icmp_type");
    sf_debug("ret_icmp_code = $ret_icmp_code");
    sf_debug("ret_pid = $ret_pid");
    sf_debug("ret_seq = $ret_seq");
    sf_debug("src_type = $src_type");
    sf_debug("src_pkt_id = $src_pkt_id");
    sf_debug("src_hostid_high = $src_hostid_high");
    sf_debug("src_hostid_low = $src_hostid_low");
    sf_debug("src_vmid_high = $src_vmid_high");
    sf_debug("src_vmid_low = $src_vmid_low");
    sf_debug("src_hostid = $src_hostid");
    sf_debug("src_vmid = $src_vmid");
    sf_debug("src_ifid = $src_ifid");
    close(SOCK);

    if ((!$is_ipv6 && $ret_icmp_type != ICMP_ECHO_REPLY) ||
        ($is_ipv6 && $ret_icmp_type != ICMP6_ECHO_REPLY))
    {
        sf_error("not Echo Reply!");
        return $ICMP_SEND_ERROR_OTHER;
    }

    return $ICMP_SEND_SUCCESS;
}

if(@ARGV != 6)
{
    sf_error("argv param error!");
    exit($ICMP_SEND_ERROR_OTHER);
}

my $version = $ARGV[0];
my $vmid = $ARGV[1];
my $hostid = $ARGV[2];
my $pkt_id = $ARGV[3];
my $ifid = $ARGV[4];
my $addr = $ARGV[5];

printf "%-12s %8s %s\n",  "localhost", 0, scalar localtime();

printf"send $addr \n";

my $is_ipv6 = 0;
if (index($addr, ':') >= 0)
{
    $is_ipv6 = 1;
}
my $ret = sf_icmp_send_recv($addr, $version, $pkt_id,
                            $hostid, $vmid, $ifid, $is_ipv6);

sf_debug("sf_icmp_send_recv ret = $ret");

exit($ret);

