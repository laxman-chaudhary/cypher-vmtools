#!/bin/bash

LOG_FILE=/var/log/$(basename $0).log

NET_CLASS=/sys/class/net
NET_VIRTUAL=/sys/devices/virtual/net
function set_multi_channel()
{
    type -a ifconfig 1>/dev/null
    if [ "$?" -ne "0" ]
    then
        echo "ifconfig no exist, go out" >> "${LOG_FILE}"
        return 1
    fi
    type -a ethtool 1>/dev/null
    if [ "$?" -ne "0" ]
    then
        echo "ethtool no exist, go out" >> "${LOG_FILE}"
        return 1
    fi
    if [ ! -d ${NET_CLASS} ]
    then
        echo "${NET_CLASS} no exist or nic no exist, go out" >> "${LOG_FILE}"
        return 1
    fi
    for devpath in ${NET_CLASS}/*
    do
        dev=`basename ${devpath}`
        [ -d ${NET_VIRTUAL}/${dev} ] && continue
        num=`ethtool -l ${dev} 2> /dev/null |grep 'Combined'|head -n1|cut -d':' -f2`
        [ -z "${num}" ] && continue
        ethtool -L ${dev} combined ${num}
        echo ">>>>${dev} combined ${num}<<<<" >> "${LOG_FILE}"
    done
    return 0
}

PROC_INTERRUPT=/proc/interrupts
PROC_IRQ=/proc/irq
function set_virtio_nic_affinity()
{
    if [ -n "$(pidof irqbalance)" ]
    then
        echo "irqbalance is in effect, try to stop it" >> "${LOG_FILE}"
		service irqbalance stop > /dev/null 2>&1
		/etc/init.d/irqbalance stop > /dev/null 2>&1
		/etc/init.d/irq_balancer stop > /dev/null 2>&1
		kill -9 $(pidof irqbalance) > /dev/null 2>&1
    fi	
    if [ ! -e ${PROC_INTERRUPT} ]
    then
        echo "/proc/interrupts no exist, go out" >> "${LOG_FILE}"
        return 1
    fi
    for entry in `cat ${PROC_INTERRUPT}|grep 'virtio[0-9]*-[inout]\{2,3\}put\.[0-9]*$'|tr -d ' '`
    do
        irq=${entry%%:*}
        index=${entry##*.}
        mask=$((1<<${index}))
        mask=$(printf %x ${mask})
        echo ${mask} > ${PROC_IRQ}/${irq}/smp_affinity
        echo ${index} > ${PROC_IRQ}/${irq}/smp_affinity_list
        echo "___${irq} ---  ${index}  ---  ${mask}___" >> "${LOG_FILE}"
    done

    index=-1
    cpu_num=`cat /proc/cpuinfo | grep processor | wc -l`
    for entry in `cat ${PROC_INTERRUPT}|grep 'virtio[0-9]*-[inout]\{2,3\}put$'|tr -d ' '`
    do
        irq=${entry%%:*}
        index=`expr \( ${index} + 1 \) % ${cpu_num}`
        mask=$((1<<${index}))
        mask=$(printf %x ${mask})
        echo ${mask} > ${PROC_IRQ}/${irq}/smp_affinity
        echo ${index} > ${PROC_IRQ}/${irq}/smp_affinity_list
        echo "___${irq} ---  ${index}  ---  ${mask}___" >> "${LOG_FILE}"
    done
    return 0
}

set_multi_channel
set_virtio_nic_affinity
exit 0