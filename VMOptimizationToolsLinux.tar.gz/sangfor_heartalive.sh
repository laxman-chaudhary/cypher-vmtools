#! /bin/bash

# 设置进程列宽环境变量,防止ps等命令取得的结果被截断
export COLUMNS=180

shell_dir=$( cd "$( dirname "${BASH_SOURCE[0]}")" && pwd)
. "${shell_dir}/update_config"
. "${shell_dir}/log.sh"
. "${shell_dir}/update_common_func"

declare -r g_change_conf_file_name="vtp-sangfor-vmstools-install"
declare -r g_sleep_time=20

x86_or_x64(){
    local x64="x86_64"
    local info=""
    info="`uname -a 2>/dev/null`"
    if [ x"${info/${x64}/}" = x"${info}" ];then
        #x86
        return 32
    else
        return 64
    fi
}
init(){
    local code=0
    g_current_dir=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
    
    x86_or_x64
    code=$?
    if [ ${code} -eq 32 ];then
        g_change_conf_file_path="${g_current_dir}/x86/${g_change_conf_file_name}"
    else
        g_change_conf_file_path="${g_current_dir}/x64/${g_change_conf_file_name}"
    fi
}

notify_heart_alive_to_host(){
    local op_notify="vmheart"
    if [ ! -e "${g_change_conf_file_path}" ];then
        echo "${g_change_conf_file_path} is not exist!"          
        return 1
    fi
    chmod +x "${g_change_conf_file_path}" >/dev/null 2>&1
    while true
	do
		"${g_change_conf_file_path}" ${op_notify}
		sleep $g_sleep_time
	done
    return 0
}

main()
{
	init
	notify_heart_alive_to_host
}

#lock exec add by wtd@20161025
lockEntry()
{
    if ! which flock >/dev/null 2>&1; then
        #if no which or no flock, use ps style
        echo "[ps] flock is not found"

        # 1, 0(ps not found) or empty(wc not found) or anything other invalid, can run
        # 2 is not running, can run
        # > 2 has already running, can't run
        local count=$(ps aux 2>/dev/null | grep sangfor_heartalive | grep -v grep | wc -l 2>/dev/null)
        if [ "" != "$count" -a $count -gt 2 ]; then
            echo "[ps] has same process already running"
            return 1
        fi
        echo "[ps] found count $count, can run"
        main
    else
        echo "[flock] flock found"
        local lock=""
        if [ -d "/tmp" ]; then
            lock="/tmp"
        fi
        lock="$lock/heartalive.lock"
        touch ${lock} 2>/dev/null
        # prevent switch to a low privilege user, lack privilege
        chmod a+r ${lock} 2>/dev/null
        (
            if ! flock -n -x 200; then
                echo "[flock] flock $lock failed $?"
                return 1
            fi
            echo "[flock] flock $lock success"
            main
        ) 200<${lock}
    fi
    return 0
}

lockEntry
