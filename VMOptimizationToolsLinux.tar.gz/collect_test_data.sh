#!/bin/bash

DATA_DIR=/tmp/test_data
rm -rf "${DATA_DIR}"
mkdir -p "${DATA_DIR}"

# collect the test data of get_os_version
uname -r > "${DATA_DIR}/uname-r.txt"
uname -a > "${DATA_DIR}/uname-a.txt"

# collect the test data of get_cpu_info and get_diskio_info
rm -rf "${DATA_DIR}/proc"
mkdir -p "${DATA_DIR}/proc"
cat "/proc/stat" > "${DATA_DIR}/proc/stat1"
cat "/proc/diskstats" > "${DATA_DIR}/proc/diskstats1"
sleep 5
cat "/proc/stat" > "${DATA_DIR}/proc/stat2"
cat "/proc/diskstats" > "${DATA_DIR}/proc/diskstats2"

# collect the test data of get_mem_usage
cat "/proc/meminfo" > "${DATA_DIR}/proc/meminfo"

# collect the test data of get_disk_total
cat "/proc/partitions" > "${DATA_DIR}/proc/partitions"

# collect the test data of get_disk_used
df -PBK > "${DATA_DIR}/df.txt"

rm -rf "${DATA_DIR}/sys/class/"
mkdir -p  "${DATA_DIR}/sys/class/"
# collect the test data of get_net_name
cp -rf "/sys/class/net" "${DATA_DIR}/sys/class/"

# collect the test data of get_net_pci_by_lspci
lspci > "${DATA_DIR}/lspci.txt"

# collect the test data of get_net_ip
ip addr ls > "${DATA_DIR}/ipaddr.txt"

LOCAL_DIR=`pwd`
cd "${DATA_DIR}"
tar -czvf "${LOCAL_DIR}/test_data.tar.gz" ./*
cd -

exit 0
