#! /bin/bash
# create by ysk
# 此功能是为了解决从vmware平台备份恢复到alcoud平台上的ip丢失问题,以及从acloud迁移到vmware的IP丢失问题
# ip丢失的根源是MAC地址发生了改变，但是后两个字节不会变。此外，网卡命名规则也会产生影响。
# 例如：在vmware的命名是ens18，到了acloud就成了eth0。此时依靠网卡名就无法找回原来的配置
# 所以根据MAC的后两个字节进行匹配，然后修改网卡配置文件，使得新网卡找回原来的IP配置
# 如果原来的虚拟机并没有进行IP配置，则不进行处理
# 目前仅支持redhat系列和Debian系列

declare -r g_debian_network_cfg="/etc/network/interfaces"
declare -r g_debian_network_cfg_dir="/etc/network/interfaces.d"
declare -r g_redhat_network_cfg_dir="/etc/sysconfig/network-scripts"
declare -r g_suse_network_cfg_dir="/etc/sysconfig/network"
declare -r g_suse_routes_config_file="/etc/sysconfig/network/routes"
declare -r g_suse_netconfig_file="/etc/sysconfig/network/config"

declare -r g_persistent_rule_file="/etc/udev/rules.d/70-persistent-net.rules"

#记录系统类型的字符串，用于检测和对比
declare -r g_REDHAT_SERIES_TYPE='redhat'
declare -r g_DEBIAN_SERIES_TYPE='debian'
declare -r g_SUSE_SERIES_TYPE='suse'
declare -r g_UNKNOWN_SYS_TYPE='unknown'

#简单的日志函数

function log_info(){
    log "INFO ${*}"
}
function log_error(){
    log "ERR ${*}"
}
function log_warn(){
    log "WARN ${*}"
}
function log_debug(){
    log "DEBUG ${*}"
}

# 获得系统类型
# 输出：参考g_XXXX_TYPE全局变量
# 返回：0-成功，255-失败
function get_system_type()
{
    #redhat series
    cat /proc/version | grep -i -E "red\s*hat" >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        log_info "redhat system"
        echo "$g_REDHAT_SERIES_TYPE"
        return 0
    fi
    #Ubuntu属于debian体系
    cat /proc/version | grep -i "ubuntu" >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        log_info "ubuntu system"
        echo "$g_DEBIAN_SERIES_TYPE"
        return 0
    fi
    # suse series
    cat /proc/version | grep -i "suse" >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        log_info "suse system"
        echo "$g_SUSE_SERIES_TYPE"
        return 0
    fi

    #get type by check network config dir or file
    if [ -d $g_redhat_network_cfg_dir ]; then
        log_info "redhat series system"
        echo "$g_REDHAT_SERIES_TYPE"
        return 0
    fi

    if [ -d $g_debian_network_cfg_dir ]; then
        log_info "debian series system"
        echo "$g_DEBIAN_SERIES_TYPE"
        return 0
    fi

    if [ -d $g_suse_network_cfg_dir ]; then
        log_info "suse series system"
        echo "$g_SUSE_SERIES_TYPE"
        return 0
    fi

    log_error "system is not support."
    echo "$g_UNKNOWN_SYS_TYPE"
    return 255
}

# 包含当前网卡信息的文件夹
declare -r g_current_nic_dir='/sys/class/net'

# 取得当前的系统网卡列表信息，包括网卡名和MAC地址
# 机制：读取/sys/class/net下的文件
# 输入：无
# 输出：分条输出每张网卡信息，格式如下：MAC地址=网卡名
#    附注：该函数保证输出格式正确的小写MAC地址
# 返回：0-成功，
#       1-不存在/sys/class/net目录
function get_current_nic_list(){
    local nic_dir=$g_current_nic_dir
    if [[ ! -d $nic_dir ]]; then
        log_warn "dir $nic_dir not exist"
        return 1
    fi

    local nic_list=$(ls $nic_dir)
    local nic=""
    for nic in $nic_list; do
        local nic_name=""
        ls "${nic_dir}/${nic}" -n | grep -q "pci" 2>/dev/null
        if [[ $? -eq 0 ]]; then
            nic_name=$nic
        fi

        ls "${nic_dir}/${nic}/device" -n 2>/dev/null | grep -q "virtio"
        if [[ $? -eq 0 ]]; then
            nic_name=$nic
        fi

        if [[ -n $nic_name ]]; then
            log_info "Detect NIC: $nic_name"
            local error_code
            nic_mac=$(cat "${nic_dir}/${nic}/address" 2>/dev/null)
            error_code=$?
            if [[ $error_code -ne 0 ]]; then
                log_warn "Cannot cat ${nic_dir}/${nic}/address, errno=$error_code"
            fi

            nic_mac=$(echo "$nic_mac" | tr [A-Z] [a-z] 2>/dev/null)
            echo "${nic_mac}:" | grep -q -E -i '^\s*([0-9a-f]{2}:){6}\s*$' 2>/dev/null
            if [[ $? -ne 0 ]]; then
                log_warn "unknown MAC: ${nic_mac}"
            fi
            echo "${nic_mac}=${nic_name}"
        fi
    done
}

# 网卡信息记录文件：用于保存平台和网卡信息
declare -r g_nic_info_file='/etc/sangfor/nic_info'

# 创建网卡信息记录文件，如果文件存在则覆盖
# 机制：使用get_bios_msg读取BIOS信息，使用get_current_nic_list读取网卡信息
# 输入：无
# 输出：无
# 返回：0 成功
#       1 无法清空/etc/sangfor/nic_info文件
#       2 无法从系统中找到BIOS信息
#       3 无法获得系统当前网卡名单
function build_nic_info_file(){
	if [[ ! -d $(dirname "$g_nic_info_file") ]]; then
		mkdir -p $(dirname "$g_nic_info_file")
	fi

    # 清空文件
    # -n: do not append newline
    echo -n "" > "$g_nic_info_file"
    if [[ $? -ne 0 ]]; then
        log_warn "cannot echo empty string to $g_nic_info_file"
        return 1
    fi
    # 写入当前BIOS信息，作为判断平台的依据
    local bios_msg
    bios_msg=$(get_bios_msg)
    if [[ $? -ne 0 ]]; then
        log_warn "cannot find BIOS msg from system"
        return 2
    fi
    echo "$bios_msg" >> "$g_nic_info_file"
    log_info "[build_nic_info_file] bios_msg=$bios_msg"
    #write info
    local nic_list
    nic_list=$(get_current_nic_list)
    if [[ $? -ne 0 ]]; then
        log_error "error when call get_current_nic_list, errno=$?"
        return 3
    fi
    echo "$nic_list" >> "$g_nic_info_file"
    log_info "[build_nic_info_file] nic_list=$nic_list"
}

# 读取网卡信息记录文件中保存的旧网卡信息
# 输入：无
# 输出：分条输出每张网卡信息，格式如下：MAC地址=网卡名
#    附注：该函数保证输出格式正确的小写MAC地址
# 返回：0-成功，其他-失败
function get_old_nic_list(){
    local nic_info_file=$g_nic_info_file
    if [[ ! -r $nic_info_file ]]; then
        log_warn "NIC backup file $backup_nic_file not exist or not readable"
    fi
    local line=""
    while read line; do
        local nic_mac=${line%=*}
        local nic_name=${line#*=}
        local nic_mac=$(echo "$nic_mac" | tr [A-Z] [a-z] 2>/dev/null)
        echo "${nic_mac}:" | grep -q -E -i '^\s*([0-9a-f]{2}:){6}\s*$' 2>/dev/null
        if [[ $? -ne 0 ]]; then
            log_warn "unknown backup line: $line"
            continue
        fi
        if [[ -n $nic_name ]]; then
            echo "${nic_mac}=${nic_name}"
        fi
    done < "${nic_info_file}"
}

# 获得虚拟机的BIOS信息，此信息可以作为判断虚拟平台类型的根据
# 输入：无
# 输出: 如以下格式：
# "Vendor: xxx"
# 返回：0-成功，1-无法从BIOS信息中提取Vendor字段
function get_bios_msg(){
    local bios_msg=""
    bios_msg=$(dmidecode -t 0 | grep -i -E '^\s*Vendor:')
    # 示例：sangfor是seaBIOS，vmware上不确定
    # Vendor: Phoenix Technologies LTD
    # Vendor: SeaBIOS
    if [[ $? -ne 0 ]]; then
        log_warn "unknown BIOS vendor message, errno=$?"
        echo "Vendor: unknown"
        return 1
    fi
    # echo会去除前后多余的空白，不需加双引号
    echo $bios_msg
}

# 是否需要进行ip恢复
# 判断的标准是BIOS是否发生改变，以及网卡数量问题。
# 输入：无
# 输出：yes-需要，no-不需要
# 返回：0 成功
#       1 无法从/etc/sangfor/nic_info读取BIOS信息
#       2 无法从当前系统查找BIOS信息
function need_ip_recover(){
    local old_msg
    old_msg=$(grep -i -E "^\s*Vendor:" "$g_nic_info_file")
    if [[ $? -ne 0 ]]; then
        log_error "cannot find BIOS msg from $g_nic_info_file"
        return 1
    fi

    local new_msg
    new_msg=$(get_bios_msg)
    if [[ $? -ne 0 ]]; then
        log_error "cannot find BIOS msg from system"
        return 2
    fi

    if [[ $old_msg == $new_msg ]]; then
        echo "no"
        return 0
    fi
	log_info "detect: bios changed" 
    local cnt=0;
    local LINE="";
    while read LINE; do
        echo LINE | grep -E "="
        if [[ $? -eq 0 ]]; then
            (( cnt+=1 ))
        fi
    done < "$g_nic_info_file"
    # 如果显卡数目超过5，则不予恢复。因为网卡的排序可能错乱，详见TD20120
    local NIC_LIMIT=5
    if [[ $cnt -gt $NIC_LIMIT ]]; then
        echo "no"
		log_info "no need recover: nic count=$cnt<=$NIC_LIMIT"
    else
        echo "yes"
        log_info "Need recover: nic count=$cnt<=$NIC_LIMIT"
    fi
}

# 匹配新旧两组网卡信息
# 新网卡信息：从平台上获得的当前网卡信息
# 旧网卡信息：之前保存在网卡信息记录文件中的信息
# 匹配规则：根据MAC地址进行匹配，只匹配后两个字节
# 输入：无
# 输出：格式如下：
#     旧MAC=旧名称->新MAC=新名称
# 返回：0-成功
#       1 调用get_old_nic_list函数失败
#       2 调用get_current_nic_list函数失败
function match_nic(){
    local old_nic_list
    old_nic_list=$(get_old_nic_list)
    if [[ $? -ne 0 ]]; then
        log_error "func get_old_nic_list failed, errno=$?"
        return 1
    fi
    # old_nic_arr=($old_nic_list)

    local new_nic_list
    new_nic_list=$(get_current_nic_list)
    if [[ $? -ne 0 ]]; then
        log_error "func get_current_nic_list failed, errno=$?"
        return 2
    fi
    log_info "Match NIC List: old = $old_nic_list; new = $new_nic_list"

    local new_nic_arr=($new_nic_list)

    # 在匹配时，只需要匹配MAC地址的后两个字节
    # aa:bb:cc:dd:11:22=ens18
    # ee:aa:cc:12:11:22=eth0
    # 此时只需匹配11:22即可，即下标12到16
    # 如果匹配上，则被匹配项清理原有值，防止重复匹配。可以适应多网卡后两个字节一致的情况
    local old_item=""
    for old_item in $old_nic_list; do
        local match=""
        local i=""
        for i in ${!new_nic_arr[@]}; do
            local new_item=${new_nic_arr[$i]}
            # 输入一定是小写MAC
            if [[ ${old_item:12:5} == ${new_item:12:5} ]]; then
                new_nic_arr[$i]='checked'
                match="${old_item}->${new_item}"
                break
            fi
        done
        if [[ -n $match ]]; then
            echo "$match"
        else
            log_warn "Unable to match $old_item"
        fi
    done
}

# IP恢复主函数
# 探测当前系统类型，分别交付不同的函数处理
# 输入：无
# 输出：无
function ip_recover(){
    local sys_type=$(get_system_type)
    log_debug "find system: $sys_type"
    case "$sys_type" in
        "$g_REDHAT_SERIES_TYPE")
            redhat_ip_recover
            ;;
        "$g_DEBIAN_SERIES_TYPE")
            debian_ip_recover
            ;;
        *)
            log_warn "$sys_type not supported so far"
            ;;
    esac
    if [[ $? -ne 0 ]]; then
        log_warn "$sys_type recover IP failed"
    fi
}

# redhat系列的IP恢复
# 机制：得到新旧两组网卡信息并匹配，得到匹配结果
#      匹配结果表明了网卡名称的变化，去修改网卡配置文件，修正网卡名和MAC名
# 例如：    旧网卡  aa:bb:cc:dd:11:22 ens18 配置文件ifcfg-ens18
#          新网卡  ff:cc:dd:aa:11:22 eth0
#     新网卡找不到配置文件，因为系统是按网卡名去搜索配置文件的DEVICE字段的
#     根据网卡的MAC地址实现了ens18->eth0的匹配
#     找到ens18的配置文件ifcfg-XXX，然后把里面的网卡名和MAC替换成新网卡
#     这样系统在查找eth0的网卡配置时，就能找到配置文件，并加载IP配置，实现恢复
# 输入：无
# 输出：无
# 返回：0 成功
#       1 /etc/sysconfig/network-script目录不存在
function redhat_ip_recover(){
    local cfg_dir=$g_redhat_network_cfg_dir
    if [[ ! -d $cfg_dir ]]; then
        log_warn "dir $g_redhat_network_cfg_dir not exist"
        return 1
    fi

    local file_list=$(find "$cfg_dir" -name 'ifcfg-*' -maxdepth 1 -type f)

    local match=$(match_nic)
    local item=""
    for item in $match; do
        log_debug "match:$item"
        local old_nic=${item%->*}
        local old_name=${old_nic#*=}
        local old_mac=${old_nic%=*}
        local new_nic=${item#*->}
        local new_name=${new_nic#*=}
        local new_mac=${new_nic%=*}
        log_debug "deal: $old_mac=$old_name->$new_mac=$new_name"
        local file=""
        # 以下步骤废除与新网卡名匹配的配置文件，使其无效
        # redhat系列会在配置目录下搜索以ifcfg-开头的文件，所以重命名后会废除
        for file in $file_list; do
            if grep -E "^\s*DEVICE=['\"]?${new_name}" "$file"; then
                log_debug "find $file contains DEVICE=$new_name"
                mv "$file" "old_${file}"
                if [[ $? -ne 0 ]]; then
                    log_warn "fail to rename $file"
                fi
            fi
        done
        # 以下步骤搜索与旧网卡名匹配的配置文件，修改配置文件的网卡名和MAC为新网卡的内容,删除UUID字段
        for file in $file_list; do
            if grep -E "^\s*DEVICE=['\"]?${old_name}" "$file"; then
                log_debug "find DEVICE file $file"
                # 替换
                sed -E "s/\b${old_name}\b/${new_name}/g" -i "${file}"
                if [[ $? -ne 0 ]]; then
                    log_warn "unable to replace $old_name with $new_name in $file"
                fi
                # 替换MAC地址：注意匹配时忽略大小写，但是替换后不论大小写都能工作
                sed -E "s/\b${old_mac}\b/${new_mac}/ig" -i "${file}"
                if [[ $? -ne 0 ]]; then
                    log_warn "unable to replace $old_mac with $new_mac in $file"
                fi
                # UUID：删掉
                sed -E "/^\s*UUID=/d" -i "${file}"
                if [[ $? -ne 0 ]]; then
                    log_warn "unable to del UUID line in $file"
                fi
                # 重命名：如果出现多个文件怎么办？重命名并无视错误
                mv "$file" "${cfg_dir}/ifcfg-${new_name}"
                if [[ $? -ne 0 ]]; then
                    log_warn "cmd: mv $file ${cfg_dir}/ifcfg-${new_name} failed, errno=$?"
                fi
            fi
        done
    done
    # 对于persistent-net.rules文件的处理：网卡名和MAC替换成新的
    if [[ -e "$g_persistent_rule_file" ]]; then
        log_debug "find 70-persistent-net"
        #log_debug $(cat "$g_persistent_rule_file")
        sed -E "s/\b${old_name}\b/${new_name}/g" -i "$g_persistent_rule_file" #sed -r????TD
        sed -E "s/\b${old_mac}\b/${new_mac}/ig" -i "$g_persistent_rule_file" #sed -r????TD
        #log_debug "---------after-------"
        #log_debug $(cat "$g_persistent_rule_file")
    fi
    log_debug "restart network "
    # 重启网络服务。
    # 如果不，则会与network服务冲突，导致后者重启失败
    service NetworkManager stop
    if [[ $? -ne 0 ]]; then
        log_warn "fail to stop NetworkManager, errno=$?"
    fi
    service network restart
    if [[ $? -ne 0 ]]; then
        log_error "fail to restart network, errno=$?"
    fi
    service NetworkManager start
    if [[ $? -ne 0 ]]; then
        log_warn "fail to stop NetworkManager, errno=$?"
    fi
    log_debug "recover ip done"
}

# debian系列的IP恢复
# 原理参考redhat的IP恢复
# 输入：无
# 输出：无
# 返回：0 正常
#       1 "/etc/network/interfaces"路径不存在
function debian_ip_recover(){
    local cfg_file=$g_debian_network_cfg
    if [[ ! -f $cfg_file ]]; then
        log_warn "config file $cfg_file not exist"
        return 1
    fi
    match=$(match_nic)
    for item in $match; do
        log_debug "match:$item"
        old_nic=${item%->*}
        old_name=${old_nic#*=}
        old_mac=${old_nic%=*}
        new_nic=${item#*->}
        new_name=${new_nic#*=}
        new_mac=${new_nic%=*}
        log_debug "$old_mac $old_name $new_mac $new_name"

        sed -E "s/\b${old_name}\b/${new_name}/g" -i "$cfg_file"
        sed -E "s/\b${old_mac}\b/${new_mac}/ig" -i "$cfg_file"
    done
# 对于persistent-net.rules文件的处理：网卡名和MAC替换成新的
    if [[ -e "$g_persistent_rule_file" ]]; then
        log_debug "find 70-persistent-net"

        sed -E "s/\b${old_name}\b/${new_name}/g" -i "$g_persistent_rule_file" #sed -r????TD
        sed -E "s/\b${old_mac}\b/${new_mac}/ig" -i "$g_persistent_rule_file" #sed -r????TD
    fi
    # 重启网络服务
    log_debug "restart network"
	#某些情况下直接重启service会失败，因此改用ifdown和ifup
    #参考https://blog.csdn.net/ah_luozhi/article/details/51427679
	ifdown -a && ifup -a
    if [[ $? -ne 0 ]]; then
        log_warn "fail to restart network, errno=$?, try again"
		/etc/init.d/networking restart || log_warn "fail to restart network, errno=$?"
    fi
    log_debug "recover ip done"

}
