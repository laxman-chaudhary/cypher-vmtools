#!/bin/bash
shopt -s  expand_aliases
shopt expand_aliases
shell_dir=`dirname "${BASH_SOURCE[0]}"`

TMP_DIR=""
TEST_DATA_DIR="/tmp/test_data" #the dir of unit test 

alias cat='test_cat(){ 
if [ "$1" = "/proc/stat" -o "$1" = "/proc/diskstats" ]; then
	if [ -L "${TMP_DIR}/$1" ]; then
		ln -sf "${TMP_DIR}/$1"2 "${TMP_DIR}/$1"; 
	else ln -sf "${TMP_DIR}/$1"1 "${TMP_DIR}/$1";
	fi;
fi; 
cat ${TMP_DIR}/$1; 
}; test_cat'
alias df='test_df(){ cat ./df.txt; }; test_df'
alias uname='test_uname(){  cat "./uname$1.txt"; }; test_uname'
alias ls='test_ls(){ ls ./$@; }; test_ls'
alias lspci='cat ./lspci.txt'
alias ip='test_ip(){ sed -n "/${3}/{/inet/p}" ./ipaddr.txt; }; test_ip'

vm_ipc_to_local_host()
{
	echo $@ >> "${shell_dir}"/tmp.txt
}

test_start()
{
	echo "start test $1"
	vm_ipc_init  666 666
	if [ $? -ne 0 ]; then
		log "vm_ipc_init() failed! modid='${modid}' instid='${instid}'"
		return 1
	fi
	send_os_version_to_host
	if [ $? -ne 0 ]; then
		log "send os version to host failed!"
		return 1
	fi
	send_os_info_to_host
	if [ $? -ne 0 ]; then
		log "send info to host failed!"
		return 1
	fi
	echo "" > "${shell_dir}"/tmp.txt
	send_os_version_to_host
	if [ $? -ne 0 ]; then
		log "send os version to host failed!"
		return 1
	fi
	send_os_info_to_host
	if [ $? -ne 0 ]; then
		log "send info to host failed!"
		return 1
	fi

	return 0
}

init_test_env()
{
	if [ -d ${TEST_DATA_DIR} ]; then
		rm -rf ${TEST_DATA_DIR}
	fi
	mkdir -p ${TEST_DATA_DIR}
	cd "${shell_dir}/collect_data"
	for FILE in `ls *.tar.gz`
	do
		#Get the file name of the catalog of tar,then create the corresponding directory
		os_dir=`basename ${FILE} .tar.gz`
		mkdir -p "${TEST_DATA_DIR}/${os_dir}"
		#Decompress the catalog of tar into corresponding directory,pay attention to the path of this file
		tar -zmxf "${shell_dir}/collect_data/${FILE}" -C "${TEST_DATA_DIR}/${os_dir}"
		TMP_DIR="${TEST_DATA_DIR}/${os_dir}"
		cd "${TMP_DIR}"
		test_start "${TMP_DIR}" || echo "exec ${TMP_DIR} failed!"
		#check the test result right of wrong
		result_file="${shell_dir}/collect_data/${os_dir}.txt"
		test -e "${result_file}"
		if [ $? -eq 0 ]; then
			diff -r "${shell_dir}/tmp.txt" "${result_file}" 
			if [ $? -eq 0 ]; then 
				rm -rf "${shell_dir}/tmp.txt"
				echo "${result_file} test success!"
			else
				mv "${shell_dir}/tmp.txt" "${shell_dir}/${os_dir}_diff.txt"
				echo "${result_file} test failed!"
			fi
		else 
			# if the file is not exist , then rename the file, check the result right of wrong end pigeonhole
			mv "${shell_dir}/tmp.txt" "${shell_dir}/${os_dir}.txt"
			echo "you should check the file data right or wrong!"
		fi
	done
}

main()
{
	init_test_env
}
