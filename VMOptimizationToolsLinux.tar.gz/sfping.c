#include <stdlib.h>
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <errno.h>
#include <assert.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/types.h>

#define lerror printf
#define ldebuga printf

#define ICMP_SEND_SUCCESS         (0)
#define ICMP_RECV_TIMEOUT         (1)
#define ICMP_SEND_ERROR_OTHER     (255)

#define SOCKET_ERROR              (-1)
#define INVALID_SOCKET             (-1)
//���صĽ��ֵ
int g_res_errno = ICMP_SEND_SUCCESS;

#define RECV_BUF_LEN 400

//����һ������
typedef int sf_int32_t;
typedef unsigned long long sf_uint64_t;
typedef unsigned int sf_uint32_t;
typedef unsigned short sf_uint16_t;
typedef unsigned char sf_uint8_t;
typedef char sf_char_t;

//�ֽ���ת��
static inline sf_int32_t sf_constant_bswap32(sf_uint32_t x)
{
    return ((x & 0x000000ffUL) << 24) |
           ((x & 0x0000ff00UL) << 8) |
           ((x & 0x00ff0000UL) >> 8) |
           ((x & 0xff000000UL) >> 24);
}

/**
 * An internal function to swap bytes of a 64-bit value.
 *
 * It is used by sf_bswap64() when the value is constant. Do not use
 * this function directly; sf_bswap64() is preferred.
 */
static inline sf_uint64_t
sf_constant_bswap64(sf_uint64_t x)
{
    return ((x & 0x00000000000000ffULL) << 56) |
           ((x & 0x000000000000ff00ULL) << 40) |
           ((x & 0x0000000000ff0000ULL) << 24) |
           ((x & 0x00000000ff000000ULL) <<  8) |
           ((x & 0x000000ff00000000ULL) >>  8) |
           ((x & 0x0000ff0000000000ULL) >> 24) |
           ((x & 0x00ff000000000000ULL) >> 40) |
           ((x & 0xff00000000000000ULL) >> 56);
}

//�����ֽ�ת��Ϊ�����ֽ�
#define sf_htonl(x) sf_constant_bswap32(x)
//�����ֽ�ת���������ֽ�
#define sf_ntohl(x) sf_constant_bswap32(x)


//�����ֽ�ת��Ϊ�����ֽ�
#define sf_htonll(x) sf_constant_bswap64(x)
//�����ֽ�ת���������ֽ�
#define sf_ntohll(x) sf_constant_bswap64(x)

//����icmpħ��
#define VT_ICMP_DEBUG_PATH_MAGIC  0x13579BDF
#define VT_ICMP_DEBUG_PATH_TTL  0xff

#define VT_ICMP6_DEBUG_PATH_MAGIC  0x13579BDE
#define ICMP_ECHO_REQUSET       8
#define ICMP_ECHO_REPLY         0
#define ICMP6_ECHO_REQUSET      128
#define ICMP6_ECHO_REPLY        129
/*
 * Structure of an internet header, naked of options.
 */
typedef struct sf_iphdr_
{
#ifdef SF_LITTLE_ENDIAN
    sf_uint8_t	ip_hl: 4,		/* header length */
                ip_v: 4;			/* version */
#else
    sf_uint8_t	ip_v: 4,			/* version */
                ip_hl: 4;		/* header length */
#endif
    sf_uint8_t	ip_tos;			/* type of service */
    sf_uint16_t	ip_len;			/* total length */
    sf_uint16_t	ip_id;			/* identification */
    sf_uint16_t	ip_off;			/* fragment offset field */
#define	IP_RF 0x8000			/* reserved fragment flag */
#define	IP_DF 0x4000			/* dont fragment flag */
#define	IP_MF 0x2000			/* more fragments flag */
#define	IP_OFFMASK 0x1fff		/* mask for fragmenting bits */
    sf_uint8_t	ip_ttl;			/* time to live */
    sf_uint8_t	ip_p;			/* protocol */
    sf_uint16_t	ip_sum;			/* checksum */
    sf_uint32_t     ip_src, ip_dst;	/* source and dest address */
} sf_iphdr_t; // __packed __aligned(4);

/*
 * Internal of an ICMP Router Advertisement
 */
typedef struct icmp_ra_addr_
{
    sf_int32_t ira_addr;
    sf_int32_t ira_preference;
} sf_icmp_ra_addr_t;

/*
 * Structure of an icmp header.
 */
typedef struct sf_icmphdr_
{
    sf_uint8_t	icmp_type;		/* type of message, see below */
    sf_uint8_t	icmp_code;		/* type sub code */
    sf_uint16_t	icmp_cksum;		/* ones complement cksum of struct */
} sf_icmphdr_t;

typedef struct sf_icmp_
{
    sf_uint8_t	icmp_type;		/* type of message, see below */
    sf_uint8_t	icmp_code;		/* type sub code */
    sf_uint16_t	icmp_cksum;		/* ones complement cksum of struct */
    union
    {
        sf_uint8_t ih_pptr;			/* ICMP_PARAMPROB */
        sf_uint32_t ih_gwaddr;	/* ICMP_REDIRECT */
        struct ih_idseq
        {
            sf_uint16_t	icd_id;	/* network format */
            sf_uint16_t	icd_seq; /* network format */
        } ih_idseq;
        sf_int32_t ih_void;

        /* ICMP_UNREACH_NEEDFRAG -- Path MTU Discovery (RFC1191) */
        struct ih_pmtu
        {
            sf_uint16_t ipm_void;	/* network format */
            sf_uint16_t ipm_nextmtu;	/* network format */
        } ih_pmtu;

        struct ih_rtradv
        {
            sf_uint8_t irt_num_addrs;
            sf_uint8_t irt_wpa;
            sf_uint16_t irt_lifetime;
        } ih_rtradv;
    } icmp_hun;
#define	icmp_pptr	icmp_hun.ih_pptr
#define	icmp_gwaddr	icmp_hun.ih_gwaddr
#define	icmp_id		icmp_hun.ih_idseq.icd_id
#define	icmp_seq	icmp_hun.ih_idseq.icd_seq
#define	icmp_void	icmp_hun.ih_void
#define	icmp_pmvoid	icmp_hun.ih_pmtu.ipm_void
#define	icmp_nextmtu	icmp_hun.ih_pmtu.ipm_nextmtu
#define	icmp_num_addrs	icmp_hun.ih_rtradv.irt_num_addrs
#define	icmp_wpa	icmp_hun.ih_rtradv.irt_wpa
#define	icmp_lifetime	icmp_hun.ih_rtradv.irt_lifetime
    union
    {
        struct id_ts  			/* ICMP Timestamp */
        {
            /*
             * The next 3 fields are in network format,
             * milliseconds since 00:00 GMT
             */
            sf_uint32_t its_otime;	/* Originate */
            sf_uint32_t its_rtime;	/* Receive */
            sf_uint32_t its_ttime;	/* Transmit */
        } id_ts;
        struct id_ip
        {
            sf_iphdr_t idi_ip;
            /* options and then 64 bits of data */
        } id_ip;
        sf_icmp_ra_addr_t id_radv;
        sf_uint32_t id_mask;
        sf_uint8_t	id_data[1];
    } icmp_dun;
#define	icmp_otime	icmp_dun.id_ts.its_otime
#define	icmp_rtime	icmp_dun.id_ts.its_rtime
#define	icmp_ttime	icmp_dun.id_ts.its_ttime
#define	icmp_ip		icmp_dun.id_ip.idi_ip
#define	icmp_radv	icmp_dun.id_radv
#define	icmp_mask	icmp_dun.id_mask
#define	icmp_data	icmp_dun.id_data
} sf_icmp_t;

typedef struct icmp6_hdr {
    u_int8_t    icmp6_type;    /* type field */
    u_int8_t    icmp6_code;    /* code field */
    u_int16_t    icmp6_cksum;    /* checksum field */
    union {
        u_int32_t    icmp6_un_data32[1]; /* type-specific field */
        u_int16_t    icmp6_un_data16[2]; /* type-specific field */
        u_int8_t     icmp6_un_data8[4];  /* type-specific field */
    } icmp6_dataun;
    #define	icmp6_data	icmp6_dataun.icmp6_un_data32
} __attribute__((packed)) sf_icmp6_t;

//���԰�����������
typedef enum vt_debug_pkt_src_type_
{
    VT_DEBUG_VR,
    VT_DEBUG_VM
} vt_debug_pkt_src_type_t;

typedef struct vt_debug_pkt_src_
{
    sf_uint8_t type;
    sf_uint32_t version;	//���԰汾��
    sf_uint32_t pkt_id;	    //���Ա���id
    sf_uint64_t hostid;    //������id
    sf_uint64_t vmid;      //�����id
    sf_uint32_t ifid;      //���������id
} vt_debug_pkt_src_t;

typedef struct vt_icmp_path_pkt_
{
    sf_icmp_t icmp;        //icmpͷ��
    sf_uint8_t  reserv[4]; //icmpԤ���ֶ�
    union //���Ա����ڲ��ֶ�
    {
        sf_uint32_t  data[64];
        struct
        {
            vt_debug_pkt_src_t src;
            sf_uint32_t magic_id;  //���Ա��ı��λ��  VT_ICMP_DEBUG_PATH_MAGIC
            sf_uint32_t pkt_index;
        } vt_icmp_s;
    } vt_icmp_u;
#define path_magic_id  vt_icmp_u.vt_icmp_s.magic_id
#define path_src  vt_icmp_u.vt_icmp_s.src
#define path_index  vt_icmp_u.vt_icmp_s.pkt_index
} vt_icmp_path_pkt_t;

/*add debug path support ipv6*/
typedef struct vt_icmp6_path_pkt_ {
	sf_icmp6_t icmp6;        //icmpͷ��
	sf_uint8_t  reserv[4]; //icmpԤ���ֶ�
	union{//���Ա����ڲ��ֶ�
		sf_uint32_t  data[64];
		struct{
			vt_debug_pkt_src_t src;			
			sf_uint32_t magic_id;  //���Ա��ı��λ��  VT_ICMP_DEBUG_PATH_MAGIC
			sf_uint32_t pkt_index;
		}vt_icmp6_s;
	}vt_icmp6_u;
	#define path6_magic_id  vt_icmp6_u.vt_icmp6_s.magic_id
	#define path6_src  vt_icmp6_u.vt_icmp6_s.src
	#define path6_index  vt_icmp6_u.vt_icmp6_s.pkt_index
}vt_icmp6_path_pkt_t;

typedef struct  _PingMsg
{
    sf_uint32_t version;
    sf_uint64_t vmid;
    sf_uint64_t hostid;
    sf_uint32_t pkt_id;
    sf_uint32_t ifid;
    char * dstip;
} PingMsg;

//************************************
// Method:    checksum
// brief:     ����У���ֽ�
// author:    laoyi
// date:      2015/03/17
// Parameter: [IN ][sf_uint16_t * buff]    ����
// Parameter: [IN ][int size]         ���ݵĳ���
// Returns:   [sf_uint8_t]                У��ֵ
//************************************
static sf_uint16_t vt_checksum(sf_uint16_t * buff, int size)
{
    int nleft = size;
    int sum = 0;
    sf_uint16_t * w = buff;
    sf_uint16_t answer = 0;

    while (nleft > 1)
    {
        sum += *w++;
        nleft -= 2;
    }

    if (nleft == 1)
    {
        *(sf_uint8_t *)(&answer) = *(sf_uint8_t *)w;
        sum += answer;
    }

    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);

    answer = ~sum;
    return answer;
}

static int vt_setTTL(int s, int nValue)
{
    int ret = setsockopt(s, IPPROTO_IP, IP_TTL, (char *)&nValue, sizeof(nValue));
    return ret;
}

static int vt_settimeout(int s, int nTime, int bRecv)
{
    int ret = 0;
#ifdef _WIN32

    ret = setsockopt(s, SOL_SOCKET,
                     bRecv ? SO_RCVTIMEO : SO_SNDTIMEO, (char *)&nTime, sizeof(nTime));
    if (ret < 0)
    {
        lerror("setsockopt timeout failed! errno = %d,%s\n", errno, strerror(errno));
    }

#else
    struct timeval timeout;
    timeout.tv_sec = nTime;
    timeout.tv_usec = 0;
    ret = setsockopt(s, SOL_SOCKET,
                     bRecv ? SO_RCVTIMEO : SO_SNDTIMEO, &timeout, sizeof(timeout));
    if (ret < 0)
    {
        lerror("setsockopt timeout failed! errno = %d,%s\n", errno, strerror(errno));
    }
#endif

    return ret ;
}

#if 0
//************************************
// Method:    vt_ipv4_legal
// brief:	  ��֤ipv4 �Ƿ�Ϸ���ip
// author:    laoyi
// date:      2014/09/17
// Parameter: [IN ][const char * ip]  ip�ַ���
// Returns:   [int32_t]               �Ϸ�����0�����Ϸ�����-1
//************************************
int32_t vt_ipv4_legal(const char * ip)
{
    if (ip == NULL)
    {
        LogError(_T("sagent_ipv4_legal has null params!\n"));
        return -1;
    }

    struct in_addr addr;
    if (inet_pton(AF_INET, ip, &addr) <= 0)
    {
        //LogError(_T("ip = %s is not ipv4!errno = %d,errmsg = %s.\n"), ip,
        //     errno, strerror(errno));
        return -1;
    }

    return 0;
}

#endif

static int vt_icmp_test_send_recv(int sock, char *data, int data_len, 
    struct sockaddr * dest, int addr_len)
{
    assert(sock > -1 && dest && data);

    int nRet = sendto(sock, data, data_len, 0, dest, addr_len);
    if (nRet == SOCKET_ERROR)
    {
        lerror(" sendto() failed: %d \n", errno);
        return -1;
    }

    char recvBuf[20 + sizeof(sf_icmp_t)] = {0};
    struct sockaddr from;
    socklen_t nLen = sizeof(from);

    nRet = recvfrom(sock, recvBuf, 20 + sizeof(sf_icmp_t) , 0,
                    &from, &nLen);
    if (nRet == SOCKET_ERROR)
    {
        if (errno == ETIMEDOUT)
        {
            lerror(" timed out\n");
            return -1;
        }

        lerror(" recvfrom() failed: %d\n", errno);
        return -1;
    }

    return 0;
}

static int vt_icmp6_send(PingMsg * ping_msg)
{
    assert(ping_msg);
    assert(ping_msg->dstip);

    vt_icmp6_path_pkt_t path;
    memset(&path, 0, sizeof(path));

    int sRaw = socket(AF_INET6, SOCK_RAW, IPPROTO_ICMPV6);
    if (sRaw == INVALID_SOCKET)
    {
        lerror("create socket failed! errno = %s\n", strerror(errno));
        g_res_errno = ICMP_SEND_ERROR_OTHER;
        return -1;
    }

    if (vt_settimeout(sRaw, 1, 1) < 0)
    {
        lerror("vt_settimeout failed!\n");
        g_res_errno = ICMP_SEND_ERROR_OTHER;
        return -1;
    }

    struct sockaddr_in6 dest;
    dest.sin6_family = AF_INET6;
    dest.sin6_port = htons(0);
    if (inet_pton(AF_INET6, ping_msg->dstip, &dest.sin6_addr) <= 0)
    {
        lerror("illagel ipv6 address : %s", ping_msg->dstip);
    }

    // pad and send icmp6 echo request packet and recive echo reply
    path.icmp6.icmp6_type = ICMP6_ECHO_REQUSET;
    path.icmp6.icmp6_code = 0;
    path.icmp6.icmp6_cksum = 0;
    path.icmp6.icmp6_data[0] = (u_int32_t)getpid();
    path.icmp6.icmp6_cksum = vt_checksum((sf_uint16_t *)&path.icmp6, sizeof(path.icmp6));

    // send test packet
    if (vt_icmp_test_send_recv(sRaw, (char *)&path.icmp6, sizeof(path.icmp6),
        (struct sockaddr *)&dest, sizeof(dest)) < 0)
    {
        lerror("vt_icmp6_test_send_recv failed!\n");
    }

    // test pkg donot add debug data,
    // just send only one debug pkt, in case of dp inform duplicate pkts to sdn
    path.path6_magic_id = sf_htonl(VT_ICMP6_DEBUG_PATH_MAGIC);
    path.path6_src.type = VT_DEBUG_VM;
    path.path6_src.version = sf_htonl(ping_msg->version);
    path.path6_src.vmid = sf_htonll(ping_msg->vmid);
    path.path6_src.hostid = sf_htonll(ping_msg->hostid);
    path.path6_src.pkt_id = sf_htonl(ping_msg->pkt_id);
    path.path6_src.ifid = sf_htonl(ping_msg->ifid);
    path.icmp6.icmp6_cksum = vt_checksum((sf_uint16_t *)&path, sizeof(path));

    ldebuga("icmp head bytes = %d\n", (int)sizeof(sf_icmp6_t));
    ldebuga("path bytes = %d\n", (int)sizeof(path));
    ldebuga("send icmp checksum = %0x\n", path.icmp6.icmp6_cksum);

    char recvBuf[RECV_BUF_LEN] = {0};
    struct sockaddr_in from;
    socklen_t nLen = sizeof(from);

    int nRet = sendto(sRaw, (char *)&path, sizeof(path), 0,
                            (struct sockaddr *)&dest, sizeof(dest));
    if (nRet == SOCKET_ERROR)
    {
        lerror("sendto() failed: %d\n", errno);
        g_res_errno = errno;
        return -1;
    }

    nRet = recvfrom(sRaw, recvBuf, RECV_BUF_LEN, 0,
                    (struct sockaddr *)&from, &nLen);
    if (nRet == SOCKET_ERROR)
    {
        if (errno == ETIMEDOUT)
        {
            lerror("timed out\n");
        } else {
            lerror("recvfrom() failed: %d\n", errno);
        }
        g_res_errno = errno;
        return -1;
    }

    vt_icmp6_path_pkt_t * recv_pkt = (vt_icmp6_path_pkt_t *)recvBuf;
    if (recv_pkt->icmp6.icmp6_type != ICMP6_ECHO_REPLY)
    {
        lerror("error echo type %d recvd \n", recv_pkt->icmp6.icmp6_type);
        g_res_errno = ICMP_SEND_ERROR_OTHER;
        return -1;
    }

    if (recv_pkt->icmp6.icmp6_data[0] != getpid())
    {
        lerror(" someone else's packet! \n");
        g_res_errno = ICMP_SEND_ERROR_OTHER;
        return -1;
    }

    // print debug info
    ldebuga("recv bytes %d\n", nRet);
    ldebuga("type = %u, version = %u, pktid = %u, hostid = %llu,"
            " vmid = %llu, ifid = %u\n",
            recv_pkt->path6_src.type,
            sf_ntohl(recv_pkt->path6_src.version),
            sf_ntohl(recv_pkt->path6_src.pkt_id),
            sf_ntohll(recv_pkt->path6_src.hostid),
            sf_ntohll(recv_pkt->path6_src.vmid),
            sf_ntohl(recv_pkt->path6_src.ifid));

    g_res_errno = ICMP_SEND_SUCCESS;
    return 0;

}

static int vt_icmp_send(PingMsg * ping_msg)
{
    assert(ping_msg);
    assert(ping_msg->dstip);

    vt_icmp_path_pkt_t path;
    memset(&path, 0, sizeof(path));

    // ����ԭʼ�׽���
    int sRaw = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);
    if (sRaw == INVALID_SOCKET)
    {
        lerror("create socket failed! errno = %s\n", strerror(errno));
        g_res_errno = ICMP_SEND_ERROR_OTHER;
        return -1;
    }

    // ���ý��ճ�ʱ
    if (vt_settimeout(sRaw, 1, 1) < 0)
    {
        lerror("vt_settimeout failed!\n");
        g_res_errno = ICMP_SEND_ERROR_OTHER;
        return -1;
    }

    //����ttl Ϊ64
    if (vt_setTTL(sRaw, 64) < 0)
    {
        lerror("vt_settimeout failed!\n");
        g_res_errno = ICMP_SEND_ERROR_OTHER;
        return -1;
    }

    // ����Ŀ�ĵ�ַ
    struct sockaddr_in dest;
    dest.sin_family = AF_INET;
    dest.sin_port = htons(0);
    dest.sin_addr.s_addr = inet_addr(ping_msg->dstip);

    // ��дICMP������ݣ�����һ��ICMP����
    path.icmp.icmp_type = ICMP_ECHO_REQUSET;
    path.icmp.icmp_code = 0;
    path.icmp.icmp_cksum = 0;
    path.icmp.icmp_id = (sf_uint16_t)getpid();
    path.icmp.icmp_seq = 1;
    path.icmp.icmp_cksum = vt_checksum((sf_uint16_t *)&path.icmp, sizeof(path.icmp));

    //���Ͳ��԰�
    if (vt_icmp_test_send_recv(sRaw, (char *)&path.icmp, sizeof(path.icmp), 
        (struct sockaddr *)&dest, sizeof(dest)) < 0)
    {
        lerror("vt_icmp_test_send_recv failed!\n");
    }

    // test pkg donot add debug data,
    // just send only one debug pkt, in case of dp inform duplicate pkts to sdn
    path.path_magic_id = sf_htonl(VT_ICMP_DEBUG_PATH_MAGIC);
    path.path_src.type = VT_DEBUG_VM;
    path.path_src.version = sf_htonl(ping_msg->version);
    path.path_src.vmid = sf_htonll(ping_msg->vmid);
    path.path_src.hostid = sf_htonll(ping_msg->hostid);
    path.path_src.pkt_id = sf_htonl(ping_msg->pkt_id);
    path.path_src.ifid = sf_htonl(ping_msg->ifid);
    path.icmp.icmp_cksum = vt_checksum((sf_uint16_t *)&path, sizeof(path));

    ldebuga("icmp size = %d\n", (int)sizeof(sf_icmp_t));
    ldebuga("path size = %d\n", (int)sizeof(path));
    ldebuga("send icmp checksum = %0x\n", path.icmp.icmp_cksum);

    // ��ʼ���ͺͽ���ICMP���
    char recvBuf[20 + sizeof(vt_icmp_path_pkt_t)] = {0};
    struct sockaddr_in from;
    socklen_t nLen = sizeof(from);

    int nRet = sendto(sRaw, (char *)&path, sizeof(path), 0,
                      (struct sockaddr *)&dest, sizeof(dest));
    if (nRet == SOCKET_ERROR)
    {
        lerror("sendto() failed: %d\n", errno);
        g_res_errno = errno;
        return -1;
    }

    nRet = recvfrom(sRaw, recvBuf, 20 + sizeof(vt_icmp_path_pkt_t), 0,
                    (struct sockaddr *)&from, &nLen);
    if (nRet == SOCKET_ERROR)
    {
        if (errno == ETIMEDOUT)
        {
            lerror("timed out\n");
        } else {
            lerror("recvfrom() failed: %d\n", errno);
        }
        g_res_errno = errno;
        return -1;
    }

    // ���յ��������а���IPͷ��IPͷ��СΪ20���ֽڣ����Լ�20�õ�ICMPͷ
    // (ICMP_HDR*)(recvBuf + sizeof(IPHeader));
    vt_icmp_path_pkt_t * recv_pkt = (vt_icmp_path_pkt_t *)(recvBuf + 20);
    if (recv_pkt->icmp.icmp_type != ICMP_ECHO_REPLY)   // ����
    {
        lerror("nonecho type %d recvd \n", recv_pkt->icmp.icmp_type);
        g_res_errno = ICMP_SEND_ERROR_OTHER;
        return -1;
    }

    if (recv_pkt->icmp.icmp_id != getpid())
    {
        lerror(" someone else's packet! \n");
        g_res_errno = ICMP_SEND_ERROR_OTHER;
        return -1;
    }

    ldebuga("type = %u,version = %u,pktid = %u,hostid = %llu,vmid = %llu,ifid = %u\n",
            recv_pkt->path_src.type,
            sf_ntohl(recv_pkt->path_src.version),
            sf_ntohl(recv_pkt->path_src.pkt_id),
            sf_ntohll(recv_pkt->path_src.hostid),
            sf_ntohll(recv_pkt->path_src.vmid),
            sf_ntohl(recv_pkt->path_src.ifid));

    g_res_errno = ICMP_SEND_SUCCESS;
    return 0;
}

void show_usage(const char * proc)
{
    printf("%s version vmid hostid pktid ifid dstip\n", proc);
}

int main(int argc, char * argv[])
{
    if (argc != 7)
    {
        show_usage(argv[0]);
        exit(1);
    }
    int ret = 0;

    PingMsg ping_msg;
    memset(&ping_msg, 0, sizeof(ping_msg));

    ping_msg.version = atoi(argv[1]);
    ping_msg.vmid = atol(argv[2]);
    ping_msg.hostid = atol(argv[3]);
    ping_msg.pkt_id = atoi(argv[4]);
    ping_msg.ifid = atoi(argv[5]);
    ping_msg.dstip = strdup(argv[6]);

    printf("version = %u\n", ping_msg.version);
    printf("vmid = %llu", ping_msg.vmid);
    printf("hostid = %llu\n", ping_msg.hostid);
    printf("pkt_id = %u\n", ping_msg.pkt_id);
    printf("ifid = %u\n", ping_msg.ifid);
    printf("dstip = %s\n", ping_msg.dstip);

    struct in_addr addr;
    struct in6_addr addr6;
    if (inet_pton(AF_INET, ping_msg.dstip, &addr) > 0)
    {
        printf("send icmp4 pkt!!\n");
        ret = vt_icmp_send(&ping_msg);
    }
    else if (inet_pton(AF_INET6, ping_msg.dstip, &addr6) > 0)
    {
        printf("send icmp6 pkt!!\n");
        ret = vt_icmp6_send(&ping_msg);
    }
    else
    {
        printf("error address %s!\n", ping_msg.dstip);
        exit(1);
    }

    if (ret < 0)
    {
        printf("ping_msg failed!\n");
    }
    else
    {
        printf("send success!\n");
    }

    if (ping_msg.dstip)
    {
        free(ping_msg.dstip);
    }

    exit(g_res_errno);
}

