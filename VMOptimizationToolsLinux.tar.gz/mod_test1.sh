#!/bin/bash

# Test code，Used for testing the transmission module

shell_dir=`dirname "$0"`
. "${shell_dir}/vm_ipc.sh"

proc_msg_10006()
{
	local peer_modid=${1}
	local peer_instid=${2}
	local datafile=${3}
	local data=`cat "${datafile}"`
	
	echo "recv data from mod ${peer_modid} inst ${peer_instid}: ${data}"
	
	# Back to the pack for test
	local answer='{"name":"mod_test1", "age":"9999", "note":"hello world!"}'
	
	vm_ipc_to_self ${peer_modid} ${peer_instid} 10005 "${answer}" || return 1
	echo "answer: ${answer}"
	return 0
}

main()
{
	local modid=555
	local instid=0
	vm_ipc_init ${modid} ${instid}
	if [ $? -ne 0 ]; then
		log "vm_ipc_init() failed! modid='${modid}' instid='${instid}'"
		return 1
	fi
	
	vm_ipc_reg_callback 10006 proc_msg_10006
	
	vm_ipc_to_self 123 234 10005 '{"name":"mod_test1", "age":"9999", "note":"hello world!"}'
	
	while true
	do
		vm_ipc_event_loop_once
		sleep 1
	done
}

main