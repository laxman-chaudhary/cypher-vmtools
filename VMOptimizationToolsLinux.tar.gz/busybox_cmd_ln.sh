#!/bin/bash

#Please use shell built-in commands
#open aliase features
shopt -s expand_aliases

#get current path
g_current_dir=$(cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd)

. "${g_current_dir}/log.sh"

#The log file path.
log_file="/var/log/sangfor_busybox_cmd_ln.log"
set_log_filepath "${log_file}"

function log_exit()
{
    log "$@"
    exit 0
}

bin="/usr/bin/"
[ ! -d "$bin" ] && bin="/bin/"

#check system is x86 or x64
x86_or_x64=""
info="`uname -a 2>/dev/null`"
if [ x"${info/x86_64/}" = x"${info}" ];then
    #x86
    x86_or_x64="x86"
else
    x86_or_x64="x64"
fi
log "system is ${x86_or_x64}"


#check the system supports busybox x86 or x64 or none
busybox_path=""
if [ x"$x86_or_x64" == x"x86" ];then
    busybox_path="${g_current_dir}/tools_x86/busybox"
elif [ x"$x86_or_x64" == x"x64" ];then
    busybox_path="${g_current_dir}/tools_x64/busybox"
else
    log_exit "Err: System not supports busybox."
fi
log "busybox_path: ${busybox_path}"


if ! type busybox > /dev/null 2>&1 ; then
    $busybox_path cp -af "$busybox_path" $bin || log_exit "Err: ${busybox_path}"
fi

#check ln/sed cmd
type ln > /dev/null 2>&1 ||  busybox ln -sf $(which busybox) "${bin}/ln"
type sed > /dev/null 2>&1 || ln -sf $(which busybox) "${bin}/sed"

#busybox commands
busybox_help=$(busybox)
busybox_cmd_str=$(echo $busybox_help | sed -n 's/.*Currently defined functions:\(.*\)/\1/p')
busybox_cmd_str=$(echo $busybox_cmd_str | sed 's/,//'g)

function m_base64()
{
    type base64 > /dev/null 2>&1 && return
    if [ x"$x86_or_x64" == x"x86" ];then
        cp -af "${g_current_dir}/tools_x86/base64" $bin
    elif [ x"$x86_or_x64" == x"x64" ];then
        cp -af "${g_current_dir}/tools_x64/base64" $bin
    else
        log_exit "Err: System not supports base64."
    fi
}

function main()
{
    for busybox_cmd in $busybox_cmd_str; do
        type $busybox_cmd > /dev/null 2>&1
        if [ $? -ne 0 ] ; then
            #str="alias ${cmd_str}=\"busybox ${cmd_str}\""
            #eval $str
            ln -sf $(which busybox) "${bin}/${busybox_cmd}"
            if [ $? -ne 0 ];then
                log "Err: ln -s $(which busybox)  ${bin}/${busybox_cmd}"
            else
                log "OK: ln -s $(which busybox) ${bin}/${busybox_cmd}"
            fi
        fi
    done
	m_base64
}

main
