#!/bin/bash
# shellcheck disable=SC2013,SC2154,SC2162,SC2004
shell_dir=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
. "${shell_dir}/vmconfig_common_func"


function convert_version_to_float()
{
    local version=$1
    echo "$version" | awk -F "." '{print $1"."$2$3 + 0}'
}

function cmp_version()
{
    local version1=$1
    local version2=$2

    local ret
    local version1_f
    local version2_f
    version1_f=$(convert_version_to_float "$version1")
    version2_f=$(convert_version_to_float "$version2")

    ret=$(awk -v v1="$version1_f" -v v2="$version2_f" 'BEGIN { print(v1<v2 ? 1 : 0) }')
    if [[ "$ret" -eq 1 ]]; then
        echo "LESS"
    elif [[ x"$version1_f" = x"$version2_f" ]]; then
        echo "EQUAL"
    else
        echo "MORE"
    fi
}

#判断系统版本是否大于1804
is_new_ubuntu()
{
    local res
    local ver=`lsb_release -r --short`

    # 版本号除了数字就是点，暂时没见过有特殊符号的版本信息
    # 出现特殊符号的版本，有netplan工具返回0，否则返回1；ubuntu18_gen_network_cfg_file函数设置IP使用netplan工具
    res=`echo "$ver" |  grep '^[[:digit:].]*$'`
    if [ $? -ne 0 ];then
        which netplan 1>&2 2>/dev/null
        if [ $? -eq 0 ];then
            return 0
        else
            return 1
        fi
    fi

    res=`cmp_version "$ver" "18.03"`
    if [ x"$res" == x"MORE" ];then
        return 0
    fi
    return 1
}


# Ubuntu18系统生成网络配置文件
# param $1: ifname,eg:eth0
# param $2: protocol,eg:dhcp|static
# param $3: ip,eg:192.168.100.100,2009::234
# param $4: net mask,eg:255.255.255.0,64
# param $5: gateway,eg:192.168.100.1,2009::1
# param $6: ip类型 ipv4 or ipv6
ubuntu18_gen_network_cfg_file()
{
    local ifname=$1
    local protocol=$2
    local ipaddr=$3
    local netmask=$4
    local gateway=$5
    local ip_type=$6
    local backup_netcfg=""
    local tar_netcfg=""
    local err_str=""

    test -z "$ifname" && return 1
    if [ x"$protocol" != x"$PROTO_STATIC" ] && [ x"$protocol" != x"$PROTO_DHCP" ];then
        log_error "error,invalid proto $protocol"
        return 1
    fi
    log_info "config:{$ifname,$protocol,$ipaddr,$netmask,$gateway}"

    if [ x"${ip_type}" == x"ipv4" ];then
        netmask=`mask2cdr "${netmask}"`
    fi
    
    backup_netcfg="/tmp/ifcfg-$ifname"
    rm -f "${backup_netcfg}" 2>/dev/null
    touch "$backup_netcfg"

    for i in `ls /etc/netplan/*.yaml`; do
        tar_netcfg=$i
        cp -f $tar_netcfg $backup_netcfg
        ."${shell_dir}/parse_yaml" "$ifname" "$ipaddr" "$netmask" "$gateway" "$ip_type" "$tar_netcfg" "$backup_netcfg"
        cp -f $backup_netcfg $tar_netcfg
    done

    if [ x"$tar_netcfg" == x"" ];then
        touch "$backup_netcfg"
        ."${shell_dir}/parse_yaml" "$ifname" "$ipaddr" "$netmask" "$gateway" "$ip_type" "$tar_netcfg" "$backup_netcfg"
        tar_netcfg="/etc/netplan/netcfg.yaml"
        cp -f $backup_netcfg $tar_netcfg
    fi

    err_str=`netplan apply 2>&1`
    if [ $? -ne 0 ]; then
        log_error "ubuntu18_gen_network_cfg_file failed.Err: $err_str"
    fi
}


# interfaces config operation
# param $1: ifname, such as eth0
# param $2: operation del|backup
# return 0(success),1(fail)
interfaces_cfg_handle_one()
{
    local line_num=1
    local found_flag=0
    local start_line=0
    local end_line=0
    local ifname=$1
    local op=$2
    local backup_file=$3
    local ip_type=$4
    local inet=""
    local res=""
    local ret=""

    if [ x"${ifname}" == x"" ];then
        log_error "invalid ifname"
        return 1
    fi
    inet=`trans_inet_type "$ip_type"`
    if [ x"$inet" == x"" ];then
        log_error "no ip_type $ip_type inet $inet"
        return 1
    fi

    while read line
    do
        if [ ! $found_flag -eq 1 ];then
            #get the interface config start position
            ret=`echo "$line" | grep "^\s*iface" | grep "${inet}"| awk -v ifname="$ifname" '{if ($2==ifname) print 1}'`
            if [ x"$ret" == x"1" ];then
                found_flag=1
                start_line=$line_num
                log_debug "found start line $line,num=$line_num"
            fi
        else
            res=`echo "$line" | grep "^\s*auto"`
            if [ x"$res" != x"" ];then
                log_debug "found end line $line,num=$line_num"
                end_line=$(($line_num-1))
                break
            fi

            res=`echo "$line" | grep "^\s*iface"`
            if [ x"$res" != x"" ];then
                log_debug "found end line $line,num=$line_num"
                end_line=$(($line_num-1))
                break
            fi
        fi
        line_num=$(($line_num+1))
    done < "$g_debian_network_cfg"

    if [ "$found_flag" -eq 0 ];then
        log_debug "not found $ifname config"
        return 1
    fi

    if [ "$end_line" -eq 0 ];then
        log_info "$ifname is the last config"
        #reach end
        end_line=$(($line_num-1))
    fi

    log_debug "$op $ifname config line $start_line:$end_line"

    if [ x"${op}" == x"del" ];then
        log_info "delete $ifname config"
        sed -i "$start_line,${end_line}d" "$g_debian_network_cfg"
        #"auto ethxx" str may be in any position
        sed -i "/^\s*auto\s*$ifname\s*$/d" "$g_debian_network_cfg"
    else
        log_info "save $ifname config to $backup_file"
        sed -n "/^\s*auto\s*$ifname\s*$/p" "$g_debian_network_cfg" > "$backup_file"
        sed -n "$start_line,${end_line}p" "$g_debian_network_cfg"  >> "$backup_file"
    fi
    return 0
}

# 删除多ip配置，如eth1:20等接口
# param $1: ifname,eg:eth0
# param $2: ip类型 ipv4 or ipv6
# return: return 0(success),1(fail)
del_interfaces_mul_ip_config()
{
    local ifname=$1
    local ip_type=$2
    local inet=""

    inet=`trans_inet_type "$ip_type"`
    if [ x"$inet" == x"" ];then
        log_error "no ip_type $ip_type inet $inet"
        return 1
    fi

    # 查询接口名并删除
    for i in `grep "${inet}" "$g_debian_network_cfg" | grep "^\s*iface\s*${ifname}:" |awk '{print $2}'`
    do
        interfaces_cfg_handle_one "$i" "del" "" "$ip_type"
        log_info "del multiip config,ifname=$i"
    done
    return 0
}

# interfaces cfg handle
# param $1: ifname, such as eth0
# param $2: operation del|backup
# param $3: ip类型 ipv4 or ipv6
# return 0(success),1(fail)
interfaces_cfg_handle()
{
    local ifname=$1
    local op=$2
    local ip_type=$3
    local inet=""

    inet=`trans_inet_type "$ip_type"`
    if [ x"$inet" == x"" ];then
        log_error "no ip_type $ip_type inet $inet"
        return 1
    fi

    if [ x"${op}" == x"del" ];then
        while true
        do
            interfaces_cfg_handle_one "$ifname" "$op" "" "$ip_type"
            ret=`cat "$g_debian_network_cfg" |grep "$inet"| grep "^\s*iface\s*$ifname\s"`
            if test -z "$ret";then
                break
            fi
            log_debug "$ifname has more config"
        done
        # 由于接口名未知，多ip单独处理，格式ethx:xx
        del_interfaces_mul_ip_config "$ifname" "$ip_type"
    else
        interfaces_cfg_handle_one "$ifname" "$op" "" "$ip_type"
    fi
    return 0
}

#清理debian网卡中的dns
clear_debian_net_config_dns()
{
    local net_name=$1
    local v4_dns=""
    local v6_dns=""
    local dns_list=""
    local all_dns_list=""
    local three_dns=""

    test -z "$net_name" && return 1

    for net in $net_name; do
        v4_dns=`form_interfaces_get_dns "$net" "ipv4"`
        v6_dns=`form_interfaces_get_dns "$net" "ipv6"`
        dns_list=`joint_dns "$v4_dns" "$v6_dns"`
        if [ x"$dns_list" == x"" ];then
            continue
        else
            all_dns_list="$all_dns_list $dns_list"
            #去掉字符串首尾空格(如果不去掉，cut用法不会过滤掉空格，取不到想要取的字符串)
            all_dns_list=`echo "$all_dns_list" | awk '{gsub(/^\s+|\s+$/, "");print}'`
        fi
    done
    #获取前面三个dns
    three_dns=`get_three_dns "$all_dns_list"`
    echo "$three_dns"
}

#获取网卡中的dns
form_interfaces_get_dns()
{
    local ifname=$1
    local ip_type=$2
    local backup_file=""
    local all_cfg_message=""
    local dns1=""
    local dns2=""
    local dns_list=""

    test -z "$ifname" && return 1
    test -z "$ip_type" && return 1

    backup_file="/tmp/$ip_type$ifname"
    interfaces_cfg_handle_one "$ifname" "backup" "$backup_file" "$ip_type"
    all_cfg_message=`grep dns-nameservers "$backup_file" 2>/dev/null`
    if [ x"$all_cfg_message" == x"" ];then
        return 1
    fi
    rm -f "$backup_file" 2>/dev/null
    dns1=`echo "$all_cfg_message" | grep dns-nameservers | awk '{print $2}'`
    dns2=`echo "$all_cfg_message" | grep dns-nameservers | awk '{print $3}'`
    #去掉网卡中的dns
    sed -i "/$all_cfg_message/d" "$g_debian_network_cfg"
    dns_list=`joint_dns "$dns1" "$dns2"`
    echo "$dns_list"
    return 0
}

# debian series system generate network config
# param $1: ifname,eg:eth0
# param $2: protocol,eg:dhcp|static
# param $3: ip,eg:192.168.100.100
# param $4: net mask,eg:255.255.255.0
# param $5: gateway,eg:192.168.100.1
# param $6: ip类型 ipv4 or ipv6
# return 0(success),1(fail)
debian_gen_network_cfg_file()
{
    local ifname=$1
    local protocol=$2
    local ipaddr=$3
    local netmask=$4
    local gateway=$5
    local ip_type=$6
    local cfg_file=""

    test -z "$ifname" && return 1
    if [ x"$protocol" != x"$PROTO_STATIC" ] && [ x"$protocol" != x"$PROTO_DHCP" ];then
        log_error "error,invalid proto $protocol"
        return 1
    fi
    log_info "config:{$ifname,$protocol,$ipaddr,$netmask,$gateway}"
    cfg_file="/tmp/ifcfg-$ifname"

    echo "iface $ifname inet $protocol" > "$cfg_file"

    is_valid_inet_address "$ipaddr"
    if [ $? -eq 0 ];then
        echo "address $ipaddr" >> "$cfg_file"
    fi

    is_valid_inet_address "$netmask"
    if [ $? -eq 0 ];then
        echo "netmask $netmask" >> "$cfg_file"
    fi

    is_valid_inet_address "$gateway"
    if [ $? -eq 0 ];then
        echo "gateway $gateway" >> "$cfg_file"
    fi

    metric=`cat /proc/net/dev |sed -n  "/$ifname:/="`
    if ! test -z "$metric";then
        echo "metric 10$metric" >> "$cfg_file"
    fi

    interfaces_cfg_handle "$ifname" "del" "$ip_type"
    cat "$cfg_file" >> "$g_debian_network_cfg"
    return 0
}

# 判断网口配置文件中是否存在auto对应网口字段，不存在则添加，将auto字段对应的网卡名统一写到一块: auto lo eth0 eth1
# param $1: ifname,eg:eth0
check_is_auto()
{
    local ifname=$1
    local old_eth_list=""
    local new_dns_list=""
    local old_auto=""
    local new_auto=""

    test -z "$ifname" && return 1
    sed -i "/^\s*auto\s*$ifname\s*$/d" "$g_debian_network_cfg"

    old_eth_list=`grep "^\s*auto " "$g_debian_network_cfg" | sed "s/^\s*//g" | sed "s/\s*#.*$//g" | sed "s/\s*$//g" | cut -d " " -f 2-`
    for eth in $old_eth_list; do
        if [ x"$eth" == x"$ifname" ];then
            return 0
        fi
    done
    old_eth_list=$(echo "$old_eth_list" | xargs echo -n) # 去掉换行符
    new_eth_list="$ifname $old_eth_list"
    old_auto="auto $old_eth_list"
    new_auto="auto $new_eth_list"
    grep -q "$old_auto" "$g_debian_network_cfg"
    if [ $? -ne 0 ]; then
        # 第一次统一auto字段
        sed -i --follow-symlinks "1i\\$new_auto" "$g_debian_network_cfg"
        for eth in $old_eth_list; do
            sed -i --follow-symlinks "/^\s*auto\s*$eth\s*$/d" "$g_debian_network_cfg"
        done
    else
        sed -i --follow-symlinks "s/$old_auto/$new_auto/g" "$g_debian_network_cfg"
    fi
}

# debian series system generate network config
# param $1: ifname,eg:eth0
# param $2: protocol,eg:dhcp|static
# param $3: ipv6,eg:2001:d02::14:0:0:9
# param $4: ipv6_prefix,eg:64
# param $5: ipv6_gateway,eg:2001:d02::14:0:0:9
# param $6: ip类型 ipv4 or ipv6
# return 0(success),1(fail)
debian_gen_ipv6_network_cfg_file()
{
    local ifname=$1
    local protocol=$2
    local ipv6=$3
    local ipv6_prefix=$4
    local ipv6_gateway=$5
    local ip_type=$6
    local cfg_file=""

    test -z "$ifname" && return 1
    if [ x"$protocol" != x"$PROTO_STATIC" ] && [ x"$protocol" != x"$PROTO_DHCP" ];then
        log_error "error,invalid proto $protocol"
        return 1
    fi

    log_info "config:{$ifname,$protocol,$ipv6,$ipv6_prefix,$ipv6_gateway}"
    cfg_file="/tmp/ifcfg-$ifname"

    echo "iface $ifname inet6 $protocol" > "$cfg_file"
    echo "pre-up modprobe ipv6" >> "$cfg_file"

    is_valid_inet6_address "$ipv6"
    if [ $? -eq 0 ];then
        echo "address $ipv6" >> "$cfg_file"
    fi
    is_valid_inet6_prefixlen "$ipv6_prefix"
    if [ $? -eq 0 ];then
        echo "netmask $ipv6_prefix" >> "$cfg_file"
    fi
    is_valid_inet6_address "$ipv6_gateway"
    if [ $? -eq 0 ];then
         echo "gateway $ipv6_gateway" >> "$cfg_file"
    fi

    metric=`sed -n "/$ifname:/=" /proc/net/dev`
    if ! test -z "$metric";then
        echo "metric 10$metric" >> "$cfg_file"
    fi

    interfaces_cfg_handle "$ifname" "del" "$ip_type"
    cat "$cfg_file" >> "$g_debian_network_cfg"
    return 0
}

# debian series system generate network config
# param $1: ifname,eg:eth0
# param $2: ip,eg:192.168.100.100
# param $3: net mask,eg:255.255.255.0
# param $4: gateway,eg:192.168.100.1
# param $5: ip_type,ipv4 or ipv6
# return 0(success),1(fail)
debian_network_cfg_handle()
{
    local ifname=$1
    local ipaddr=$2
    local netmask=$3
    local gateway=$4
    local ip_type=$5
    local method=""
    local inet_type=""
    local backup_file=""
    local protocol=$PROTO_STATIC

    if test -z "$ifname";then
        log_error "ifname is needed"
        return 1
    fi
    check_iptype_is_ipv4_or_ipv6 "$ip_type"
    if [ $? -eq 1 ]; then
        log_error "ip_type $ip_type is not ipv4 or ipv6"
        return 1
    fi

    # 如果没有配置ip，获取接口当前的配置
    if test -z "$ipaddr";then
        log_info "$ifname not found ip config"
        method=`nmcli_get_config_ip_method "$ifname" "$ip_type"` 
        if ! test -z "$method";then
            #从networkmanager配置中获取
            if [ x"$method" == x"manual" ] || [ x"$method" == x"ignore" ];then
                protocol=$PROTO_STATIC
                ipaddr=`nmcli_get_config_ip "$ifname" "$ip_type"`
                netmask=`nmcli_get_config_mask "$ifname" "$ip_type"`
                gateway=`nmcli_get_config_gateway "$ifname" "$ip_type"` 
            else
                protocol=$PROTO_DHCP
            fi
            log_info "[nmcli]origin ip_type:$ip_type,proto:$protocol,ip:$ipaddr,netmask:$netmask,gateway:$gateway"
        else
            #从/etc/network/interfaces配置中获取
            inet_type=`trans_inet_type "$ip_type"`
            if [ x"$inet_type" == x"" ];then
                log_error "no ip_type $ip_type inet_type $inet_type"
                return 1
            fi

            log_info "get info from config $ifname"
            backup_file="/tmp/$ifname.cfg"
            interfaces_cfg_handle_one "$ifname" "backup" "$backup_file" "${ip_type}"
            protocol=`grep "${inet_type}" "$backup_file" | grep "iface"|awk '{print $4}'`

            if [ x"$PROTO_STATIC" == x"$protocol" ];then
                ipaddr=`grep "^\s*address" "$backup_file" | awk '{print $2}'`
                ipaddr=`remove_quotation_mark "$ipaddr"`
                netmask=`grep "^\s*netmask" "$backup_file"| awk '{print $2}'`
                netmask=`remove_quotation_mark "$netmask"`
                gateway=`grep "^\s*gateway" "$backup_file" | awk '{print $2}'`
                gateway=`remove_quotation_mark "$gateway"`
            else
                protocol=$PROTO_DHCP
            fi
            log_info "[config]origin ip_type:$ip_type, proto:$protocol,ip:$ipaddr,netmask:$netmask,gateway:$gateway"
        fi
    fi

    # 配置中可能获取不到ip，通过命令获取
    if [ x"$PROTO_STATIC" == x"$protocol" ];then
        if test -z "$ipaddr" || test -z "$netmask";then
            log_warn "$ifname get config from cmd"
            if [ x"$ip_type" == x"ipv4" ];then
                ipaddr=`get_if_ip "$ifname"`
                netmask=`get_if_mask "$ifname"`
                gateway=`get_if_gateway "$ifname"`
            elif [ x"$ip_type" == x"ipv6" ];then
                ipaddr=`get_if_ipv6 "$ifname"`
                netmask=`get_if_ipv6_prefix_len "$ifname"`
                gateway=`get_if_ipv6_gateway "$ifname"`
            fi
            if test -z "$ipaddr" || test -z "$netmask";then
                log_warn "$ifname get ip info failed,use default proto (dhcp)"
                protocol=$PROTO_DHCP
            else
                protocol=$PROTO_STATIC
            fi
            log_info "[cmd]origin ip_type:$ip_type, proto:$protocol,ip:$ipaddr,netmask:$netmask,gateway:$gateway"
        fi
    fi

    #由于添加ipv6的字段信息之后，有些系统对于多个auto ifname同样的字段，系统会认为网卡配置文件出错，导致重启网络失败，
    #因此将auto字段对应的网卡名统一写到一块
    check_is_auto "$ifname"

    if [ x"$ip_type" == x"ipv4" ];then
        if is_new_ubuntu; then
            ubuntu18_gen_network_cfg_file "$ifname" "$protocol" "$ipaddr" "$netmask" "$gateway" "$ip_type"
        else
            debian_gen_network_cfg_file "$ifname" "$protocol" "$ipaddr" "$netmask" "$gateway" "$ip_type"
        fi
    elif [ x"$ip_type" == x"ipv6" ];then
        if is_new_ubuntu; then
            ubuntu18_gen_network_cfg_file "$ifname" "$protocol" "$ipaddr" "$netmask" "$gateway" "$ip_type"
        else
            debian_gen_ipv6_network_cfg_file "$ifname" "$protocol" "$ipaddr" "$netmask" "$gateway" "$ip_type"
        fi
    fi

    # 若网卡未启用，则启用网卡
    ifconfig "$ifname" | grep "UP" -q
    if [ $? -ne 0 ]; then
        ifconfig "$ifname" up
    fi

    return 0
}


