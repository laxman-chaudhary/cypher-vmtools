#! /bin/bash
# create by lzlong
# 修改虚拟机内部系统的配置

#简单的日志函数

function log_info(){
    log "INFO ${*}"
}
function log_error(){
    log "ERR ${*}"
}
function log_warn(){
    log "WARN ${*}"
}
function log_debug(){
    log "DEBUG ${*}"
}

# Fix TD 86851, 经讨论，禁掉所有Linux的页面碎片整理
# 问题描述： centos7.x guest系统的balloon驱动有bug，透明大页的页面碎片整理会进行page migration，从而触发balloon驱动有问题的逻辑
set_transparent_hugepage_defrag_never(){
    local thp_defrag_path=""
    if [ -f "/sys/kernel/mm/transparent_hugepage/defrag" ]; then
      thp_defrag_path="/sys/kernel/mm/transparent_hugepage/defrag"
    elif [ -f "/sys/kernel/mm/redhat_transparent_hugepage/defrag" ]; then
      thp_defrag_path="/sys/kernel/mm/redhat_transparent_hugepage/defrag"
    else
      return
    fi

    local has_never=$(cat ${thp_defrag_path} |grep '\[never\]')
    if [ x"$has_never" == x"" ];then
        log_info "echo never to  ${thp_defrag_path}"
        echo 'never' > ${thp_defrag_path}
    fi

    return
}

# Fix TD 86851, 经过实际验证，numa_balancing也会进行page migration操作，因此也有可能触发balloon内存回收的问题。
# 因此，在vmtools里面需要补充如下的修改，检测到虚拟机开启了内存回收时，就禁用numa自动平衡机制。
disable_numabalance_when_use_virtballon(){
    local numa_balancing_path="/proc/sys/kernel/numa_balancing"

    # Fix TD 90404,开启会导致oracle的性能测试iowait比较高，这里默认关掉
    if [ -f ${numa_balancing_path} ];then
        log_info "disable numa balancing:echo 0 to ${numa_balancing_path}"
        echo 0 > ${numa_balancing_path}
    fi
}

modify_guest_system_config() {
    set_transparent_hugepage_defrag_never
    disable_numabalance_when_use_virtballon
}