#!/bin/bash

shell_dir=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
. "${shell_dir}/sangfor_vmconfig_common"

main()
{
    #init vmconfig env
    init_env
    #init vmconfig ipc
    vm_ipc_init ${g_mode_id} ${g_instance_id}
    if [ $? -ne 0 ]; then
        log_error "vmconfig vm_ipc_init() failed! modid='${g_mode_id}' instid='${g_instance_id}'"
        return 1
    fi
    if [ "$1" == "dns" ]; then
        immediately_set_network "dns"
    else
        immediately_set_network
    fi

}
main $*