#!/bin/bash
# shellcheck disable=SC1017,SC2046,SC2060,SC2155

shell_dir=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
. "${shell_dir}/log.sh"

# set password
# param $1: password
set_root_pwd()
{
    local root_pwd=`echo "$1" | base64 -d`
    echo "root:$root_pwd" | chpasswd >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        log "chpasswd error"
    fi
}

# clear file: passwd.lock shadow.lock
clear_chpasswd_lock_file()
{
    local passwd_lock_file="/etc/passwd.lock"
    local shadow_lock_file="/etc/shadow.lock"

    if [ `cat $passwd_lock_file | wc -l` -eq 0 ]; then
         unlink $passwd_lock_file
    fi

    if [ `cat $shadow_lock_file | wc -l` -eq 0 ]; then
         unlink $shadow_lock_file
    fi
}

chmod_600()
{
    local file_path=$1

    if [ ! -e "${file_path}" ];then
        log_error "file ${file_path} is not exist"
        return 1
    fi

    if stat -c '%a' "${file_path}" | grep -qv 600;then
        chmod 600 "${file_path}" 2>/dev/null
    fi

    if [ $? -ne 0 ];then
        return 1
    fi

    return 0
}

# set ssh_publickey
# param $1: ssh_publickey_operate
# param $2: ssh_publickey
# return 0(success),1(fail)
set_ssh_publickey()
{
    local ssh_publickey_operate=$1
    #兼容性适配，arm的一些系统如deepin、kylinV10、redhat、centos支持第一行的操作，另一些操作系统如debian、UOS支持第二行的操作
    #有些系统两种方式都支持，有些只能支持其中一种，如centos只支持第一种方式，UOS只支持第二种方式，需要都兼容
    local ssh_publickey=`echo "$2" | sed -r 's/(..)/\1 /g' | awk '{for(i=1;i<=NF;i++) print strtonum("0x"$i)}'  | awk '{for(i=1;i<=NF;i++) printf("%c", $i)}'`
    if [ -z "$ssh_publickey" ] ; then
        ssh_publickey=`echo "$2" | sed -r 's/(..)/\1 /g' | awk '{for(i=1;i<=NF;i++) printf("%d ", "0x"$i)}'  | awk '{for(i=1;i<=NF;i++) printf("%c", $i)}'`
    fi
    local config_file_arr=("/root/.ssh/authorized_keys" "/etc/ssh/sshd_config")

    # 检查秘钥格式正确
    content=`echo "$ssh_publickey" | awk '{print $2}'`
    if [ x"${content}" != x"" ] ; then
        if ! [[ "${content}" =~ ^[A-Za-z0-9/+=-]+$ ]] ; then
            log "The content of "${ssh_publickey}" file is not ssh public key, Abort!"
            return
        fi
    fi

    # 检查配置文件权限
    for file in ${config_file_arr[@]}
    do
        if [ ! -f ${file} ]; then
            continue
        fi
        permission=`stat -c "%G" ${file}`
        if [ x"${permission}" != x"root" ] ; then
            log "The permission of ${file} file is not root, Abort!"
            return
        fi
    done

    if [ "${ssh_publickey_operate}" -eq 0 ] ; then
        rm -f /root/.ssh/authorized_keys

        sed -i '/^PermitRootLogin .*/d' /etc/ssh/sshd_config
        echo "PermitRootLogin yes" >> /etc/ssh/sshd_config

        log "remove ssh_publickey...success"
    else
        if [ ! -e "/root/.ssh" ] ; then
             mkdir -p /root/.ssh
        fi

        echo "${ssh_publickey}" > /root/.ssh/authorized_keys

        sed -i '/^PermitRootLogin .*/d' /etc/ssh/sshd_config
        echo "PermitRootLogin without-password" >> /etc/ssh/sshd_config

        log "set ssh_publickey ${ssh_publickey}...success"
    fi

    #ubuntu19需要重启ssh服务
    /etc/init.d/ssh restart 2>/dev/null
    systemctl restart ssh 2>/dev/null
    /etc/init.d/sshd restart 2>/dev/null
    systemctl restart sshd 2>/dev/null

    return 0
}

#Get the major version
#$1 The version string
#return the major version. Return 255 if it is failed.
get_major(){
    local module_version="$1"
    local temp_str=""
    module_version=`echo "$1" 2>/dev/null | tr -d [:space:] 2>/dev/null`
    #Determine the parameters of legitimacy
    if [[ "${module_version}" =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]];then
        log_debug "module_version:${module_version} format is right."
    else
        #module_version format is wrong.
        log_error "module_version:${module_version} format is error!"
        return 255
    fi
    temp_str=${module_version%%.*}
    if [ x"${temp_str}" = x"" ];then
        log_error "get major failed!"
        #Get the major version failed.
        return 255
    fi
    if [ "${temp_str}" -ge 255 ];then
        log_error "The major number is too big!"
        return 255
    fi
    return ${temp_str}
}

#TEST get_major
TEST_get_major(){
    log_debug "TEST_get_major"
    get_major "2.0.1"
    if [ ${?} -ne 2 ];then
        log_error "get_major 2.0.1 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi


    get_major "        2.     0.           1"
    if [ ${?} -ne 2 ];then
        log_error "get_major         2.     0.           1 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_major ".0.1"
    if [ ${?} -ne 255 ];then
        log_error "get_major .0.1 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_major "005.0.1"
    if [ ${?} -ne 5 ];then
        log_error "get_major 005.0.1 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_major "0005.0.1"
    if [ ${?} -ne 255 ];then
        log_error "get_major 0005.0.1 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_major "300.0.1"
    if [ ${?} -ne 255 ];then
        log_error "get_major 300.0.1 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_major "9999999999999.0.1"
    if [ ${?} -ne 255 ];then
        log_error "get_major 9999999999999.0.1 failed!"
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_major "20.1"
    if [ ${?} -ne 255 ];then
        log_error "get_major 20.1 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_major "201"
    if [ ${?} -ne 255 ];then
        log_error "get_major 201 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_major "2.0.1.4"
    if [ ${?} -ne 255 ];then
        log_error "get_major 2.0.1.4 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_major "2.0s1"
    if [ ${?} -ne 255 ];then
        log_error "get_major 2.0s1 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_major "2.0..1"
    if [ ${?} -ne 255 ];then
        log_error "get_major 2.0..1 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi
    return 0
}

#Get the minor version
#$1 The version string
#Return the minor version，return 255 if failed.
get_minor(){
    local module_version="$1"
    local temp_str=""
    local temp_str_str=""
    module_version=`echo "$1" 2>/dev/null | tr -d [:space:] 2>/dev/null`
    #Determine the parameters of legitimacy
    if [[ "${module_version}" =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]];then
        log_debug "module_version:${module_version} format is right."
    else
        #module_version format is wrong.
        log_error "module_version:${module_version} format is error!"
        return 255
    fi
    temp_str=${module_version#*.}
    temp_str_str=${temp_str%.*}
    if [ x"${temp_str_str}" = x"" ];then
        #get minor version failed!
        log_error "get minor failed!"
        return 255
    fi
    if [ "${temp_str_str}" -ge 255 ];then
        log_error "The minor number is too big!"
        return 255
    fi
    return ${temp_str_str}
}

#TEST get_minor
TEST_get_minor(){
    log_debug "TEST_get_minor"
    get_minor "2.0.1"
    if [ ${?} -ne 0 ];then
        log_error "get_minor 2.0.1 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_minor "        2.     0.           1"
    if [ ${?} -ne 0 ];then
        log_error "get_minor         2.     0.           1 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_minor "2..1"
    if [ ${?} -ne 255 ];then
        log_error "get_minor 2..1 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_minor "2.005.1"
    if [ ${?} -ne 5 ];then
        log_error "get_minor 2.005.1 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_minor "2.0005.1"
    if [ ${?} -ne 255 ];then
        log_error "get_minor 2.0005.1 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_minor "0.9999999999999999999999999999999999.1"
    if [ ${?} -ne 255 ];then
        log_error "get_minor 0.9999999999999999999999999999999999.1 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_minor "20.1"
    if [ ${?} -ne 255 ];then
        log_error "get_minor 20.1 failed!"
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_minor "201"
    if [ ${?} -ne 255 ];then
        log_error "get_minor 201 failed!"
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_minor "2.0.1.4"
    if [ ${?} -ne 255 ];then
        log_error "get_minor 2.0.1.4 failed!"
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_minor "2.0s1"
    if [ ${?} -ne 255 ];then
        log_error "get_minor 2.0s1 failed!"
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_minor "2.0..1"
    if [ ${?} -ne 255 ];then
        log_error "get_minor 2.0..1 failed!"
        log_error "TEST_get_major failed!"
        return 1
    fi
    return 0
}

#Get the release version
#$1 The version string
#Return the release version，Return 255 if failed.
get_release(){
    local module_version="$1"
    local temp_str=""
    module_version=`echo "$1" 2>/dev/null | tr -d [:space:] 2>/dev/null`
    #Determine the parameters of legitimacy
    if [[ "${module_version}" =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]];then
        log_debug "module_version:${module_version} format is right."
    else
        #version format is wrong
        log_error "module_version:${module_version} format is error!"
        return 255
    fi
    temp_str=${module_version##*.}
    if [ x"${temp_str}" = x"" ];then
        #get the release version failed
        log_error "get release failed!"
        return 255
    fi
    if [ "${temp_str}" -ge 255 ];then
        log_error "The release number is too big!"
        return 255
    fi
    return ${temp_str}
}

#TEST get_release
TEST_get_release(){
    log_debug "TEST_get_release"
    get_release "2.0.1"
    if [ ${?} -ne 1 ];then
        log_error "get_release 2.0.1 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_release "        2.     0.           1"
    if [ ${?} -ne 1 ];then
        log_error "get_release         2.     0.           1 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_release "2.0."
    if [ ${?} -ne 255 ];then
        log_error "get_release 2.0. failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_release "2.0.005"
    if [ ${?} -ne 5 ];then
        log_error "get_release 2.0.005 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_release "2.0.0005"
    if [ ${?} -ne 255 ];then
        log_error "get_release 2.0.0005 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_release "2.0.9999999999999999999999999999999999"
    if [ ${?} -ne 255 ];then
        log_error "get_release 2.0.9999999999999999999999999999999999 failed!"
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_release "20.1"
    if [ ${?} -ne 255 ];then
        log_error "get_release 20.1 failed!"
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_release "201"
    if [ ${?} -ne 255 ];then
        log_error "get_release 201 failed!"
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_release "2.0.1.4"
    if [ ${?} -ne 255 ];then
        log_error "get_release 2.0.1.4 failed!"
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_release "2.0s1"
    if [ ${?} -ne 255 ];then
        log_error "get_release 2.0s1 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi

    get_release "2.0..1"
    if [ ${?} -ne 255 ];then
        log_error "get_release 2.0..1 failed! "
        log_error "TEST_get_major failed!"
        return 1
    fi
    return 0
}

#compare version function
#$1 The version of the guest
#$2 The version of the host
#255 failed
#0 The version is the same
#1 $1 is taller than $2
#2 $2 is taller than $1
compare_version(){
    local first_version="$1"
    local second_version="$2"
    local first_major=255
    local first_minor=255
    local first_release=255
    local second_major=255
    local second_minor=255
    local second_release=255

    get_major "${first_version}"
    first_major=$?
    get_minor "${first_version}"
    first_minor=$?
    get_release "${first_version}"
    first_release=$?
    get_major "${second_version}"
    second_major=$?
    get_minor "${second_version}"
    second_minor=$?
    get_release "${second_version}"
    second_release=$?
    if [ ${first_major} -eq 255 -o ${first_minor} -eq 255 -o ${first_release} -eq 255 ];then
        log_error "analysis ${first_version} failed!"
        return 255
    fi
    if [ ${second_major} -eq 255 -o ${second_minor} -eq 255 -o ${second_release} -eq 255 ];then
        log_error "analysis ${second_version} failed!"
        return 255
    fi
    #compare major
    if [ ${first_major} -lt ${second_major} ];then
        log_debug "${first_version} < ${second_version}"
        return 2
    elif [ ${first_major} -gt ${second_major} ];then
        log_debug "${first_version} > ${second_version}"
        return 1
    fi
    #compare minor
    if [ ${first_minor} -lt ${second_minor} ];then
        log_debug "${first_version} < ${second_version}"
        return 2
    elif [ ${first_minor} -gt ${second_minor} ];then
        log_debug "${first_version} > ${second_version}"
        return 1
    fi
    #compare release
    if [ ${first_release} -lt ${second_release} ];then
        log_debug "${first_version} < ${second_version}"
        return 2
    elif [ ${first_release} -gt ${second_release} ];then
        log_debug "${first_version} > ${second_version}"
        return 1
    fi
    log_debug "${first_version} = ${second_version}"
    return 0
}
#TEST compare_version
TEST_compare_version(){
    log_debug "TEST_compare_version"
    compare_version "2.0.1" "2.0.1" 
    if [ $? -ne 0 ];then
        log_error "compare_version 2.0.1 2.0.1 failed!"
        log_error "TEST_compare_version failed!"
        return 1
    fi
    compare_version "2.0.2" "2.0.1" 
    if [ $? -ne 1 ];then
        log_error "compare_version 2.0.2 2.0.1 failed!"
        log_error "TEST_compare_version failed!"
        return 1
    fi
    compare_version "2.0.1" "2.0.2" 
    if [ $? -ne 2 ];then
        log_error "compare_version 2.0.1 2.0.2 failed! "
        log_error "TEST_compare_version failed!"
        return 1
    fi
    compare_version "2.0.1" " 2.0.2" 
    if [ $? -ne 2 ];then
        log_error "compare_version \"2.0.1\" \" 2.0.2\" failed!"
        log_error "TEST_compare_version failed!"
        return 1
    fi
    compare_version "2.0.1" 
    if [ $? -ne 255 ];then
        log_error "compare_version 2.0.1 failed! "
        log_error "TEST_compare_version failed!"
        return 1
    fi
    compare_version "0.1" "2.0.2" 
    if [ $? -ne 255 ];then
        log_error "compare_version 0.1 2.0.2 failed!"
        log_error "TEST_compare_version failed!"
        return 1
    fi
    compare_version "2.1.9999999999999999999999999999999999" "2.0.2" 
    if [ $? -ne 255 ];then
        log_error "compare_version 2.1.9999999999999999999999999999999999 2.0.2 failed!"
        log_error "TEST_compare_version failed!"
        return 1
    fi
    compare_version "20.0006.00001" "2.0.2" 
    if [ $? -ne 255 ];then
        log_error "compare_version 20.0006.00001 2.0.2 failed!"
        log_error "TEST_compare_version failed!"
        return 1
    fi
    compare_version "2.0.1" "202" 
    if [ $? -ne 255 ];then
        log_error "compare_version 2.0.1 202 failed!"
        log_error "TEST_compare_version failed!"
        return 1
    fi
    compare_version "2.0.10.4" "2.0.2" 
    if [ $? -ne 255 ];then
        log_error "compare_version 2.0.10.4 2.0.2 failed!"
        log_error "TEST_compare_version failed!"
        return 1
    fi
    return 0
}