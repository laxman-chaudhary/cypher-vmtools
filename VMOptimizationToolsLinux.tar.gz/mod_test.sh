#!/bin/bash

# Test code，Used for testing the transmission module

shell_dir=`dirname "$0"`
. "${shell_dir}/vm_ipc.sh"

proc_msg_10001()
{
	local peer_modid=${1}
	local peer_instid=${2}
	local datafile=${3}
	local data=`cat "${datafile}"`
	
	echo "recv data from mod ${peer_modid} inst ${peer_instid}: ${data}"
	
	# Back to the pack for test
	local answer='{"people":[{"name":"hellworld[0]","age":0,"note":"nice to meet you!!!!"},{"name":"hellworld[1]","age":1,"note":"nice to meet you!!!!"},{"name":"hellworld[2]","age":2,"note":"nice to meet you!!!!"},{"name":"hellworld[3]","age":3,"note":"nice to meet you!!!!"},{"name":"hellworld[4]","age":4,"note":"nice to meet you!!!!"},{"name":"hellworld[5]","age":5,"note":"nice to meet you!!!!"},{"name":"hellworld[6]","age":6,"note":"nice to meet you!!!!"},{"name":"hellworld[7]","age":7,"note":"nice to meet you!!!!"},{"name":"hellworld[8]","age":8,"note":"nice to meet you!!!!"},{"name":"hellworld[9]","age":9,"note":"nice to meet you!!!!"}]}'
	
	vm_ipc_to_local_host ${peer_modid} ${peer_instid} 10002 "${answer}" || return 1
	echo "answer: ${answer}"
	return 0
}

proc_msg_10003()
{
	local peer_modid=${1}
	local peer_instid=${2}
	local datafile=${3}
	
	echo "recv file from mod ${peer_modid} inst ${peer_instid}: ${data}"
	# If you use echo analysis may be truncated because here is to transfer files.
	local filename=`get_value_from_json_file "${datafile}" filename`
	local filesize=`get_value_from_json_file "${datafile}" filesize`
	
	# The binary data using the base64 transcoding. 
	# Note here that regular requirements of data field is not the last field.
	sed 's/.*"data":"\(.*\)",.*/\1/g' "${datafile}" | base64 -d > /var/recv
	
	return 0
}

proc_msg_10004()
{
	local peer_modid=${1}
	local peer_instid=${2}
	local datafile=${3}
	
	echo "send file to host mod ${peer_modid} inst ${peer_instid}: ${data}"
	local filename=`get_value_from_json_file "${datafile}" note`
	
	base64 "${filename}" > /var/send.tmp
	local filesize=`stat -c %s "${filename}"`
	local basefilename=`basename "${filename}"`
	
	echo -n "{\"filename\":\"${basefilename}\",\"filesize\":\"${filesize}\",\"data\":\""  > /var/send.tmp
	# base64 add --wrap to avoid wrap
	base64 --wrap=0 "${filename}" >> /var/send.tmp
	echo "\",\"offset\":\"0\"}" >> /var/send.tmp
	
	vm_ipc_to_local_host ${peer_modid} ${peer_instid} 10003 "/var/send.tmp" || return 1
}

proc_msg_10005()
{
	local peer_modid=${1}
	local peer_instid=${2}
	local datafile=${3}
	local data=`cat "${datafile}"`
	
	echo "recv data from mod ${peer_modid} inst ${peer_instid}: ${data}"
	
	# Back to the pack for test
	local answer='{"people":[{"name":"hellworld[0]","age":0,"note":"nice to meet you!!!!"},{"name":"hellworld[1]","age":1,"note":"nice to meet you!!!!"},{"name":"hellworld[2]","age":2,"note":"nice to meet you!!!!"},{"name":"hellworld[3]","age":3,"note":"nice to meet you!!!!"},{"name":"hellworld[4]","age":4,"note":"nice to meet you!!!!"},{"name":"hellworld[5]","age":5,"note":"nice to meet you!!!!"},{"name":"hellworld[6]","age":6,"note":"nice to meet you!!!!"},{"name":"hellworld[7]","age":7,"note":"nice to meet you!!!!"},{"name":"hellworld[8]","age":8,"note":"nice to meet you!!!!"},{"name":"hellworld[9]","age":9,"note":"nice to meet you!!!!"}]}'
	
	vm_ipc_to_self ${peer_modid} ${peer_instid} 10006 "${answer}" || return 1
	echo "answer: ${answer}"
	return 0
}

main()
{
	local modid=123
	local instid=234
	vm_ipc_init ${modid} ${instid}
	if [ $? -ne 0 ]; then
		log "vm_ipc_init() failed! modid='${modid}' instid='${instid}'"
		return 1
	fi
	
	vm_ipc_reg_callback 10001 proc_msg_10001
	vm_ipc_reg_callback 10003 proc_msg_10003
	vm_ipc_reg_callback 10004 proc_msg_10004
	vm_ipc_reg_callback 10005 proc_msg_10005
	
	while true
	do
		vm_ipc_event_loop_once
		sleep 1
	done
}

main
