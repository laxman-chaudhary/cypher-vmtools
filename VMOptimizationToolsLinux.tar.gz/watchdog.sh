#!/bin/bash

# API interface for monitoring process this file

# The directory for registration process.
declare -r WATCHDOG_DIR__="/var/sangfor/watchdog"
# lock file
declare -r WATCHDOG_LOCK__=${WATCHDOG_DIR__}/.lock
# sangfor_watchdog process directory
declare g_watchdog_dir__=`dirname "$0"`

# Return the locked file descriptor
watchdog_lock_file_fd()
{
	echo "200"
	return 0
}

# Initialize the watchdog interface. This service will join the watchdog monitoring
# param $1: process name(without path)
watchdog_reg_proccess()
{
	local procname=$1	
	# create a directory if it does not exist.
	test ! -d "${WATCHDOG_DIR__}" && mkdir -p "${WATCHDOG_DIR__}"
	# Generate a monitor file
	echo 0 > "${WATCHDOG_DIR__}/${procname}" && return 0 || return 1
}

# The anti registration
# param $1: process name (without path)
watchdog_unreg_process()
{
	local procname=$1
	test -z "${WATCHDOG_DIR__}" && return 1
	test -z "${procname}" && return 1
	rm -f "${WATCHDOG_DIR__}/${procname}" && return 0 || return 1
}

# External call check API, call in the while cycle
watchdog_check_once()
{
	# Non blocking lock, and not that watchdog already exists
	exec 200<>"${WATCHDOG_LOCK__}"
	test $? -eq 0 || return 1
	
	flock -n 200
	local ret=$?
	test ${ret} -eq 0 && log "sangfor_watchdog is dead, restart it!" && "${g_watchdog_dir__}/sangfor_watchdog" "sangfor_watchdog"
	
	# Close the file lock automatic release
	exec 200<&-

	return 0
}
