#!/bin/bash

# The demo to test watchdog.

# current directory
shell_dir=`dirname "$0"`
my_name=`basename "$0"`
. "${shell_dir}/log.sh"
. "${shell_dir}/watchdog.sh"

proc=`basename "$0"`
watchdog_reg_proccess "${proc}"

set_log_filepath "/var/log/${my_name}.log"
while true
do
	watchdog_check_once
	sleep 3
done

